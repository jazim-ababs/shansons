<!DOCTYPE HTML>

<html>
	<head>
		<title>Dimension by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="<?php echo e(asset('custom/assets/css/main.css')); ?>" />
    <noscript><link rel="stylesheet" href="<?php echo e(asset('custom/assets/css/noscript.css')); ?>" /></noscript>
    
    <style>
      .add-img {
        background-image: url(<?php echo e(asset('custom/images/main.jpg')); ?>)
      }
    </style>
	</head>
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper" class="add-img">

				<!-- Header -->
					<header id="header" class="add">
						<div class="logo">
							<span class="icon fa-gem"></span>
						</div>
						<div class="content">
							<div class="inner">
								<h1>Shan Son's Engineering Works</h1>
								<p>Auto Parts Manufacturer</p>
							</div>
						</div>
						<nav>
							<ul>
                <?php if(auth()->guard()->check()): ?>
                    <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>

                    <?php if(Route::has('register')): ?>
                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php endif; ?>
                <?php endif; ?>
							</ul>
						</nav>
					</header>
			
				<!-- Footer -->
					<footer id="footer">
						<p class="copyright">&copy; 2019 <a href="https://www.softwarehubpro.com" >Software Hub Pro</a>. All Rights Reserved.</p>
					</footer>

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="<?php echo e(asset('custom/assets/js/jquery.min.js')); ?>"></script>
			<script src="<?php echo e(asset('custom/assets/js/browser.min.js')); ?>"></script>
			<script src="<?php echo e(asset('custom/assets/js/breakpoints.min.js')); ?>"></script>
			<script src="<?php echo e(asset('custom/assets/js/util.js')); ?>"></script>
			<script src="<?php echo e(asset('custom/assets/js/main.js')); ?>"></script>
			<script src="<?php echo e(asset('admin/js/loader.js')); ?>"></script>

	</body>
</html>
<?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/landing-page.blade.php ENDPATH**/ ?>