<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'Default Report'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>">

    <?php echo $__env->yieldPushContent('styling'); ?>

</head>
<body>


        <?php echo $__env->make('shared.main-print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

       
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/jquery.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripting'); ?>
    
</body>
</html><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/layouts/print.blade.php ENDPATH**/ ?>