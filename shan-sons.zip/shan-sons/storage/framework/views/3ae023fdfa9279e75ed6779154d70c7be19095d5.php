<?php $__env->startSection('title'); ?>
    Edit Prfole
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>

    <h1 class="page-header">
        Dashboard
        <small>Profile</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Profile > Edit Profile</p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                    <form method="POST" action="<?php echo e(route('profile.update', ['id' => auth()->user()->id])); ?>">
			
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
            
                        <div class="form-group">
                            <label for="name">Username:</label>
                            <input class="form-control" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">
                        </div>
            
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input class="form-control" disabled  type="email" name="email" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
            
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" class="form-control" id="password">
                        </div>
            
                        <div class="form-group">
                            <label for="c-password">Confirm Password:</label>
                            <input type="password" name="password_confirmation" class="form-control" id="c-password">
                        </div>
            
                        <input type="submit" class="btn btn-primary" value="Update Password">
            
                    </form>

            </div>

        </div>

    </div>

    <div style="margin-top: 10px"></div>
    <?php echo $__env->make('/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>

    <?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>