<div class="<?php echo e($responsiveClass); ?>">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            <tr>
                <th>Sr No</th>
                <th>Name</th>
                <th>Working Days</th>
                <th>Basic Salary</th>
                <th>Total Hours	</th>
                <th>Late Hours	</th>
                <th>Total Over Time	</th>
                <th>Over Time Commission</th>
                <th>Net Salary	</th>
                <th>Co. Section	</th>
                <th>P.Balance	</th>
                <th>Day Book</th>
                <th>Total</th>
                <th>Advance Dedication</th>
                <th>Penality</th>
                <th>Final Salary</th>
                <th>Pay Salary</th>
                <th>Signature</th>
                <th>B/Loan</th>
                <th>Total Security</th>
            </tr>

            <tr>
                <td><?php echo e($payroll->srNumber); ?></td>
                <td><?php echo e($payroll->employee->name); ?></td>
                <td><?php echo e($payroll->workingDays); ?></td>
                <td><?php echo e($payroll->basicSalary); ?></td>
                <td><?php echo e($payroll->totalHours); ?></td>
                <td><?php echo e($payroll->lateHours); ?></td>
                <td><?php echo e($payroll->overTime); ?></td>
                <td><?php echo e($payroll->overTimeCommission); ?></td>
                <td><?php echo e($payroll->netSalary); ?></td>
                <td><?php echo e($payroll->coSec); ?></td>
                <td><?php echo e($payroll->pBalance); ?></td>
                <td><?php echo e($payroll->daybook); ?></td>
                <td><?php echo e($payroll->total); ?></td>
                <td><?php echo e($payroll->advanceDeduction); ?></td>
                <td><?php echo e($payroll->penalty); ?></td>
                <td><?php echo e($payroll->finalSalary); ?></td>
                <td><?php echo e($payroll->paySalary); ?></td>
                <td><?php echo e($payroll->signature); ?></td>
                <td><?php echo e($payroll->bLoan); ?></td>
                <td><?php echo e($payroll->totalSecurity); ?></td>
            </tr>


        </table>

    </div>

</div><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/components/single-payroll.blade.php ENDPATH**/ ?>