<?php $__env->startSection('title'); ?>
    Print DC
<?php $__env->stopSection(); ?>

<?php $__env->startSection('reportTitle'); ?>
    DC
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styling'); ?>
    <style>
        .highlight {
            font-size: 17px;
            font-weight: bold;
        }
        .topMargin {
            margin-top: 10px;
        }
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          <div class="table-responsive">
            
            <div>
                          
              <table style="margin-top: 20px;" class="table">

                  <tr>
                    <th>Sr No</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Unit</th>
                    <th>Quantity</th>
                    <th>Remarks</th>
                  </tr>

                  <?php $__currentLoopData = $dcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
                            
                            <td><?php echo e($dc->SrNo); ?></td>
							<td><?php echo e($dc->date); ?></td>
							<td><?php echo e($dc->description); ?></td>
							<td><?php echo e($dc->unit); ?></td>
							<td><?php echo e($dc->quantity); ?></td>
							<td><?php echo e($dc->remarks); ?></td>
							
						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </table>

            </div>


          </div>

          
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      <?php echo $__env->make('shared.main-print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

      <table style="margin-top: 20px;" class="table">

            <tr>
            <th>Sr No</th>
            <th>Date</th>
            <th>Description</th>
            <th>Unit</th>
            <th>Quantity</th>
            <th>Remarks</th>
            </tr>

            <?php $__currentLoopData = $dcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    
                    <td><?php echo e($dc->SrNo); ?></td>
                    <td><?php echo e($dc->date); ?></td>
                    <td><?php echo e($dc->description); ?></td>
                    <td><?php echo e($dc->unit); ?></td>
                    <td><?php echo e($dc->quantity); ?></td>
                    <td><?php echo e($dc->remarks); ?></td>
                    
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

      <?php $__env->startComponent('components.footer', ['flag'=>true]); ?>
      <?php echo $__env->renderComponent(); ?>

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripting'); ?>
  <script>
    
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/mainstore/dc/print.blade.php ENDPATH**/ ?>