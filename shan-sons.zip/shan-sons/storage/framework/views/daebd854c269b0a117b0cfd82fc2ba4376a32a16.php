<?php $__env->startSection('title'); ?>
	
	All Employees

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styling'); ?>
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('dashboard-content'); ?>

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Employee</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > HR > Employee > All Employees</p>
	</div>


	<?php $__env->startComponent('components.search-button'); ?>
		<a href="<?php echo e(route('employee.create')); ?>" class="btn btn-success">Add New Employee</a>
	<?php echo $__env->renderComponent(); ?>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    <?php if(count($employees) > 0): ?>
		    
		      <tr>
		      	<th>Employee No</th>
		      	<th>Name</th>
		      	<th>Date</th>
		      	<th>Mobile No</th>
		      	<th>Address</th>
		      	<th>Department</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							
							<td><?php echo e($employee->employeeNo); ?></td>
							<td><?php echo e($employee->name); ?></td>
							<td><?php echo e($employee->date); ?></td>
							<td><?php echo e($employee->mobileNo); ?></td>
							<td><?php echo e($employee->address); ?></td>
							<td><?php echo e($employee->department); ?></td>

							<td><a href="<?php echo e(route('employee.edit', ['id'=> $employee->id ])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#<?php echo e($employee->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							<?php $__env->startComponent('components.modal', ['obj'=>$employee]); ?>
								<form method="POST" action="<?php echo e(route('employee.destroy', ['id' => $employee->id ])); ?>">

									<?php echo method_field('delete'); ?>
									<?php echo csrf_field(); ?>

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							<?php echo $__env->renderComponent(); ?>

						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	</tbody>

		      <?php else: ?>
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    <?php endif; ?>  

		  </table>

		</div>
		
	</div>

	<?php $__env->startComponent('components.pagination', ['collection'=>$employees]); ?>
	<?php echo $__env->renderComponent(); ?>
	<!-- END MAIN DIV -->

	


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>
	
	<?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('shared.get-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/hr/employee/index.blade.php ENDPATH**/ ?>