<?php $__env->startSection('title'); ?>
    Payroll Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('reportTitle'); ?>
    Payroll Report
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('components.single-payroll', ['payroll'=>$payroll, 'responsiveClass'=>'table-responsive']); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="hidden">
        <div id="printDiv">
    
          <?php echo $__env->make('shared.main-print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
    
          <?php $__env->startComponent('components.single-payroll', ['payroll' => $payroll, 'responsiveClass'=>'']); ?>
          <?php echo $__env->renderComponent(); ?>

          <?php $__env->startComponent('components.footer', ['flag'=>false]); ?>
          <?php echo $__env->renderComponent(); ?>
    
        </div>
    </div>

    <div style="margin-top: 30px;" class="container">
        <div class="row">
          <div class=" col-md-4 ">
            <button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
          </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripting'); ?>
    <script>
      
        document.getElementById("doPrint").addEventListener("click", function() {
            var printContents = document.getElementById('printDiv').innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        });

  </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/accounts/payroll/show.blade.php ENDPATH**/ ?>