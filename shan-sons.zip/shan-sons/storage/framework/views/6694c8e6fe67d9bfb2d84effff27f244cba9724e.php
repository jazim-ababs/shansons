<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center" style="color:blue">SHAN SON'S ENGINEERING WORKS</h1>
            <h4 class="text-center">22 KM Ferouzpur Road Rohi Nala Near Ultra Chemical,Lahore</h4>
            <hr>
            <h4 class="text-center">S.T.Reg.No. 03-02-8708-127-46, N.T.N # 1519787-5</h4>
            <hr>
            <h3 class="text-center" style="color: blue"><?php echo $__env->yieldContent('reportTitle', 'Default Report'); ?></h3>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/shared/main-print.blade.php ENDPATH**/ ?>