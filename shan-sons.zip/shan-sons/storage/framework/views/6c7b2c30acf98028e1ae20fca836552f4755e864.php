
<div style="float: right; margin-right: 30px;">
    <?php echo e($collection->links()); ?>

</div><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/components/pagination.blade.php ENDPATH**/ ?>