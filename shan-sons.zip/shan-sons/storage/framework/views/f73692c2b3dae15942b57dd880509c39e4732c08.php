<?php $__env->startSection('title'); ?>
    Create Fuel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>

    <h1 class="page-header">
        Dashboard
        <small>Fuel</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Main Store > Fuel </p>
    </div>

    <div>
        
        <a href="#" data-toggle="modal" data-target="#1" class="btn btn-primary">Dsiaplay Fuel List</a>

        <!-- Modal for Deleting -->
        <div class="modal fade" id="1" role="dialog">
          <div class="modal-dialog">
          
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Display Fuel Record</h4>
              </div>
              <div class="modal-body">
                
                <form method="POST" action="<?php echo e(route('fuel.index')); ?>">
                    
                    <?php echo csrf_field(); ?>

                    <?php if(count($fuelCatagories) > 0): ?>  
                        <div class="form-group">
                          <label for="sel1">Select Fuel Catagory:</label>
                          <select class="form-control" id="sel1" name="fuelcatagory_id">
                            
                            <?php $__currentLoopData = $fuelCatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuelCatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($fuelCatagory->id); ?>"><?php echo e($fuelCatagory->fuelCatagory); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>
                        </div>

                        <input type="submit" class="btn btn-success" value="Submit">

                        <?php else: ?>
                            <p class="alert alert-danger">Please enter fuel catagory  <a style="margin-left: 15px;" href="<?php echo e(route('fuelcatagory.create')); ?>">Create New Fuel Catagory</a></p>

                    <?php endif; ?>  

                </form>

              </div>
              <div class="modal-footer">

                

                <a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
              </div>
            </div>
            
          </div>
        </div>

        <a href="<?php echo e(route('fuelcatagory.create')); ?>" class="btn btn-success">Add Fuel Catagory</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="<?php echo e(route('fuel.store')); ?>">

                    <?php echo csrf_field(); ?>

                    <?php if(count($fuelCatagories) > 0): ?>  
                        <div class="form-group">
                          <label for="sel1">Select Fuel Catagory:</label>
                          <select class="form-control" id="sel1" name="fuelcatagory_id">
                            
                            <?php $__currentLoopData = $fuelCatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuelCatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($fuelCatagory->id); ?>"><?php echo e($fuelCatagory->fuelCatagory); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>
                        </div>

                        <?php else: ?>
                            <p class="alert alert-danger">Please enter fuel catagory  <a style="margin-left: 15px;" href="<?php echo e(route('fuelcatagory.create')); ?>">Create New Fuel Catagory</a></p>

                    <?php endif; ?>  

                    <div class="form-group">
                        <label for="openingBalance">Opening Balance:</label>
                        <input type="number" class="form-control" id="openingBalance" name="openingBalance" value="<?php echo e(old('openingBalance')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="srNo">Sr No:</label>
                        <input type="number" class="form-control" id="srNo" name="srNo" value="<?php echo e(old('srNo')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Issue To:</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="uom">UOM:</label>
                        <input type="text" class="form-control" id="uom" name="uom" value="<?php echo e(old('uom')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="issue">Issue:</label>
                        <input type="date" class="form-control" id="issue" name="issue" value="<?php echo e(old('issue')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="received">Received:</label>
                        <input type="text" class="form-control" id="received" name="received" value="<?php echo e(old('received')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="balance">Balance:</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="<?php echo e(old('balance')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="total">Total:</label>
                        <input type="number" class="form-control" id="total" name="total" value="<?php echo e(old('total')); ?>">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    <?php echo $__env->make('/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    <?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/fuel/create.blade.php ENDPATH**/ ?>