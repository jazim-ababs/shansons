<!-- jQuery -->
<script src="<?php echo e(asset('admin/js/jquery.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/js/notify.js')); ?>"></script>


<script src="<?php echo e(asset('admin/js/loader.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/shared/script.blade.php ENDPATH**/ ?>