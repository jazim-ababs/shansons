<?php $__env->startSection('title'); ?>
	
	All Outward Gate Pass

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styling'); ?>
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('dashboard-content'); ?>

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Outward Gate Pass</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > Main Store > Outward Gate Pass > All Outward Pass</p>
	</div>


	<?php $__env->startComponent('components.search-button'); ?>
		<a href="/dn/create" class="btn btn-success">Add New Gate Pass</a>
	<?php echo $__env->renderComponent(); ?>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		 
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Date</th>
		      	<th>Description</th>
		      	<th>Unit</th>
		      	<th>Quantity</th>
		      	<th>Remarks</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					<?php $__currentLoopData = $dn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							
							<td><?php echo e($dns->SrNo); ?></td>
							<td><?php echo e($dns->date); ?></td>
							<td><?php echo e($dns->description); ?></td>
							<td><?php echo e($dns->unit); ?></td>
							<td><?php echo e($dns->quantity); ?></td>
							<td><?php echo e($dns->remarks); ?></td>
						
							<td><a href="/dn/<?php echo e($dns->id); ?>/edit" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#<?php echo e($dns->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							<div class="modal fade" id="<?php echo e($dns->id); ?>" role="dialog">
							<div class="modal-dialog">
							
								<!-- Modal content-->
								<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Delete</h4>
								</div>
								<div class="modal-body">
									<p>Are sure you want to delete this?</p>
								</div>
								<div class="modal-footer">

									<form method="POST" action="/dn/<?php echo e($dns->id); ?>">

										<?php echo method_field('DELETE'); ?>
										<?php echo csrf_field(); ?>

										<input type="submit" class="btn btn-success" value="Yes">
									</form>

									<a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
								</div>
								</div>
								
							</div>
							</div>

						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>


		  </table>

		</div>
		
	</div>

	<div style="margin-top: 20px">
		<a href="/dn/print" class="btn btn-primary">Print All</a>
	</div>

	<?php $__env->startComponent('components.pagination', ['collection'=>$dn]); ?>
	<?php echo $__env->renderComponent(); ?>	


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>
	
	<?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('shared.get-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/mainstore/demandnote/index.blade.php ENDPATH**/ ?>