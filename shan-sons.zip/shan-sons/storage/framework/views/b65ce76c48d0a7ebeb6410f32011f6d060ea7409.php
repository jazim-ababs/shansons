<?php $__env->startSection('title'); ?>
    EDIT GRN
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>

    <h1 class="page-header">
        Dashboard
        <small>GRN</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Main Store > GRN > EDIT GRN</p>
    </div>

    <div>
     

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form  method="POST" action="/dn/<?php echo e($dn->id); ?>">
                        <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="srNo">Serial Number:</label>
                        <input type="number" class="form-control" id="srNo" name="SrNo" value="<?php echo e($dn->SrNo); ?>">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e($dn->date); ?>">
                    </div>

                    <div class="form-group">
                        <label for="Description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" value="<?php echo e($dn->description); ?>">
                    </div>

                    <div class="form-group">
                        <label for="unit">Unit</label>
                        <input type="text" class="form-control" id="unit" name="unit" value="<?php echo e($dn->unit); ?>">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($dn->quantity); ?>">
                    </div>

                  
                     <div class="form-group">
                        <label for="amount">Remarks</label>
                        <input type="text" class="form-control" id="remarks" name="remarks" value="<?php echo e($dn->remarks); ?>">
                    </div>



                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Update">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

  

<?php $__env->stopSection(); ?>



<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/mainstore/demandnote/edit.blade.php ENDPATH**/ ?>