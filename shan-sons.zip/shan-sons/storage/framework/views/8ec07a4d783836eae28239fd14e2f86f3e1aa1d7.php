<div class="row">
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-2">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-8 col-md-offset-3">
                <?php $__env->startComponent('components.search'); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/components/search-button.blade.php ENDPATH**/ ?>