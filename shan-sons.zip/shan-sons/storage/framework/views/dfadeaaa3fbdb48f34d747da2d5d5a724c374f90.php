<?php $__env->startSection('title'); ?>
	
	All Payrolls

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styling'); ?>
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('dashboard-content'); ?>

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Payroll</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Payroll > All Record</p>
	</div>


	<?php $__env->startComponent('components.search-button'); ?>
		<a href="<?php echo e(route('payroll.create', ['empId' => $emp_id])); ?>" class="btn btn-success">Add New Payroll</a>
	<?php echo $__env->renderComponent(); ?>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    <?php if(count($payrolls) > 0): ?>
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Name</th>
		      	<th>Working Days</th>
		      	<th>Basic Salary</th>
		      	<th>Total Hours	</th>
		      	<th>Late Hours	</th>
		      	<th>Total Over Time	</th>
		      	<th>Over Time Commission</th>
		      	<th>Net Salary	</th>
		      	<th>Co. Section	</th>
		      	<th>P.Balance	</th>
		      	<th>Day Book</th>
		      	<th>Total</th>
		      	<th>Advance Dedication</th>
		      	<th>Penality</th>
		      	<th>Final Salary</th>
		      	<th>Pay Salary</th>
		      	<th>Signature</th>
		      	<th>B/Loan</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					<?php $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							
							<td><?php echo e($payroll->srNumber); ?></td>
							<td><?php echo e($payroll->employee->name); ?></td>
							<td><?php echo e($payroll->workingDays); ?></td>
							<td><?php echo e($payroll->basicSalary); ?></td>
							<td><?php echo e($payroll->totalHours); ?></td>
							<td><?php echo e($payroll->lateHours); ?></td>
							<td><?php echo e($payroll->overTime); ?></td>
							<td><?php echo e($payroll->overTimeCommission); ?></td>
							<td><?php echo e($payroll->netSalary); ?></td>
							<td><?php echo e($payroll->coSec); ?></td>
							<td><?php echo e($payroll->pBalance); ?></td>
							<td><?php echo e($payroll->daybook); ?></td>
							<td><?php echo e($payroll->total); ?></td>
							<td><?php echo e($payroll->advanceDeduction); ?></td>
							<td><?php echo e($payroll->penalty); ?></td>
							<td><?php echo e($payroll->finalSalary); ?></td>
							<td><?php echo e($payroll->paySalary); ?></td>
							<td><?php echo e($payroll->signature); ?></td>
							<td><?php echo e($payroll->bLoan); ?></td>

							<td><a href="<?php echo e(route('payroll.show', ['empId' => $emp_id, 'id' => $payroll->id ])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="<?php echo e(route('payroll.edit', ['empId' => $emp_id, 'id' => $payroll->id])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#<?php echo e($payroll->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							<?php $__env->startComponent('components.modal', ['obj'=>$payroll]); ?>
								<form method="POST" action="<?php echo e(route('payroll.destroy', ['empId' => $emp_id, 'id' => $payroll->id])); ?>">

									<?php echo method_field('delete'); ?>
									<?php echo csrf_field(); ?>

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							<?php echo $__env->renderComponent(); ?>

						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	</tbody>

		      <?php else: ?>
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    <?php endif; ?>  

		  </table>

		</div>
		
	</div>

	

	

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>
	
	<?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('shared.get-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/accounts/payroll/index.blade.php ENDPATH**/ ?>