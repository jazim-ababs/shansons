<?php $__env->startSection('title'); ?>
	Opening Page for Payroll
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styling'); ?>
	<style type="text/css">
		.someTopMargin {
			margin-top: 30px;
		}
	</style>
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('dashboard-content'); ?>

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Payroll</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Payroll</p>
	</div>

	<div>
		<a href="<?php echo e(route('employee.create')); ?>" class="btn btn-success">Add New Employee</a>
	</div>

	<div class="table-responsive someTopMargin">
		
		<table class="table table-hover">
			
			<tr>
				<th>ID</th>
				<th>Employee Name</th>
				<th>Create Payroll</th>
				<th>Display Payroll</th>
			</tr>	

			<?php if(count($employees) > 0): ?>

				<tbody id="myTable">
					<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							
							<td><?php echo e($employee->id); ?></td>
							<td><?php echo e($employee->name); ?></td>
							
							<td><a href="<?php echo e(route('payroll.create', ['id' => $employee->id])); ?>" class="btn btn-primary">Create Payroll</a></td>
                            <td><a href="" class="btn btn-success">Display Payroll</a></td>
                            
						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>

			<?php endif; ?>


		</table>

	</div>

	<!-- END MAIN DIV -->

	


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>
	
	<?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<script src="<?php echo e(asset('admin/js/search.js')); ?>"></script>
	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/accounts/payroll/open.blade.php ENDPATH**/ ?>