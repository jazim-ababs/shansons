<div class="text-center" <?php if($flag): ?> style="color: white; background-color: black" <?php endif; ?>>  
    &copy; 2019 <a href="https://www.softwarehubpro.com" <?php if($flag): ?> style="color: white" <?php endif; ?>>Software Hub Pro</a>. All Rights Reserved.
</div><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/components/footer.blade.php ENDPATH**/ ?>