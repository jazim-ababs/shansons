<?php $__env->startSection('title'); ?>
    Create Raw Material Store
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>

    <h1 class="page-header">
        Dashboard
        <small>Raw Material Store</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Raw Material Store > Create Record</p>
    </div>

    <div>
        
        <a href="<?php echo e(route('raw.index')); ?>" class="btn btn-primary">Dsiaplay All Record</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="<?php echo e(route('raw.store')); ?>">

                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="srNumber">Serial Number:</label>
                        <input type="number" class="form-control" id="srNumber" name="srNumber" value="<?php echo e(old('srNumber')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="uom">UOM:</label>
                        <input type="text" class="form-control" id="uom" name="uom" value="<?php echo e(old('uom')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="issue">Isssue:</label>
                        <input type="text" class="form-control" id="issue" name="issue" value="<?php echo e(old('issue')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description')); ?>">
                    </div>

                     <div class="form-group">
                        <label for="balance">Balance:</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="<?php echo e(old('balance')); ?>">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    <?php echo $__env->make('/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    <?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/store/rawmaterialstore/create.blade.php ENDPATH**/ ?>