<?php $__env->startSection('title'); ?>
	
	All Outward Gate Pass

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styling'); ?>
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('dashboard-content'); ?>

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Outward Gate Pass</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > Main Store > DC > All Record</p>
	</div>


	<?php $__env->startComponent('components.search-button'); ?>
		<a href="/dc/create" class="btn btn-success">Add New Record</a>
	<?php echo $__env->renderComponent(); ?>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		 
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Date</th>
		      	<th>Description</th>
		      	<th>Unit</th>
		      	<th>Quantity</th>
		      	<th>Remarks</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					<?php $__currentLoopData = $dc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dcs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							
							<td><?php echo e($dcs->SrNo); ?></td>
							<td><?php echo e($dcs->date); ?></td>
							<td><?php echo e($dcs->description); ?></td>
							<td><?php echo e($dcs->unit); ?></td>
							<td><?php echo e($dcs->quantity); ?></td>
							<td><?php echo e($dcs->remarks); ?></td>
						

							<td><a href="/dc/<?php echo e($dcs->id); ?>/edit" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#<?php echo e($dcs->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							<div class="modal fade" id="<?php echo e($dcs->id); ?>" role="dialog">
							<div class="modal-dialog">
							
								<!-- Modal content-->
								<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Delete</h4>
								</div>
								<div class="modal-body">
									<p>Are sure you want to delete this?</p>
								</div>
								<div class="modal-footer">

									<form method="POST" action="/dc/<?php echo e($dcs->id); ?>">

										<?php echo method_field('DELETE'); ?>
										<?php echo csrf_field(); ?>

										<input type="submit" class="btn btn-success" value="Yes">
									</form>

									<a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
								</div>
								</div>
								
							</div>
							</div>

						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>


		  </table>

		</div>
		
	</div>

	<div style="margin-top: 20px">
		<a href="/dc/print" class="btn btn-primary">Print All</a>
	</div>

	<?php $__env->startComponent('components.pagination', ['collection'=>$dc]); ?>
	<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>
	
	<?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('shared.get-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/mainstore/dc/index.blade.php ENDPATH**/ ?>