<!-- Bootstrap Core CSS -->
<link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo e(asset('admin/css/sb-admin.css')); ?>" rel="stylesheet">

<!-- Custom Fonts -->
<link href="<?php echo e(asset('admin/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">


<link rel="stylesheet" href="<?php echo e(asset('admin/css/loader.css')); ?>"><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/shared/style.blade.php ENDPATH**/ ?>