<?php $__env->startSection('title'); ?>
    Create GRN
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>

    <h1 class="page-header">
        Dashboard
        <small>GRN</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Main Store > DC > Create Record</p>
    </div>

    <div>
        
        <a href="/dc" class="btn btn-primary">Display All</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form  method="POST" action="/dc/create">

                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="srNo">Serial Number:</label>
                        <input type="number" class="form-control" id="SrNo" name="SrNo" value="<?php echo e(old('srNo')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="Description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="unit">Unit</label>
                        <input type="text" class="form-control" id="unit" name="unit" value="<?php echo e(old('unit')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e(old('quantity')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="rate">Remarks</label>
                        <input type="text" class="form-control" id="remarks" name="remarks" value="<?php echo e(old('remarks')); ?>">
                    </div>

                  



                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

   <?php echo $__env->make('/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripting'); ?>

    <?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/mainstore/dc/create.blade.php ENDPATH**/ ?>