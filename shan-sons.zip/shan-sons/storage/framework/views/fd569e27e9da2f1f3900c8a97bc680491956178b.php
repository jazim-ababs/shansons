<script>
    <?php if(count($errors) > 0): ?>
        $.notify('Something wrong \n Check the errors below the page ', 'error');
    <?php endif; ?>

    <?php if(Session::has('message')): ?>
    $.notify('<?php echo e(Session::get('message')); ?>', '<?php echo e(Session::get('alert-class')); ?>');
    <?php endif; ?>
</script><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/shared/notification.blade.php ENDPATH**/ ?>