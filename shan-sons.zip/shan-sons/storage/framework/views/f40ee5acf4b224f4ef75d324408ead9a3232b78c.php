<?php $__env->startSection('title'); ?>
    Edit Payroll
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>

    <h1 class="page-header">
        Dashboard
        <small>Payroll</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Payroll > Edit Payroll</p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="<?php echo e(route('payroll.update', ['empId' => $payroll->employee->id, 'id' => $payroll->id])); ?>">

                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="employee_id" value="<?php echo e($payroll->employee_id); ?>">

                    <div class="form-group">
                        <label for="srNumber">Serial Number:</label>
                        <input type="number" class="form-control" id="srNumber" name="srNumber" value="<?php echo e($payroll->srNumber); ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Employee Name:</label>
                        <input readonly type="text" class="form-control" id="name" name="name" value="<?php echo e($payroll->employee->name); ?>">
                    </div>

                    <div class="form-group">
                        <label>Date</label>
                        <input type="month" name="date" value="<?php echo e($payroll->date); ?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="basicSalary">Basic Salary:</label>
                        <input type="number" class="form-control" id="basicSalary" name="basicSalary" value="<?php echo e($payroll->basicSalary); ?>">
                    </div>

                    <div class="form-group">
                        <label for="workingDays">Working Days:</label>
                        <input type="number" class="form-control" id="workingDays" name="workingDays" value="<?php echo e($payroll->workingDays); ?>">
                    </div>

                    <div class="form-group">
                        <label for="totalHours">Total Hours:</label>
                        <input type="number" class="form-control" id="totalHours" name="totalHours" value="<?php echo e($payroll->totalHours); ?>">
                    </div>

                    <div class="form-group">
                        <label for="lateHours">Late Hours:</label>
                        <input type="number" class="form-control" id="lateHours" name="lateHours" value="<?php echo e($payroll->lateHours); ?>">
                    </div>

                    <div class="form-group">
                        <label for="coSec">Co Sec:</label>
                        <input type="number" class="form-control" id="coSec" name="coSec" value="<?php echo e($payroll->coSec); ?>">
                    </div>

                    <div class="form-group">
                        <label for="pBalance">P.Balance:</label>
                        <input type="number" class="form-control" id="pBalance" name="pBalance" value="<?php echo e($payroll->pBalance); ?>">
                    </div>

                    <div class="form-group">
                        <label for="daybook">Daybook:</label>
                        <input type="text" class="form-control" id="daybook" name="daybook" value="<?php echo e($payroll->daybook); ?>">
                    </div>

                    <div class="form-group">
                        <label for="advanceDeduction">Advance Deduction:</label>
                        <input type="number" class="form-control" id="advanceDeduction" name="advanceDeduction" value="<?php echo e($payroll->advanceDeduction); ?>">
                    </div>

                    <div class="form-group">
                        <label for="penalty">Penalty:</label>
                        <input type="number" class="form-control" id="penalty" name="penalty" value="<?php echo e($payroll->penalty); ?>">
                    </div>

                    <div class="form-group">
                        <label for="signature">Signature:</label>
                        <input type="text" class="form-control" id="signature" name="signature" value="<?php echo e($payroll->signature); ?>">
                    </div>

                    <div class="form-group">
                        <label for="bLoan">B/Loan:</label>
                        <input type="number" class="form-control" id="bLoan" name="bLoan" value="<?php echo e($payroll->bLoan); ?>">
                    </div>

                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    <?php echo $__env->make('/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripting'); ?>


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    <?php echo $__env->make('shared.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('/admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shan-sons\resources\views/admin/accounts/payroll/edit.blade.php ENDPATH**/ ?>