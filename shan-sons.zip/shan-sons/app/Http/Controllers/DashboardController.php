<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,accountsKeeper,storeKeeper,gateKeeper');
    }

    public function dashboard()
    {
    	return view('admin.dashboard.main');
    }

    public function store()
    {
    	return view('admin.dashboard.store');
    }

    public function mainstore()
    {
    	return view('admin.dashboard.mainstore');
    }

    public function fuel()
    {
    	return view('admin.dashboard.fuel');
    }

    public function accounts()
    {
    	return view('admin.dashboard.accounts');
    }

    public function hr()
    {
        return view('admin.dashboard.hr');
    }
}
