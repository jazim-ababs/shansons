<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Mail;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class MailController extends Controller
{

	public function html_email() {
	      $data = array('name'=>"Rana jazim abbas");
	      Mail::send('mail', $data, function($message) {
	         $message->to('exampleme87@gmail.com', 'Tutorials Point')->subject
	            ('Laravel HTML Testing Mail');
	         $message->from('ranajazim87@gmail.com','Rana jazim Abbas');
	      });
	      echo "Check your inbox.";
	  }

    public function attachment_email() {
      $data = array('name'=>"Rana JAzim Abbas");
      Mail::send('mail', $data, function($message) {
         $message->to('exampleme87@gmail.com', 'Tutorials Point')->subject
            ('Laravel Testing Mail with Attachment');
         $message->attach('M:\Images\coding.jpg');
         $message->from('ranajazim87@gmail.com','Virat Gandhi');
      });
      echo "Email Sent with attachment. Check your inbox.";
   }
}
