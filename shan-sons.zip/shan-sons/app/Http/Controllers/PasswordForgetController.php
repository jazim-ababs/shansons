<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Mail;

class PasswordForgetController extends Controller
{
    public function reset()
    {
        return view('forget_password');
    }

    public function send_link(Request $request, Notification $notification)
    {
        $request->validate([
            'email' => 'required'
        ]);

        $email = $request->email;
        $user = User::where('email', '=', $email)->first();

        if (!$user)
        {
            $notification->createNotication('This is not the valid email!', 'error');
            return redirect()->back();
        }

        $token = md5(time() .$email .$user->password);
        $data = array('name' => $user->name, 'confirm_token' => $token);
        Mail::send('mail', $data, function($message) use($email) {
            $message->to($email)->subject('From Shan Sons');
            $message->from('ranajazim87@gmail.com', 'Rana Jazim Abbas');
        });

        $user->token = $token;
        $user->save();

        $notification->createNotication('Please Check your inbox! \nWe have e-mailed you reset-password-link', 'success');
        return redirect()->back();
    }

    public function setPassword($confirmation_token)
    {
        return view('setPassword', compact('confirmation_token'));
    }

    public function update(Request $request, Notification $notification)
    {
        $request->validate([
            'token' => 'required',
            'password' => ['required', 'confirmed', 'min:8'],
            'password_confirmation' => 'required'
        ]);

        $user = User::whereToken($request->token)->first();

        if (!$user || $user->token != $request->token)
        {
            $notification->createNotication('This is not the valid token \n
            Again Click the reset button from your email or \n
            Again Click on the Reset Password link', 'error');

            return redirect()->back();
        }

        $user->password = Hash::make($request->password);
        $token = md5(time() .$request->email .$user->password);
        $user->token = $token;
        $user->save();

        return redirect('/login');
    }

}
