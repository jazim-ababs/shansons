<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use Illuminate\Http\Request;

use App\Gate;

class GateController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,gateKeeper');
	}	

    public function index()
    {
    	$gates = Gate::paginate(config('settings.pages'));

    	return view('admin.gate.index', compact('gates'));
    }


	public function create()
	{
		return view('admin.gate.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$date = date('Y-m-d');

		if ($request->date != $date)
		{
			$notification->createNotication('Sorry you are not allowed to take this action', 'error');

			return redirect()->back();
		}

		$attributes = $this->validation($request);
		Gate::create($attributes);
		
		$notification->createNotication('Successfully created the gate!', 'success');
        return redirect()->back();
	}


	public function edit($id)
	{
		$gate = Gate::findOrFail($id);

		return view('admin.gate.edit', compact('gate'));
	}


	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request, $id);
		$gate = Gate::findOrFail($id);

		$gate->update($attributes);
		return redirect()->route('gate.index');
	}


	public function destroy($id, Notification $notification)
	{
		Gate::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the gate!', 'success');

        return redirect()->back();
	}


	public function single($id)
	{
		$gate = Gate::findOrFail($id);

		return view('admin.gate.print', compact('gate'));
	}


	public function printAll()
	{
		$gates = Gate::paginate(7);

		return view('admin.gate.printall', compact('gates'));
	}


	private function validation($values, $id = 0)
	{
		return $values->validate([
			'srNumber' => 'required',
			'date' => 'required',
			'timing' => 'required',
			'name' => 'required',
			'vehicleNumber' => 'required',
			'contactInfo' => 'required',
			'description' => 'required',
			'quantity' => 'required',
		]);
	}

}
