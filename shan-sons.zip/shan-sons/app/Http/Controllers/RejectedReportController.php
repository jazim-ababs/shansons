<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use App\Rejectedreport;
use Illuminate\Http\Request;

class RejectedReportController extends Controller
{
    public function index()
    {
        $reports = Rejectedreport::paginate(config('settings.pages'));

        return view('admin.report.index', compact('reports'));
    }
    
    public function create()
    {
        return view('admin.report.create');
    }

    public function store(Request $request, Notification $notification)
    {
        $attributes = $this->validation($request);
        Rejectedreport::create($attributes);

        $notification->createNotication('Successfully created the record', 'success');
        return redirect()->back();
    }

    public function edit($id)
    {
        $report = Rejectedreport::findOrFail($id);

        return view('admin.report.edit', compact('report'));
    }

    public function update(Request $request, $id)
    {
        $attributes = $this->validation($request);
        $report = Rejectedreport::findOrFail($id);

        $report->update($attributes);
        return redirect()->route('rejectedReport.index');
    }

    public function destroy($id, Notification $notification)
    {
        Rejectedreport::findOrFail($id)->delete();
        $notification->createNotication('Successfully deleted the record', 'success');

        return redirect()->back();
    }

    private function validation($values)
    {
        return $values->validate([
            'partyname' => 'required',
            'totalBalance' => 'required',
            'description' => 'required',
            'process' => 'required',
            'workerName' => 'required',
            'checkBy' => 'required',
            'balance' => 'required',
        ]);
    }

}
