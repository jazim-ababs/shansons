<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\GRN;

class GrnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $grn = GRN::paginate(config('settings.pages'));
        //dd($employees);
        return view('admin.mainstore.grn.index', compact('grn'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.mainstore.grn.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Notification $notification)
    {
        GRN::validation($request);

        // GRN::create(request(['SrNo','date','description','unit','quantity','rate','amount']));
        GRN::create([
           'SrNo'=>request('SrNo'),
           'date'=>request('date'),
           'description'=>request('description'),
           'unit'=>request('unit'),
           'quantity'=>request('quantity'),
            'rate'=>request('rate'),
           'amount'=>request('amount')
            

               ]);

        $notification->createNotication('Successfully created the record', 'success');
        return back();
    }

    public function print()
    {
        $grns = GRN::all();

        return view('admin.mainstore.grn.print', compact('grns'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $grn = GRN::find($id);
        return view('admin.mainstore.grn.edit', compact('grn'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $grn = GRN::findOrFail($id);
         $grn->SrNo = request('SrNo');
         $grn->date = request('date');
         $grn->description = request('description');
         $grn->unit = request('unit');
         $grn->rate = request('rate');
         $grn->amount = request('amount');
         $grn->save();
        return redirect('/grn');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Notification $notification)
    {  
        GRN::findOrFail($id)->delete();

        $notification->createNotication('Successfully deleted the record', 'success');
        return back();
    }
}
