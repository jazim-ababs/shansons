<?php

namespace App\Http\Controllers\Fuel;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\FuelModel\Cuttingoil;

class CuttingoilController extends Controller
{
    public function index()
	{
		$cuttingoils = Cuttingoil::all();

		return view('admin.fuel.cuttingoil.index', compact('cuttingoils'));
	}


	public function create()
	{
		return view('admin.fuel.cuttingoil.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$attributes = $this->validation($request);
		Cuttingoil::create($attributes);

		$notification->createNotication('Successfully created the petrole!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$cuttingoil = Cuttingoil::findOrFail($id);

		return view('admin.fuel.cuttingoil.edit', compact('cuttingoil'));
	}


	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request);
		$cuttingoil = Cuttingoil::findOrFail($id);

		$cuttingoil->update($attributes);
		return redirect()->route('cuttingoil.index');
	}


	public function destroy($id, Notification $notification)
	{
		Cuttingoil::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the petrole!', 'success');
		
		return redirect()->back();
	}


	public function singleprint($id)
	{
		$cuttingoil = Cuttingoil::findOrFail($id);

		return view('admin.fuel.cuttingoil.print', compact('cuttingoil'));
	}


	private function validation($values)
	{
		return $values->validate([
			'openingBalance' => 'required',
			'srNo' => 'required',
			'name' => 'required',
			'description' => 'required',
			'uom' => 'required',
			'issue' => 'required',
			'received' => 'required',
			'balance' => 'required',
			'total' => 'required',
		]);
	}
}
