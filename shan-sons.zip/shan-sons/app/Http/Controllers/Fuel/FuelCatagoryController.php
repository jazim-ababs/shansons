<?php

namespace App\Http\Controllers\Fuel;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\FuelModel\Fuelcatagory;

class FuelCatagoryController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }

	public function index()
	{
		$fuelCatagories = Fuelcatagory::all();

		return view('admin.fuel.fuelcatagory.index', compact('fuelCatagories'));		
	}

    
	public function create()
	{
		return view('admin.fuel.fuelcatagory.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$attibutes = $this->validation($request);
		Fuelcatagory::create($attibutes);

		$notification->createNotication('Successfully created the fuel catagory!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$fuelCatagory = Fuelcatagory::findOrFail($id);

		return view('admin.fuel.fuelcatagory.edit', compact('fuelCatagory'));
	}


	public function update(Request $request, $id)
	{
		$attibutes = $this->validation($request, $id);
		$fuelCatagory = Fuelcatagory::findOrFail($id);

		$fuelCatagory->update($attibutes);
		return redirect()->route('fuelcatagory.index');
	}


	public function destroy($id, Notification $notification)
	{
		Fuelcatagory::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the fuel catagory!', 'success');

		return redirect()->back();
	}


	private function validation($values, $id = 0)
	{
		return $values->validate([
			'fuelCatagory' => 'required|unique:fuelcatagories,fuelCatagory,'.$id
		]);
	}

}
