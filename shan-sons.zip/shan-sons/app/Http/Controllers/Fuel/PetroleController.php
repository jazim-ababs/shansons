<?php

namespace App\Http\Controllers\Fuel;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Session;
use App\FuelModel\Petrole;

class PetroleController extends Controller
{
    
	public function index()
	{
		$petroles = Petrole::all();

		return view('admin.fuel.petrole.index', compact('petroles'));
	}


	public function create()
	{
		return view('admin.fuel.petrole.create');
	}


	public function store(Request $request)
	{
		$attributes = $this->validation($request);
		Petrole::create($attributes);

		Session::flash('message', 'Successfully created the petrole!'); 
		Session::flash('alert-class', 'success');

		return redirect()->back();
	}


	public function edit($id)
	{
		$petrole = Petrole::findOrFail($id);

		return view('admin.fuel.petrole.edit', compact('petrole'));
	}


	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request);
		$petrole = Petrole::findOrFail($id);

		$petrole->update($attributes);
		return redirect()->route('petrole.index');
	}


	public function destroy($id)
	{
		Petrole::findOrFail($id)->delete();

		Session::flash('message', 'Successfully deleted the petrole!'); 
		Session::flash('alert-class', 'success');

		return redirect()->back();
	}


	public function singleprint($id)
	{
		$petrole = Petrole::findOrFail($id);

		return view('admin.fuel.petrole.print', compact('petrole'));
	}


	private function validation($values)
	{
		return $values->validate([
			'openingBalance' => 'required',
			'srNo' => 'required',
			'name' => 'required',
			'description' => 'required',
			'uom' => 'required',
			'issue' => 'required',
			'received' => 'required',
			'balance' => 'required',
			'total' => 'required',
		]);
	}

}
