<?php

namespace App\Http\Controllers\Fuel;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\FuelModel\Fuelcatagory;
use App\FuelModel\Fuel;

class FuelController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }

	public function index(Request $request)
	{
        $request->validate([
            'fuelcatagory_id' => 'required'
        ]);


        $fuelCatagory = Fuelcatagory::findOrFail($request->fuelcatagory_id);
        $fuels = $fuelCatagory->fuels()->paginate(config('settings.pages'));

        $catagoryName = $fuelCatagory->fuelCatagory;

        return view('admin.fuel.index', compact('fuels', 'catagoryName'));
	}


    public function create()
    {
    	$fuelCatagories = Fuelcatagory::all();

    	return view('admin.fuel.create', compact('fuelCatagories'));
    }


    public function store(Request $request, Notification $notification)
    {
    	$attributes = $this->validation($request);
    	Fuel::create($attributes);

        $notification->createNotication('Successfully created the petrole', 'success');
		return redirect()->back();
    }


    public function edit($id)
    {
        $fuel = Fuel::findOrFail($id);
        $fuelCatagories = Fuelcatagory::all();

        return view('admin.fuel.edit', compact('fuel', 'fuelCatagories'));
    }


    public function update(Request $request, $id)
    {
        $attributes = $this->validation($request);
        $fuel = Fuel::findOrFail($id);

        $fuel->update($attributes);
        return redirect()->route('fuel.create');
    }


    public function destroy($id)
    {
        Fuel::findOrFail($id)->delete();

        return redirect()->route('fuel.create');
    }


    public function singleprint($id)
    {
        $fuel = Fuel::findOrFail($id);

        return view('admin.fuel.print', compact('fuel'));
    }


    private function validation($values)
    {
    	return $values->validate([
    		'fuelcatagory_id' => 'required',
    		'openingBalance' => 'required',
			'srNo' => 'required',
			'name' => 'required',
			'description' => 'required',
			'uom' => 'required',
			'issue' => 'required',
			'received' => 'required',
			'balance' => 'required',
			'total' => 'required',
    	]);
    }

}
