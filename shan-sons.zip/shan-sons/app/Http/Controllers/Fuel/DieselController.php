<?php

namespace App\Http\Controllers\Fuel;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\FuelModel\Diesel;

class DieselController extends Controller
{
    public function index()
	{
		$diesels = Diesel::all();

		return view('admin.fuel.diesel.index', compact('diesels'));
	}


	public function create()
	{
		return view('admin.fuel.diesel.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$attributes = $this->validation($request);
		Diesel::create($attributes);

		$notification->createNotication('Successfully created the diesel!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$diesel = Diesel::findOrFail($id);

		return view('admin.fuel.diesel.edit', compact('diesel'));
	}


	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request);
		$diesel = Diesel::findOrFail($id);

		$diesel->update($attributes);
		return redirect()->route('diesel.index');
	}


	public function destroy($id, Notification $notification)
	{
		Diesel::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the diesel!', 'success');

		return redirect()->back();
	}


	public function singleprint($id)
	{
		$diesel = Diesel::findOrFail($id);

		return view('admin.fuel.diesel.print', compact('diesel'));
	}


	private function validation($values)
	{
		return $values->validate([
			'openingBalance' => 'required',
			'srNo' => 'required',
			'name' => 'required',
			'description' => 'required',
			'uom' => 'required',
			'issue' => 'required',
			'received' => 'required',
			'balance' => 'required',
			'total' => 'required',
		]);
	}
}
