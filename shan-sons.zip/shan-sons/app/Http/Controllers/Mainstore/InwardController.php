<?php

namespace App\Http\Controllers\Mainstore;

use App\Custom\Notification;
use App\Custom\Price;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\MainstoreModel\Inward;

class InwardController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }

	public function index()
	{
		$inwards = Inward::paginate(config('settings.pages'));

		return view('admin.mainstore.inward.index', compact('inwards'));
	}

    
	public function create()
	{
		return view('admin.mainstore.inward.create');
	}


	public function store(Request $request, Notification $notification, Price $price) 
	{
		$attributes = $this->validation($request);

		$attributes['price'] = $price->getPrice($attributes);
		Inward::create($attributes);

		$notification->createNotication('Successfully created the inward!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$inward = Inward::findOrFail($id);

		return view('admin.mainstore.inward.edit', compact('inward'));
	}


	public function update(Request $request, $id, Price $price)
	{
		$attributes = $this->validation($request);
		$attributes['price'] = $price->getPrice($attributes);

		$inward = Inward::findOrFail($id);

		$inward->update($attributes);
		return redirect()->route('inward.index');
	}


	public function show($id)
	{
		$inward = Inward::findOrFail($id);

		return view('admin.mainstore.inward.show', compact('inward'));
	}


	public function destroy($id, Notification $notification)
	{
		Inward::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the inward!', 'success');

		return redirect()->back();
	}



	private function validation($values)
	{
		return $values->validate([
			'srNumber' => 'required',
			'date' => 'required',
			'partyName' => 'required',
			'vehicleNumber' => 'required',
			'byHand' => 'required',
			'description' => 'required',
			'unit' => 'required',
			'quantity' => 'required',
			'box' => 'required',
		]);
	}

}
