<?php

namespace App\Http\Controllers\Mainstore;

use App\Custom\Notification;
use App\Custom\Price;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\MainstoreModel\Returnable;

class ReturnableController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }

	public function index()
	{
		$outwards = Returnable::paginate(config('settings.pages'));

		return view('admin.mainstore.returnable.index', compact('outwards'));
	}

    
	public function create()
	{
		return view('admin.mainstore.returnable.create');
	}


	public function store(Request $request, Notification $notification, Price $price) 
	{
		$attributes = $this->validation($request);
		$attributes['price'] = $price->getPrice($attributes);

		Returnable::create($attributes);

		$notification->createNotication('Successfully created the outward returnable!', 'success');
		return redirect()->back();
	}


	public function show($id)
	{
		$outward = Returnable::findOrFail($id);

		return view('admin.mainstore.returnable.show', compact('outward'));
	}


	public function edit($id)
	{
		$outward = Returnable::findOrFail($id);

		return view('admin.mainstore.returnable.edit', compact('outward'));
	}


	public function update(Request $request, $id, Price $price)
	{
		$attributes = $this->validation($request);
		$attributes['price'] = $price->getPrice($attributes);

		$outward = Returnable::findOrFail($id);

		$outward->update($attributes);
		return redirect()->route('returnable.index');
	}


	public function destroy($id, Notification $notification)
	{
		Returnable::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the outward returnable!', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([
			'srNumber' => 'required',
			'date' => 'required',
			'partyName' => 'required',
			'vehicleNumber' => 'required',
			'byHand' => 'required',
			'description' => 'required',
			'unit' => 'required',
			'quantity' => 'required',
			'box' => 'required',
		]);
	}
}
