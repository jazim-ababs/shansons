<?php

namespace App\Http\Controllers\Mainstore;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\MainstoreModel\Inventory;

class InventoryController extends Controller
{
    public function index()
    {
        $inventories = Inventory::paginate(config('settings.pages'));
        
        return view('admin.mainstore.inventory.index', compact('inventories'));
    }

    public function print()
    {
        $inventories = Inventory::all();

        return view('admin.mainstore.inventory.print', compact('inventories'));
    }

    public function create()
    {
        return view('admin.mainstore.inventory.create');
    }

    public function store(Request $request, Notification $notification)
    {
        $attributes = $this->validation($request);
        $attributes['balance'] = $this->calculation($attributes);

        Inventory::create($attributes);

        $notification->createNotication('Successfully created the inventory', 'success');
        return redirect()->back();
    }

    public function edit($id)
    {
        $inventory = Inventory::findOrFail($id);

        return view('admin.mainstore.inventory.edit', compact('inventory'));
    }

    public function update(Request $request, $id)
    {
        $attributes = $this->validation($request);
        $attributes['balance'] = $this->calculation($attributes);

        $inventory = Inventory::findOrFail($id);
        $inventory->update($attributes);

        return redirect()->route('inventory.index');
    }

    public function destroy($id, Notification $notification)
    {
        Inventory::findOrFail($id)->delete();
        $notification->createNotication('Successfully deleted the inventory', 'success');

        return redirect()->back();
    }

    private function calculation($values)
    {
        $balance = $values['quantity'] - $values['issue'];
        return $balance + $values['return'];
    }

    private function validation($values)
    {
        return $values->validate([
            'srNumber' => 'required',
            'date' => 'required',
            'description' => 'required',
            'quantity' => 'required',
            'issue' => 'required',
            'return' => 'required',
        ]);
    }


}
