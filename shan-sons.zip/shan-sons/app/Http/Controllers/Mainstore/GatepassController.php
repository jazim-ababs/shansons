<?php

namespace App\Http\Controllers\Mainstore;

use App\Custom\Notification;
use App\Custom\Price;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\MainstoreModel\Gatepass;

class GatepassController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }

    public function index()
	{
		$outwards = Gatepass::paginate(config('settings.pages'));

		return view('admin.mainstore.gatepass.index', compact('outwards'));
	}

    
	public function create()
	{
		return view('admin.mainstore.gatepass.create');
	}


	public function store(Request $request, Notification $notification, Price $price) 
	{
		$attributes = $this->validation($request);
		$attributes['price'] = $price->getPrice($attributes);

		Gatepass::create($attributes);

		$notification->createNotication('Successfully created the outward gate pass!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$outward = Gatepass::findOrFail($id);

		return view('admin.mainstore.gatepass.edit', compact('outward'));
	}


	public function show($id)
	{
		$gatePass = Gatepass::findOrFail($id);

		return view('admin.mainstore.gatepass.show', compact('gatePass'));
	}


	public function update(Request $request, $id, Price $price)
	{
		$attributes = $this->validation($request);
		$outward = Gatepass::findOrFail($id);
		$attributes['price'] = $price->getPrice($attributes);

		$outward->update($attributes);
		return redirect()->route('gatepass.index');
	}


	public function destroy($id, Notification $notification)
	{
		Gatepass::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the outward gate pass!', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([
			'srNumber' => 'required',
			'date' => 'required',
			'partyName' => 'required',
			'vehicleNumber' => 'required',
			'byHand' => 'required',
			'description' => 'required',
			'unit' => 'required',
			'quantity' => 'required',
			'box' => 'required',
		]);
	}
}
