<?php

namespace App\Http\Controllers\Partyname;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\PartynameModel\Salename;
use App\PartynameModel\Sale;

class SaleController extends Controller
{
    public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}


    public function index($salenameID)
    {
        $sales = Salename::findOrFail($salenameID)->sales()->paginate(config('settings.pages'));

        return view('admin.accounts.sale.index', compact('sales'));
    }


    public function createpage()
    {
    	$salenames = Salename::all();

    	return view('admin.accounts.sale.createpage', compact('salenames'));
    }


    public function create($salenameID)
    {
    	$salename = Salename::findOrFail($salenameID);

    	return view('admin.accounts.sale.create', compact('salename'));
    }


    public function store(Request $request, $salenameID, Notification $notification)
    {
        $attributes = $this->validation($request);
        $attributes['amount'] = $attributes['quantity'] * $attributes['unitPrice'];
        $attributes['totalInvoiceAmount'] = ($attributes['balance'] * 100)/$attributes['amount'];
        Sale::create($attributes);

        $notification->createNotication('Successfully created the sale!', 'success');
        return redirect()->back();
    }


    public function edit($salenameID, $id)
    {
        $sale = Sale::findOrFail($id);

        return view('admin.accounts.sale.edit', compact('sale'));
    }


    public function update(Request $request, $salenameID, $id)
    {
        $attributes = $this->validation($request);
        $sale = Sale::findOrFail($id);

        $attributes['amount'] = $attributes['quantity'] * $attributes['unitPrice'];
        $attributes['totalInvoiceAmount'] = ($attributes['balance'] * 100)/$attributes['amount'];

        $sale->update($attributes);
        return redirect()->route('sale.index', ['salenameId' => $salenameID]);
    }


    public function show($salenameID, $id)
    {
        $sale = Sale::findOrFail($id);

        return view('admin.accounts.sale.show', compact('sale'));
    }


    public function destroy($salenameID, $id, Notification $notification)
    {
        Sale::findOrFail($id)->delete();
        $notification->createNotication('Successfully deleted the sale!', 'success');

        return redirect()->back();
    }


    private function validation($values)
    {
        return $values->validate([
            'salename_id' => 'required',
            'invoiceNo' => 'required',
            'invoiceDate' => 'required',
            'customerId' => 'required',
            'customerPro' => 'required',
            'paymentTerms' => 'required',
            'salesRepId' => 'required',
            'shippingMethod' => 'required',
            'shipDate' => 'required',
            'dueDate' => 'required',
            'quantity' => 'required',
            'item' => 'required',
            'description' => 'required',
            'unitPrice' => 'required',
            'amount' => 'required',
            'balance' => 'required',
            'totalInvoiceAmount' => 'required',
            'credit' => 'required',
        ]);
    }

}
