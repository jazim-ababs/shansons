<?php

namespace App\Http\Controllers\Partyname;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\PartynameModel\Salename;

class SaleNameController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}


    public function index()
    {
    	$salenames = Salename::paginate(config('settings.pages'));

    	return view('admin.accounts.salename.index', compact('salenames'));
    }


	public function create()
	{
		return view('admin.accounts.salename.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$attributes = $this->validation($request);
		Salename::create($attributes);

		$notification->createNotication('Successfully created the salename!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$salename = Salename::findOrFail($id);

		return view('admin.accounts.salename.edit', compact('salename'));
	}


	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request, $id);
		$salename = Salename::findOrFail($id);

		$salename->update($attributes);
		return redirect()->route('salename.index');
	}


	public function destroy($id, Notification $notification)
	{
		Salename::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the salename!', 'success');

		return redirect()->back();
	}	


	private function validation($values, $id = 0)
	{
		return $values->validate([
			'name' => 'required|unique:salenames,name,'.$id,
			'mobileNumber' => 'required|regex:/(03)[0-9]{9}/|max:11',
		]);
	}

}
