<?php

namespace App\Http\Controllers\Partyname;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Custom\DaybookRecord;
use App\Custom\Notification;
use App\PartynameModel\Expense;

class ExpensesController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}

	public function createpage()
	{
		return view('admin.accounts.expenses.createpage');
	}


	public function createExpenses(Request $request, DaybookRecord $daybooRecord, Notification $notification)
	{
		
		if (!$this->isRecordExists($request->date)) {

			$daybooRecord->setRecord($request->date);

			$date = $request->date;
			$advanceSalary = $daybooRecord->getAdvanceSalary();
			$entertainment = $daybooRecord->getEntertainment();
			$fuelExpense = $daybooRecord->getFuelExpense();
			$repair = $daybooRecord->getRepairMaintainence();
			$otherExpenses = $daybooRecord->getOtherExpenses();

			// dd($date);

			return view('admin.accounts.expenses.create', compact('date', 'advanceSalary', 'entertainment', 'fuelExpense', 'repair', 'otherExpenses'));

		} else {

			$notification->createNotication('Expenses already created for this date!', 'error');

			return redirect()->back();
		}

		

	} //-- ends function --//

	public function index()
	{
		$expenses = Expense::paginate(config('settings.pages'));

		return view('admin.accounts.expenses.index', compact('expenses'));
	}


	public function store(Request $request, Notification $notification)
	{
		$attributes = $this->validation($request);
		Expense::create($attributes);

		$notification->createNotication('Successfully created the expenses!', 'success');
		return redirect()->back();
	}


	public function print($id)
	{
		$expense = Expense::findOrFail($id);

		return view('admin.accounts.expenses.show', compact('expense'));
	}


	public function edit($id)
	{
		$expense = Expense::findOrFail($id);

		return view('admin.accounts.expenses.edit', compact('expense'));
	}

	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request);
		$expense = Expense::findOrFail($id);

		$expense->update($attributes);
		return redirect()->route('expenses.index');
	}

	public function destroy($id, Notification $notification)
	{
		Expense::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the expenses!', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([

			'date' => 'required',
			'advanceSalary' => 'required',
			'entertainment' => 'required',
			'fuelExpenses' => 'required',
			'repairAndMain' => 'required',
			'courier' => 'required',
			'eob' => 'required',
			'accessories' => 'required',
			'billFactory' => 'required',
			'freight' => 'required',
			'hardware' => 'required',
			'home' => 'required',
			'lunch' => 'required',
			'rent' => 'required',
			'lubricantDiesel' => 'required',
			'officeExpenses' => 'required',
			'paint' => 'required',
			'fuelToolPlaza' => 'required',
			'rawMaterial' => 'required',
			'taxes' => 'required',
			'installment' => 'required',
			'services' => 'required',
			'socialSecurity' => 'required',
			'incomeTax' => 'required',

		]);
	}


	private function isRecordExists($date)
	{
		$flag = false;

		if (Expense::where('date', '=', $date)->exists() ) {
			$flag = true;
		}

		return $flag;		
	}



}
