<?php

namespace App\Http\Controllers\Partyname;

use App\Custom\CustomPayroll;
use App\Custom\Notification;
use App\HrModel\Employee;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\PartynameModel\Payroll;

class PayRollController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}
	
	public function index($emp_id)
	{
		$payrolls = Employee::findOrFail($emp_id)->payrolls;

		return view('admin.accounts.payroll.index', compact('payrolls', 'emp_id'));
	}


	public function print()
	{
		$payrolls = Payroll::all();

		return view('admin.accounts.payroll.print', compact('payrolls'));
	}


	public function open()
	{
		$employees = Employee::all();

		return view('admin.accounts.payroll.open', compact('employees'));
	}

	public function create($emp_id)
	{
		$employee = Employee::findOrFail($emp_id);
		$loan = Payroll::where('employee_id', $emp_id)
						->orderBy('updated_at', 'desc')
						->first();
		$remainingLoan = 0;
		
		if ($loan) {
			$remainingLoan = $loan->remainingLoan;
		} 

		return view('admin.accounts.payroll.create', compact('employee', 'remainingLoan'));
	}


	public function store(Request $request,$emp_id, Notification $notification, CustomPayroll $payroll)
	{
		$this->validation($request);
		$payroll->take_values($request);
		
		$data = json_decode(json_encode($payroll->get_values()), true); 
		Payroll::create($data);

		$notification->createNotication('Successfully created the record', 'success');
		return redirect()->back();
	}


	public function edit($emp_id, $id)
	{
		$payroll = Payroll::findOrFail($id);

		return view('admin.accounts.payroll.edit', compact('payroll'));
	}


	public function update(Request $request,$emp_id, $id, CustomPayroll $custom_payroll)
	{
		$this->validation($request);
		$payroll = Payroll::findOrFail($id);

		$custom_payroll->take_values($request);
		$data = json_decode(json_encode($custom_payroll->get_values()), true);

		$payroll->update($data);
		return redirect()->route('payroll.index', ['empId' => $emp_id]);
	}

	
	public function show($emp_id, $id)
	{
		$payroll = Payroll::findOrFail($id);

		return view('admin.accounts.payroll.show', compact('payroll'));
	}


	public function destroy($emp_id, $id, Notification $notification)
	{
		Payroll::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the payroll!', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([
			'srNumber' => 'required',
			// 'name' => 'required',
			'basicSalary' => 'required',
			'workingDays' => 'required',
			'totalHours' => 'required',
			'lateHours' => 'required',
			// 'overTimeCommission' => 'required',
			// 'netSalary' => 'required',
			'coSec' => 'required',
			'pBalance' => 'required',
			'daybook' => 'required',
			// 'total' => 'required',
			'advanceDeduction' => 'required',
			'penalty' => 'required',
			// 'finalSalary' => 'required',
			// 'paySalary' => 'required',
			'signature' => 'required',
			'bLoan' => 'required',
			// 'totalSecurity' => 'required',
		]);
	}

}
