<?php

namespace App\Http\Controllers\Partyname;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\PartynameModel\Partyname;

class PartyNameController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}

    public function index()
    {
    	$partyNames = Partyname::paginate(config('settings.pages'));

    	return view('admin.accounts.partyName.index', compact('partyNames'));
    }


	public function create()
	{
		return view('admin.accounts.partyName.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$attibutes = $this->validation($request);
		Partyname::create($attibutes);

		$notification->createNotication('Successfully created the partyname!', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$partyName = Partyname::findOrFail($id);

		return view('admin.accounts.partyName.edit', compact('partyName'));
	}


	public function update(Request $request, $id)
	{
		$attibutes = $this->validation($request, $id);
		$partyName = Partyname::findOrFail($id);

		$partyName->update($attibutes);
		return redirect()->route('partyname.index');
	}


	public function destroy($id, Notification $notification)
	{
		Partyname::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the partyname!', 'success');

		return redirect()->back();
	}

	private function validation($values, $id = 0)
	{
		return $values->validate([
			'srNumber' => 'required',
			'ac' => 'required',
			'partyName' => 'required|unique:partynames,partyName,'.$id,
		]);
	}

}
