<?php

namespace App\Http\Controllers\Partyname;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\PartynameModel\Daybook;
use App\PartynameModel\Detail;

class DaybookController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}
	
    public function index()
    {
		$daybooks = Daybook::paginate(config('settings.pages'));

    	return view('admin.accounts.daybook.index', compact('daybooks'));
    }


	public function create()
	{
		$daybook = Daybook::orderBy('created_at', 'desc')->first();
		$openingBalance = 0;

		if ($daybook)
			$openingBalance = $daybook->openingBalance;

		return view('admin.accounts.daybook.create', compact('openingBalance'));
	}


	public function store(Request $request, Notification $notification)
	{
		$record = Daybook::where('date', '=', $request->date)->get();

		if (count($record) > 0) {

			$notification->createNotication('The daybook record is already created for this date', 'error');

			return redirect()->back();

		} else {

			$attributes = $this->validation($request);
			$daybook = Daybook::create($attributes);

			$price = 0;

			// // for repair and maintainence
			if ($request->rpDescription) {

				for ($i = 0; $i < count($request->rpDescription); $i++) {
					$detail = new Detail();
					$detail->price = $request->rpPrice[$i];
					$detail->description = $request->rpDescription[$i];
					$detail->catagoryName = 'Repair And Maintainence ';
					$detail->daybook_id = $daybook->id;	
					$price += $detail->price;

					$detail->save();
				}

			}

			// // for other expenses
			if ($request->otherExpDescription) {

				for ($i = 0; $i < count($request->otherExpDescription); $i++) {
					$detail = new Detail();
					$detail->description = $request->otherExpDescription[$i];
					$detail->price = $request->otherExpPrice[$i];
					$detail->catagoryName = 'Other Expenses ';
					$detail->daybook_id = $daybook->id;	
					$price += $detail->price;


					$detail->save();
				}

			}

			// // for salary wages
			if ($request->wagesDescription) {

				for ($i = 0; $i < count($request->wagesDescription); $i++) {
					$detail = new Detail();
					$detail->price = $request->wagesPrice[$i];
					$detail->description = $request->wagesDescription[$i];
					$detail->catagoryName = 'Salary Wages ';
					$detail->daybook_id = $daybook->id;	
					$price += $detail->price;


					$detail->save();
				}

			}

			// // for fuel expenses
			if ($request->fuelDesctiption) {

				for ($i = 0; $i < count($request->fuelDesctiption); $i++) {
					$detail = new Detail();
					$detail->price = $request->fuelPrice[$i];
					$detail->description = $request->fuelDesctiption[$i];
					$detail->catagoryName = 'Fuel Expenses ';
					$detail->daybook_id = $daybook->id;	
					$price += $detail->price;


					$detail->save();
				}

			}

			// // for advance expenses
			if ($request->advanceDescription) {

				for ($i = 0; $i < count($request->advanceDescription); $i++) {
					$detail = new Detail();
					$detail->price = $request->advancePrice[$i];
					$detail->description = $request->advanceDescription[$i];
					$detail->catagoryName = 'Advance Description';
					$detail->daybook_id = $daybook->id;	
					$price += $detail->price;


					$detail->save();
				}

			}

			// // for entertainment
			if ($request->entertainDescription) {

				for ($i = 0; $i < count($request->entertainDescription); $i++) {
					$detail = new Detail();
					$detail->price = $request->entertainPrice[$i];
					$detail->description = $request->entertainDescription[$i];
					$detail->catagoryName = 'Entertainment ';
					$detail->daybook_id = $daybook->id;	
					$price += $detail->price;


					$detail->save();
				}

			}

			$updateDaybook = Daybook::findOrFail($daybook->id);
			$attributes['totalExpenses'] = $price;
			$myBalance = $daybook->openingBalance - $price;
			$attributes['remainingBalance'] = $myBalance;
			$attributes['openingBalance'] = $myBalance;
			$updateDaybook->update($attributes);

			$notification->createNotication('Successfully created the daybook record!', 'success');

			return redirect()->back();

		} // ends else statement

		
	} // function ends


	public function show($id)
	{
		$details = Detail::where('daybook_id', '=', $id)->get();
		$daybook = Daybook::findOrFail($id);
		
		return view('admin.accounts.daybook.show', compact('details', 'daybook'));
	}


	public function print($id)
	{
		$details = Detail::where('daybook_id', '=', $id)->get();
		$daybook = Daybook::findOrFail($id);

		return view('admin.accounts.daybook.print', compact('details', 'daybook'));
	}


	public function destroy($id, Notification $notification)
	{
		Daybook::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the daybook record!', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([
			'date' => 'required',
			'voucherNo' => 'required',
			'openingBalance' => 'required',
		]);
	}


}
