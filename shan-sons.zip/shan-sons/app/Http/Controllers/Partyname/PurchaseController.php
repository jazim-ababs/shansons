<?php

namespace App\Http\Controllers\PartyName;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\PartynameModel\Partyname;
use App\PartynameModel\Purchase;

class PurchaseController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin,accountsKeeper');
	}

	public function print($partynameID)
	{
		$purchases = Partyname::findOrFail($partynameID)->purchases;

		return view('admin.accounts.purchase.print', compact('purchases'));
	}

	public function index($partynameID)
	{
		$partyName = PartyName::findOrFail($partynameID);
		$purchases = $partyName->purchases()->paginate(config('settings.pages'));

		return view('admin.accounts.purchase.index', compact('purchases', 'partyName'));
	}

    
	public function createpage()
	{
		$partyNames = Partyname::all();

		return view('admin.accounts.purchase.createpage', compact('partyNames'));
	}


	public function create($partynameID)
	{
		$latest = Purchase::where('partyname_id', '=', $partynameID)->orderBy('created_at', 'desc')->first();
		$partyName = Partyname::findOrFail($partynameID);

		$balance = 0;
		if ($latest)
			$balance = $latest->balance;

		return view('admin.accounts.purchase.create', compact('partyName', 'balance'));
	}


	public function store(Request $request, $partynameID, Notification $notification)
	{
		$attributes = $this->validation($request);
		$amount = $request->qty * $request->price;

		$tempBalance = $request->balance;
		$balance = ( $request->cr - $amount ) + $tempBalance;

		$attributes['dr'] = $amount;
		$attributes['balance'] = $balance;

		Purchase::create($attributes);

		$notification->createNotication('Successfully created the purchase!', 'success');
		return redirect()->back();
	}


	public function update(Request $request, $partynameID, $id)
	{
		$attributes = $this->validation($request);
		$purchase = Purchase::findOrFail($id);

		$purchase->update($attributes);
		return redirect()->route('purchase.createpage');
	}


	public function edit($partynameID, $id)
	{
		$purchase = Purchase::findOrFail($id);

		return view('admin.accounts.purchase.edit', compact('purchase'));
	}


	public function show($partynameID, $id)
	{
		$purchase = Purchase::findOrFail($id);

		return view('admin.accounts.purchase.show', compact('purchase'));
	}


	public function destroy($partynameID, $id, Notification $notification)
	{
		Purchase::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the purchase!', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([
			'partyname_id' => 'required',
			'date' => 'required',
			'girn' => 'required',
			'description' => 'required',
			'qty' => 'required',
			'uom' => 'required',
			'price' => 'required',
			'cr' => 'required',
			'balance' => 'required',
		]);
	}



}
