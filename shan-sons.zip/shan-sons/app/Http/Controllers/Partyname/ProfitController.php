<?php

namespace App\Http\Controllers\Partyname;

use App\Custom\Expense;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

// use App\PartynameModel\Salename;
// use DB;
use App\Custom\Profit;

class ProfitController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin');
	}

	public function create()
	{
		return view('admin.accounts.profit.create');
	}

	public function store(Request $request, Expense $expense, Profit $profitObj)
	{
		$request->validate([
			'date' => 'required'
		]);
		
		$record = $this->getRecord($request->date);
		
		return view('admin.accounts.profit.index', [
			'sales' => $record['sales'],
			'totalRevenue' => $record['totalRevenue'],
			'totalExpenses' => $record['totalExpenses'],
			'profit' =>  $record['profit'],
			'date' => $request->date
		]);
	}

	public function show($date)
	{
		$record = $this->getRecord($date);

		return view('admin.accounts.profit.show', [
			'sales' => $record['sales'],
			'totalRevenue' => $record['totalRevenue'],
			'totalExpenses' => $record['totalExpenses'],
			'profit' =>  $record['profit'],
			'date' => $date
		]);
	}

	private function getRecord($date)
	{
		$expense = new Expense;
		$profitObj = new Profit;

		$profitObj->fetchRecord($date);
		$sales = $profitObj->getTotal();
		
		$totalRevenue = $this->totalRevenues($sales);
		$expense->fetchExpenses($date);

		$totalExpenses = $expense->getExpenses();
		$profit = $totalExpenses - $totalRevenue;

		return ['sales'=>$sales, 'totalRevenue'=>$totalRevenue, 'totalExpenses'=>$totalExpenses, 'profit'=>$profit];
	}
    
	public function profit(Expense $expense, Profit $profit)
	{
		
		$date = "2019-10";
		// $expense->fetchExpenses($date);
		// return $expense->getExpenses();

		$profit->fetchRecord($date);
		$myProfit = $profit->getTotal();
		return $myProfit;
	}

	private function totalRevenues($sales)
	{
		$price = 0;

		foreach ($sales as $sale)
		{
			// dd($sale['price']);
			// dd($sales);
			$price += $sale['price'];
		}
		
		return $price;
	}

	private function randomeFunction()
	{
		// $saleNameIDs = Salename::select('id')->get();
		// $saleNameIDs = DB::table('salenames')->select('id')->get();

		// foreach ($saleNameIDs as $obj)
		// {
		// 	echo $obj->id . "<br />";
		// }

		// return $saleNameIDs;

		$date = "2019-10-10";
		// $sales = Salename::with('sales')->where('invoiceDate', '=', $date)->get();

		// $sales = Salename::with(["sales" => function($q) use($date) {
		// 	$q->where('invoiceDate', '=', $date)
		// }])->get();

		// $sales = Salename::with('sales')->get();

		//  $sales = Salename::with(["sales" => function($q) use($date){
		//   $q->where("invoiceDate", "=", $date);
		// }])->get();

		// return $sales;

		// $cars = array
		//   (
		//   array("name" => 'Atlas Honda', 'price' => 2000),
		//   array("name" => 'Honda', 'price' => 4000),
		//   array("name" => 'BMW', 'price' => 5000)
		//   );

		//   return $cars;
	}

}
