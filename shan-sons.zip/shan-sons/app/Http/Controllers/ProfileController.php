<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    
    public function edit()
    {
        return view('admin.profile.edit');
    }

    public function update(Request $request, $id, Notification $notification)
    {
        $request->validate([

			'name'	=>	['required', 'min:5', 'max:20'],
			'password'	=>	['required', 'min:8', 'max:20', 'confirmed'],
			'password_confirmation'	=>	['required'],

        ]);
        
        $user = User::findOrFail($id);

        $user->name = $request->name;
		$user->password = Hash::make($request->password);

		$user->save();
		$notification->createNotication('Successfully update the profile', 'success');

		return redirect()->back();
    }


}
