<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use App\Custom\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin');
    }

    public function index(Role $roleObj)
    {
        $users = User::all();
        $roles = $roleObj->getIds();

        return view('admin.user.index', compact('users', 'roles'));
    }

    public function create()
    {
        return view('admin.user.create');
    }

    public function store(Request $request, Notification $notification)
    {
        // return $request;
        $attributes = $this->validation($request);

        unset($attributes['passowrd_confirmation']);
		unset($attributes['password']);

        $attributes['password'] = Hash::make($request->password);
        User::create($attributes);

        $notification->createNotication('Successfully created the user', 'success');
        return redirect()->back();
    }

    public function action(Request $request, $id, Notification $notification)
    {
        $user = User::findOrFail($id);
		$user->role_id = $request->userType;

		$user->save();
        $notification->createNotication('Successfully update the Role Type', 'success');
		
		return redirect()->back();
    }

    public function destroy($id, Notification $notification)
    {
        User::findOrFail($id)->delete();
        $notification->createNotication('Successfully deleted the user', 'success');

        return redirect()->back();
    }

    private function validation($values)
    {
        return $values->validate([
            'name' => ['required', 'string', 'max:255', 'min:5'],
			'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
			'password' => ['required', 'string', 'min:8', 'confirmed'],
			'password_confirmation' => ['required']
        ]);
    }

}
