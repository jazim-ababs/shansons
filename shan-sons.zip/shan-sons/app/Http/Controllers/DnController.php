<?php

namespace App\Http\Controllers;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\DN;
class DnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $dn = DN::paginate(config('settings.pages'));
        //dd($employees);
        return view('admin.mainstore.demandnote.index', compact('dn'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        return view('admin.mainstore.demandnote.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Notification $notification)
        
        
    {
       
       DN::validation($request);
        DN::create(request(['SrNo','date','description','unit','quantity','rate','remarks']));

        $notification->createNotication('Successfully created the record', 'success');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    public function print()
    {
        $dns = DN::all();

        return view('admin.mainstore.demandnote.print', compact('dns'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $dn = DN::find($id);
        return view('admin.mainstore.demandnote.edit', compact('dn'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
         $dn = DN::findOrFail($id);
         $dn->SrNo = request('SrNo');
         $dn->date = request('date');
         $dn->description = request('description');
         $dn->unit = request('unit');
         $dn->quantity = request('quantity');
         $dn->remarks = request('remarks');
         $dn->save();
        return redirect('/dn');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Notification $notification)
    {
        DN::findOrFail($id)->delete();

        $notification->createNotication('Successfully deleted the record', 'success');
        return back();
    }
}
