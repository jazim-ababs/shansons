<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Company;
use App\Custom\Notification;

class CompanyController extends Controller
{
    
    public function index()
    {
		// $pages = config('settings.pages');
		// return $pages;
    	$companies = Company::paginate(config('settings.pages'));

    	return view('admin.company.companyIndex', compact('companies'));
    }

    public function create()
    {
    	return view('admin.company.create');
    }

    public function store(Request $request, Notification $notification)
    {
    	$attributes = $this->validation($request);
    	Company::create($attributes);

		$notification->createNotication('Successfully created the company!', 'success');
    	return redirect()->back();
    }

    public function edit($id)
    {
    	$company = Company::findOrFail($id);

    	return view('admin.company.companyEdit', compact('company'));
    }

    public function update(Request $request, $id)
    {
    	$attributes = $this->validation($request, $id);
    	$company = Company::findOrFail($id);

    	$company->update($attributes);
    	return redirect()->route('company.index');
    }

    public function destroy($id, Notification $notification)
    {
		Company::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the company!', 'success');

    	return redirect()->back();
    }

    private function validation($values, $id = 0)
    {
    	return $values->validate([

			'companyName' => ['required', 'min:6', 'max:30'],
			'companyName' => 'required|unique:companies,companyName,'.$id,
    		'address' => ['required', 'min:6', 'max:70'],
    		'number' => 'required|regex:/(03)[0-9]{9}/|max:11',
    		'ntnNumber'	=> 'required'

    	]);
    }


}
