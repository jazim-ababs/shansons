<?php

namespace App\Http\Controllers\Hr;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\HrModel\Employee;

class EmployeeController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
		$this->middleware('role:admin');
	}


	public function index()
	{
		$employees = Employee::paginate(config('settings.pages'));

		return view('admin.hr.employee.index', compact('employees'));
	}

    
    public function create()
    {
    	return view('admin.hr.employee.create');
    }


    public function store(Request $request, Notification $notification)
    {
    	$attributes = $this->validation($request);
    	Employee::create($attributes);

		$notification->createNotication('Successfully created the employee!', 'success');
		return redirect()->back();
    }


    public function edit($id)
    {
    	$employee = Employee::findOrFail($id);

    	return view('admin.hr.employee.edit', compact('employee'));
    }


    public function update(Request $request, $id)
    {
    	$attributes = $this->validation($request);
    	$employee = Employee::findOrFail($id);

    	$employee->update($attributes);
    	return redirect()->route('employee.index');
    }


    public function destroy($id, Notification $notification)
    {
    	Employee::findOrFail($id)->delete();
		$notification->createNotication('Successfully created the employee!', 'success');

		return redirect()->back();
    }


    private function validation($values)
    {
    	return $values->validate([
    		'employeeNo' => 'required',
    		'name' => 'required',
    		'date' => 'required',
    		'mobileNo' => 'required|regex:/(03)[0-9]{9}/|max:11',
    		'address' => 'required',
    		'department' => 'required',
    	]);
    }

}
