<?php

namespace App\Http\Controllers\Store;

use App\Custom\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\StoreModel\Rawmaterial;

class RawMaterialStoreController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }
	
    public function index()
    {
    	$raws = Rawmaterial::paginate(config('settings.pages'));

    	return view('admin.store.rawmaterialstore.index', compact('raws'));
    }


	public function create()
	{
		return view('admin.store.rawmaterialstore.create');
	}


	public function store(Request $request, Notification $notification)
	{
		$attributes = $this->validation($request);
		Rawmaterial::create($attributes);

		$notification->createNotication('Succssfully created the raw material', 'success');
		return redirect()->back();
	}


	public function edit($id)
	{
		$raw = Rawmaterial::findOrFail($id);

		return view('admin.store.rawmaterialstore.edit', compact('raw'));
	}


	public function show($id)
	{
		$raw = Rawmaterial::findOrFail($id);

		return view('admin.store.rawmaterialstore.show', compact('raw'));
	}


	public function update(Request $request, $id)
	{
		$attributes = $this->validation($request);
		$raw = Rawmaterial::findOrFail($id);

		$raw->update($attributes);
		return redirect()->route('raw.index');
	}


	public function destroy($id, Notification $notification)
	{
		Rawmaterial::findOrFail($id)->delete();
		$notification->createNotication('Successfully deleted the raw material', 'success');

		return redirect()->back();
	}


	private function validation($values)
	{
		return $values->validate([
			'srNumber' => 'required',
			'date' => 'required',
			'uom' => 'required',
			'issue' => 'required',
			'description' => 'required',
			'balance' => 'required',
		]);
	}

}
