<?php

namespace App\Http\Controllers\Store;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Company;
use App\Custom\Notification;
use App\StoreModel\FinishStore;

class FinishStoreController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin,storeKeeper');
    }

    public function record()
    {
    	$companies = Company::all();

    	return view('admin.store.finishstore.record', compact('companies'));
    }


    public function index($companyId)
    {
        // return $companyId;
        $company = Company::find($companyId);
        $finishStores = $company->finishStores()->paginate(config('settings.pages'));
        
        $companyId = $company->id;
        return view('admin.store.finishstore.index', compact('finishStores', 'companyId'));
    }


    public function create($id)
    {
    	$company = Company::findOrFail($id);
    	// dd('wait');
    	return view('admin.store.finishstore.create', compact('company'));
    }


    public function store(Request $request, Notification $notification)
    {
        $attributes = $this->validation($request);
        $calculation = $this->calculateTotalBalance($attributes);

        $attributes['endingBalance'] = $calculation['totalBalance'];
        $attributes['balance'] = $calculation['balanceInHand'];

        FinishStore::create($attributes);

        $notification->createNotication('Successfully created the finish store!', 'success');
        return redirect()->back();
    }


    public function selectDate(Request $request, $companyId)
    {
        $finishStores = FinishStore::where([
            ['company_id', '=', $companyId],
            ['date', '=', $request->date]
        ])->get();
        $date = $request->date;
        
        if (count($finishStores) > 0)
            $companyName = $finishStores[0]->company->companyName;
        else
            $companyName = '';

        return view('admin.store.finishstore.report', compact('finishStores', 'date', 'companyName'));
    }

    public function edit($companyId, $id)
    {
        $finishStore = FinishStore::findOrFail($id);

        return view('admin.store.finishstore.edit', compact('finishStore'));
    }

    public function update(Request $request, $companyId, $id)
    {
        $attributes = $this->validation($request);
        $calculation = $this->calculateTotalBalance($attributes);

        $attributes['endingBalance'] = $calculation['totalBalance'];
        $attributes['balance'] = $calculation['balanceInHand'];

        $finishStore = FinishStore::findOrFail($id);

        $finishStore->update($attributes);
        return redirect()->route('finishstore.index', ['companyId'=>$companyId]);
    }

    public function destroy($companyId, $id, Notification $notification)
    {
        FinishStore::findOrFail($id)->delete();
        $notification->createNotication('Successfully deleted the finish store', 'success');

        return redirect()->back();
    }

    private function calculateTotalBalance($values)
    {
        $totalBalance = $values['openingBalance'] + $values['packing'];
        $balanceInHand = ( $totalBalance - $values['qtv'] ) + $values['receive'];

        return ['totalBalance'=>$totalBalance, 'balanceInHand'=>$balanceInHand];
    }

    private function validation($values)
    {
        return $values->validate([
            'company_id' => 'required',
            'date' => 'required',
            'description' => 'required',
            'openingBalance' => 'required',
            'packing' => 'required',
            'qtv' => 'required',
            'receive' => 'required'
        ]);
    }

}
