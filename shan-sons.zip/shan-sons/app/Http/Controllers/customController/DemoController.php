<?php

namespace App\Http\Controllers\customController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DemoController extends Controller
{
    //
}
