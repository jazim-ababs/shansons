<?php

namespace App\PartynameModel;

use Illuminate\Database\Eloquent\Model;

class Daybook extends Model
{
    protected $guarded = [];
}
