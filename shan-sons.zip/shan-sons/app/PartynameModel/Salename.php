<?php

namespace App\PartynameModel;

use Illuminate\Database\Eloquent\Model;

class Salename extends Model
{
    protected $guarded = [];

    public function sales()
    {
    	return $this->hasMany('App\PartynameModel\Sale');
    }

}
