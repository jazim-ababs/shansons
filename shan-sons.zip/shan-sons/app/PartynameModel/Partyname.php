<?php

namespace App\PartynameModel;

use Illuminate\Database\Eloquent\Model;

class Partyname extends Model
{
    protected $guarded = [];

    public function purchases()
    {
    	return $this->hasMany('App\PartynameModel\Purchase');
    }

}
