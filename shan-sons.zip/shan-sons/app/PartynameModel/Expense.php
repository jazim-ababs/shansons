<?php

namespace App\PartynameModel;

use Illuminate\Database\Eloquent\Model;

class Expense extends Model
{
    protected $guarded = [];
}
