<?php

namespace App\PartynameModel;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $guarded = [];

    public function salename()
    {
    	return $this->belongsTo('App\PartynameModel\Salename');
    }
}
