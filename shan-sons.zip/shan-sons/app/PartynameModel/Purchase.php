<?php

namespace App\PartynameModel;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    protected $guarded = [];

    public function partyname()
    {
    	return $this->belongsTo('App\PartynameModel\Partyname');
    }

}
