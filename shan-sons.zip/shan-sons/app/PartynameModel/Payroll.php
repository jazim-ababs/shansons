<?php

namespace App\PartynameModel;

use App\HrModel\Employee;
use Illuminate\Database\Eloquent\Model;

class Payroll extends Model
{
    protected $guarded = [];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

}
