<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DC extends Model
{
      protected $guarded = [];

    
      
      public static function validation($values)
     {
     	$values->validate([
     		'SrNo'=>'required',
     		'date'=>'required',
     		'description' => 'required',
     		'unit'=>'required',
     		'quantity'=>'required',
     		'remarks'=>'required'
     		


     	]);
     }
}
