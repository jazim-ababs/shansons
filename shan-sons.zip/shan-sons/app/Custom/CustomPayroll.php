<?php

namespace App\Custom;

use App\PartynameModel\Payroll;

class CustomPayroll
{
    private $data;

    public function take_values($values)
    {
        $this->data = $values;
    }

    public function get_values()
    {
       $fields = array();

       $fields['employee_id'] = $this->data['employee_id'];
       $fields['srNumber'] = $this->data['srNumber'];
       $fields['basicSalary'] = $this->data['basicSalary'];
       $fields['workingDays'] = $this->data['workingDays'];
       $fields['totalHours'] = $this->data['totalHours'];
       $fields['lateHours'] = $this->data['lateHours'];
       $fields['coSec'] = $this->data['coSec'];
       $fields['pBalance'] = $this->data['pBalance'];
       $fields['daybook'] = $this->data['daybook'];
       $fields['advanceDeduction'] = $this->data['advanceDeduction'];
       $fields['penalty'] = $this->data['penalty'];
       $fields['signature'] = $this->data['signature'];
       $fields['bLoan'] = $this->data['bLoan'];
       

       $fields['overTimeCommission'] = $this->overTimeCommission();
       $fields['totalSalary'] = $this->totalSalary();
       $fields['overtime'] = $this->totalOvertime();
       $fields['overTimeCommission'] = $this->overTimeCommission();
       $fields['netSalary'] = $this->netSalary();
       $fields['total'] = $this->total();
       $fields['finalSalary'] = $this->finalSalary();
       $fields['paySalary'] = $this->paySalary();
       $fields['remainingLoan'] = $this->remainingLoad();
       $fields['totalSecurity'] = $this->totalSecurity();

       return $fields;
    }

    private function oneDaySalary()
    {
        return $this->data['basicSalary'] / 30;
    }

    private function totalSalary()
    {
        return $this->data['workingDays'] * $this->oneDaySalary();
    }

    private function totalOvertime()
    {
        return $this->data['totalHours'] - $this->data['lateHours'];
    }

    private function oneHourSalary()
    {
        return $this->data['basicSalary'] / 240;
    }

    private function overTimeCommission()
    {
        return $this->oneHourSalary() * $this->totalOvertime();
    }

    private function netSalary()
    {
        return $this->data['basicSalary'] + $this->overTimeCommission();
    }

    private function total()
    {
        // return $this->data['pBalance'];
        return $this->data['pBalance'] + $this->data['daybook'];
    }

    private function finalSalary()
    {
        return $this->netSalary() - $this->data['coSec'] - $this->total() - $this->data['penalty'];
    }

    private function paySalary()
    {
        return $this->finalSalary() - $this->overTimeCommission();
    }

    private function remainingLoad()
    {
        return $this->data['bLoan'] - $this->data['advanceDeduction'];
    }

    private function totalSecurity()
    {
        $emp_id = $this->data['employee_id'];
        $payrolls = Payroll::where('employee_id', $emp_id)->get();
        $security = 0;

        if ($payrolls) 
        {
            foreach ($payrolls as $payroll)
            {
                $security += $payroll->coSec;
            }
        }
        else 
        {
            $security = 30;
        }

        return $security;
    }

}
