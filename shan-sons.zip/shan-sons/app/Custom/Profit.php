<?php 

namespace App\Custom;

use App\PartynameModel\Salename;

class Profit
{

	private $data = array();


	private function setFields($name, $price)
	{
		$localFields = array('name' => $name, 'price' => $price);

		array_push($this->data, $localFields);
	}

	public function getTotal()
	{
		return $this->data;
	}

	public function fetchRecord($date)
	{
		 $salenames = Salename::with(["sales" => function($q) use($date){
		  $q->where('invoiceDate', 'like', '%'. $date . '%');
		}])->get();

		 $this->fetchParent($salenames);
	}

	private function fetchParent($salenames)
	{
		foreach ($salenames as $salename)
		{
			$name = $salename->name;
			$price = $this->fetchChild($salename);

			$this->setFields($name, $price);
		}
	}

	private function fetchChild($salename)
	{
		$price = 0;

		foreach ($salename->sales as $sale)
		{
			$price += $sale->total;
		}

		return $price;
	}



} //-- ends class --//
