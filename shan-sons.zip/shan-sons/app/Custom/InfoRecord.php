<?php

namespace App\Custom;

use App\PartynameModel\Daybook;
use App\PartynameModel\Detail;

class InfoRecord {

	//-- data members
	private $price;
	private $advanceSalary;
	private $entertainment;
	private $repair;
	private $fuelExpense;


	//-- member functions --//
	public function __construct()
	{
		$this->price = 0;
		$this->advanceSalary = 0;
		$this->entertainment = 0;
		$this->repair = 0;
		$this->fuelExpense = 0;
	}

	private function setPrice($price)
	{
		dd($this['price']);
		$this->price = $this->price + $price;
	}

	private function setFuelExpense($price)
	{
		$this->fuelExpense = $this->fuelExpense + $price;
	}

	private function setAdvanceSalary($price)
	{
		$this->advanceSalary = $this->advanceSalary + $price;
	}

	private function setEntertainment($price)
	{
		$this->entertainment = $this->entertainment + $price;
	}

	private function setRepair($price)
	{
		$this->repair = $this->repair + $price;
	}

	public function getPrice()
	{
		return $this->price;
	}

	public function getAdvanceSalary()
	{
		return $this->advanceSalary;
	}

	public function getEntertainment()
	{
		return $this->entertainment;
	}

	public function getRepairMaintainence()
	{
		return $this->repair;
	}

	public function getFuelExpense()
	{
		return $this->fuelExpense;
	}

	public function fetchRecord($date)
	{
		$daybooks = Daybook::where('date', 'like', '%'. $date . '%')->get();

		// dd($daybooks);

		foreach ($daybooks as $daybook) {

			$this->setParentFieldPrice($daybook);

		} //-- ends foreach loop --//

	}


	private function setParentFieldPrice($record)
	{
		$this->setPrice($record->fuelCr);
		$this->setPrice($record->entertainCr);

		// dd($this->price);

		$this->setChildFieldPrice('Fuel Expenses', $record->id, 'setFuelExpense');
		$this->setChildFieldPrice('Entertainment', $record->id, 'setEntertainment');
		$this->setChildFieldPrice('Salary Wages', $record->id, 'setAdvanceSalary');
		$this->setChildFieldPrice('Repair And Maintainence', $record->id, 'setRepair');
	} 

	private function setChildFieldPrice($catagoryName, $id, $functionName)
	{
		$details = Detail::where([
				['catagoryName', '=', $catagoryName],
				['daybook_id', '=', $id]
			])->get();

		foreach ($details as $detail) {

			$this->$functionName($detail->price);

		} //-- ends foreach loop --//

	}

	private function getFunctionName($name)
	{
		$funcName = "";

		if ($name == "Repair And Maintainence")
			$funcName = "setRepair";
		elseif ($name == "Salary Wages")
			$funcName = "setAdvanceSalary";
		elseif ($name == "Fuel Expenses")
			$funcName = "setFuelExpense";
		elseif ($name == "Entertainment")
			$funcName = "setEntertainment";

		return $funcName;
	}


} //-- ends class --//
