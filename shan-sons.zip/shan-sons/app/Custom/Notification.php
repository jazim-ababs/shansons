<?php

namespace App\Custom;

use Session;

class Notification
{

    public function createNotication($message, $response)
    {
        Session::flash('message', $message); 
		Session::flash('alert-class', $response);
    }

} //-- ends Notification Class --//
