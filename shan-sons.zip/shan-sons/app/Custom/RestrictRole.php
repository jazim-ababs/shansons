<?php 

namespace App\Custom;

class RestrictRole
{
    private $user;

    public function __construct()
    {
        $this->user = auth()->user();
    }

    public function roleExists($permission, ...$roles)
    {
        // dd($roles, $permission);
        // dd($roles);
        return auth()->user()->hasRoleExists($permission, $roles);
    }


} //-- ends Class RestrictRole --//
