<?php 

namespace App\Custom;

use App\PartynameModel\Daybook;
use App\PartynameModel\Detail;

class DaybookRecord
{

	//-- data members --//
	private $advanceSalary;
	private $entertainment;
	private $repair;
	private $fuelExpense;
	private $otherExpenses;



	//-- member functions --//
	public function __construct()
	{
		$this->advanceSalary = 0;
		$this->entertainment = 0;
		$this->repair = 0;
		$this->fuelExpense = 0;
		$this->otherExpenses = 0;
	}

	private function setFuelExpense($price)
	{
		$this->fuelExpense = $this->fuelExpense + $price;
	}

	private function setAdvanceSalary($price)
	{
		$this->advanceSalary = $this->advanceSalary + $price;
	}

	private function setEntertainment($price)
	{
		$this->entertainment = $this->entertainment + $price;
	}

	private function setRepair($price)
	{
		$this->repair = $this->repair + $price;
	}

	private function setOtherExpenses($price)
	{
		$this->otherExpenses = $this->otherExpenses + $price;
	}

	public function getOtherExpenses()
	{
		return $this->otherExpenses;
	}

	public function getPrice()
	{
		return $this->price;
	}

	public function getAdvanceSalary()
	{
		return $this->advanceSalary;
	}

	public function getEntertainment()
	{
		return $this->entertainment;
	}

	public function getRepairMaintainence()
	{
		return $this->repair;
	}

	public function getFuelExpense()
	{
		return $this->fuelExpense;
	}

	public function setRecord($date)
	{
		// $this->fetchParent($date);

		$this->fetchChild($date, 'Fuel Expenses', 'setFuelExpense');
		$this->fetchChild($date, 'Entertainment', 'setEntertainment');
		$this->fetchChild($date, 'Salary Wages', 'setAdvanceSalary');
		$this->fetchChild($date, 'Repair And Maintainence', 'setRepair');
		$this->fetchChild($date, 'Other Expenses', 'setOtherExpenses');
	}

	private function fetchParent($date)
	{
		$daybooks = Daybook::where('date', 'like', '%'. $date . '%')->get();

		foreach ($daybooks as $daybook) {
			// dd($daybook->advanceCr);
			$this->setAdvanceSalary($daybook->advanceCr);
			$this->setEntertainment($daybook->entertainCr);
			$this->setFuelExpense($daybook->fuelCr);
			$this->setRepair($daybook->rpCr);

		} //-- ends foreach loop --//

		// dd($this->getAdvanceSalary());

	}

	private function fetchChild($date, $catagoryName, $functionName)
	{
		$details = Detail::where([
			['created_at', 'like', '%' . $date . '%'],
			['catagoryName', '=', $catagoryName]
		])->get();

		foreach ($details as $detail) {

			$this->$functionName($detail->price);

		} //-- ends foreach loop --//

	}



} //-- ends class --//

