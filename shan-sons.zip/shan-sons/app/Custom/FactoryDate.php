<?php

namespace App\Custom;

use DateTime;

class FactoryDate
{
    public function getDate()
    {
        $start = new DateTime('2019-10-01');
        $end = new DateTime('2019-10-29');
        
        $randomTimestamp = mt_rand($start->getTimestamp(), $end->getTimestamp());
        $randomDate = new DateTime();
        $randomDate->setTimestamp($randomTimestamp);
        return $randomDate->format('Y-m-d');
    }
    
}
