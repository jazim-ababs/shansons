<?php

namespace App\Custom;

class Role
{
    private $ids = array('user' => 0, 'admin' => 1, 'accountsKeeper' => 2, 'gateKeeper' => 3, 'storeKeeper' => 4);

    private $myRoles = array('User', 'Admin', 'Accounts Keeper', 'Gate Keeper', 'StoreKeeper');

    public function getIds()
    {
        return $this->ids;
    }

    public function getRoles()
    {
        return $this->myRoles;
    }

    public function getRoleId($role)
    {
        return $this->ids[$role];
    }

    public function getRoleName($id)
    {
        return $this->myRoles[$id];
    }

} //-- ends Role Class --//
