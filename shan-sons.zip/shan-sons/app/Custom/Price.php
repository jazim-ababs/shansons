<?php 

namespace App\Custom;

class Price
{
    public function getPrice($values)
    {
        return $values['quantity'] * $values['box'];
    }


} //-- ends Price Class --//
