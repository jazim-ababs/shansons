<?php

namespace App\Custom;

use App\PartynameModel\Expense as AppExpense;

class Expense
{

    private $totalPrice;

    public function __construct()
    {
        $this->totalPrice = 0;
    }

    private function setField($price)
    {
        $this->totalPrice += $price;
    }

    public function getExpenses()
    {
        return $this->totalPrice;
    }

    public function fetchExpenses($date)
    {
        $expenses = AppExpense::where('date', '=', $date)->get();
        $indexes = array(0, 1, 25, 26);

        foreach ($expenses as $expense)
        {
            $expense = json_decode($expense);
            $count = 0;

            foreach ($expense as $value)
            {
                if (in_array($count, $indexes)) 
                {
                    $count++;
                    continue;
                }
                else
                {
                    $this->setField($value);
                }

                $count++;
            } //-- ends inner foreach loop --//
        
        } //-- ends outer foreach loop --//


    } //-- ends function --//


} //-- ends Expense Class --//
