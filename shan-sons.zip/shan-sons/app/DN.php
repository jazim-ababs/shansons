<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DN extends Model
{
     protected $guarded = [];

      public static function validation($values)
     {
     	$values->validate([
     		'SrNo'=>'required',
     		'date'=>'required',
     		'description' => 'required|min:5',
     		'unit'=>'required',
     		'quantity'=>'required',
     		'remarks'=>'required'


     	]);
     }
}
