<?php

namespace App;

use App\Custom\Role;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    // public function isAdmin()
    // {
    //     if ($this->role_id == 1)
    //         return true;
        
    //     return false;
    // }

    // private $ids = array('user' => 0, 'admin' => 1, 'accountsKeeper' => 2, 'gateKeeper' => 3, 'storeKeeper' => 4);
    // private $myRoles = array('User', 'Admin', 'Accounts Keeper', 'Gate Keeper', 'StoreKeeper');
    // private $roleObj;

    // public function __construct()
    // {
    //     $this->roleObj = new Role;
    // }

    // public function hasRole($role, $role_id)
    // {
    //     if ($this->roleObj->getRoleId($role) == $role_id)
    //         return true;

    //     return false;
    // }

    // public function hasRoleExists($isCheck, ...$roles)
    // {
    //     $flag = false;

    //     foreach ($roles as $role)
    //     {
    //         if ($this->roleObj->getRoleId($role) == auth()->user()->role_id)
    //         {
    //             $flag = true;
    //             break;
    //         }
    //     }

    //     if (!$isCheck)
    //         $flag = !$flag;

    //     return $flag;
    // }

    // public function getRoleName()
    // {
    //     $id = auth()->user()->role_id;

    //     return $this->roleObj->getRoleName($id);
    // }

    public function isAdmin()
    {
        if ($this->role_id == 1)
            return true;
        
        return false;
    }

    private $ids = array('user' => 0, 'admin' => 1, 'accountsKeeper' => 2, 'gateKeeper' => 3, 'storeKeeper' => 4);
    private $myRoles = array('User', 'Admin', 'Accounts Keeper', 'Gate Keeper', 'StoreKeeper');

    public function hasRole($role, $role_id)
    {
        if ($this->ids[$role] == $role_id)
            return true;

        return false;
    }

    public function hasRoleExists($isCheck, $roles)
    {
        $flag = false;
        // dd($roles);

        foreach ($roles as $role)
        {
            // dd($role);
            // dd($this->ids[$role]);
            if ($this->ids[$role] == auth()->user()->role_id)
            {
                $flag = true;
                break;
            }
        }

        if (!$isCheck)
            $flag = !$flag;

        return $flag;
    }

    public function getRoleName()
    {
        $id = auth()->user()->role_id;

        return $this->myRoles[$id];
    }

}
