<?php 

namespace App\forms;

interface Notification
{
    function createNotification($message, $alert);
}


