<?php

namespace App\StoreModel;

use Illuminate\Database\Eloquent\Model;

class Rawmaterial extends Model
{
    protected $guarded = [];
}
