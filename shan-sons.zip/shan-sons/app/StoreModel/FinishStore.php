<?php

namespace App\StoreModel;

use Illuminate\Database\Eloquent\Model;

class FinishStore extends Model
{
    protected $guarded = [];

    
    public function company()
    {
    	return $this->belongsTo('App\Company');
    }
}
