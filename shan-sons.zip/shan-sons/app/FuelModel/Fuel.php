<?php

namespace App\FuelModel;

use Illuminate\Database\Eloquent\Model;

class Fuel extends Model
{
    protected $guarded = [];

    public function fuelcatagory()
    {
    	return $this->belongsTo('App\FuelModel\Fuelcatagory');
    }

}
