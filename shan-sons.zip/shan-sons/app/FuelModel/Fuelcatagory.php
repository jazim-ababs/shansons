<?php

namespace App\FuelModel;

use Illuminate\Database\Eloquent\Model;

class Fuelcatagory extends Model
{
    protected $guarded = [];


    public function setFuelCatagoryAttribute($value)
    {
        $this->attributes['fuelCatagory'] = ucfirst($value);
    }

    public function fuels()
    {
    	return $this->hasMany('App\FuelModel\Fuel');
    }

}
