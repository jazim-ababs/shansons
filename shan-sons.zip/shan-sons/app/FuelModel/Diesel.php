<?php

namespace App\FuelModel;

use Illuminate\Database\Eloquent\Model;

class Diesel extends Model
{
    protected $guarded = [];
}
