<?php

namespace App\FuelModel;

use Illuminate\Database\Eloquent\Model;

class Petrole extends Model
{
    protected $guarded = [];
}
