<?php

namespace App\FuelModel;

use Illuminate\Database\Eloquent\Model;

class Hydraulicoil extends Model
{
    protected $guarded = [];
}
