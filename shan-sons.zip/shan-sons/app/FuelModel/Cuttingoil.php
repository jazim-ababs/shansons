<?php

namespace App\FuelModel;

use Illuminate\Database\Eloquent\Model;

class Cuttingoil extends Model
{
    protected $guarded = [];
}
