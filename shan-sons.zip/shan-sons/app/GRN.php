<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GRN extends Model
{
     public $table='grns';
     protected $fillable = ['SrNo','date','description','unit','quantity','rate','amount'];

     public static function validation($values)
     {
     	$values->validate([
     		'SrNo'=>'required',
     		'date'=>'required',
     		'description' => 'required|min:5',
     		'unit'=>'required',
     		'quantity'=>'required',
     		'rate'=>'required',
     		'amount'=>'required'


     	]);
     }

}
