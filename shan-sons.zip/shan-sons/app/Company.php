<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $guarded = [];


    public function finishStores()
    {
    	return $this->hasMany('App\StoreModel\FinishStore');
    }

}
