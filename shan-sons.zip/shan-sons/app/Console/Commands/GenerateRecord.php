<?php

namespace App\Console\Commands;

use App\Company;
use App\FuelModel\Fuel;
use App\FuelModel\Fuelcatagory;
use App\Gate;
use App\HrModel\Employee;
use App\MainstoreModel\Gatepass;
use App\MainstoreModel\Inventory;
use App\MainstoreModel\Inward;
use App\MainstoreModel\Returnable;
use App\PartynameModel\Daybook;
use App\PartynameModel\Partyname;
use App\PartynameModel\Payroll;
use App\PartynameModel\Purchase;
use App\PartynameModel\Sale;
use App\PartynameModel\Salename;
use App\StoreModel\FinishStore;
use App\StoreModel\Rawmaterial;
use Illuminate\Console\Command;

class GenerateRecord extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'record:create {length}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create dummies record and save them into the database';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $length = $this->argument('length') - '0';

        if ($this->confirm('Are u sure u want to save them into the database?')) 
        {
            //-------------------------//
            //---Create the record-----//
            //-------------------------//

            // for company
            factory(Company::class, $length)->create();
            // for daybook
            // factory(Daybook::class, $length)->create();
            // for employee
            factory(Employee::class, $length)->create();
            // for finishstore
            factory(FinishStore::class, $length)->create();
            // for fuel catagory
            factory(Fuelcatagory::class, $length)->create();
            // for fuel 
            factory(Fuel::class, $length)->create();
            // for gate
            factory(Gate::class, $length)->create();
            // for gatepass
            factory(Gatepass::class, $length)->create();
            // for Inventory
            factory(Inventory::class, $length)->create();
            // for inward
            factory(Inward::class, $length)->create();
            // for partyname
            factory(Partyname::class, $length)->create();
            // for payroll
            factory(Payroll::class, $length)->create();
            // for purchase
            factory(Purchase::class, $length)->create();
            // for raw material store
            factory(Rawmaterial::class, $length)->create();
            // for returnable
            factory(Returnable::class, $length)->create();
            // for sale
            factory(Sale::class, $length)->create();
            // for salename
            factory(Salename::class, $length)->create();


            $this->info('Successfully created the record of length '.$this->argument('length') .' and also save themn into the database');
        } 
        else 
        {
            $this->warn('The record is not save into the database');
        }
        
    }
}
