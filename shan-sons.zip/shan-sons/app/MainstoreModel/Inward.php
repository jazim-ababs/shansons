<?php

namespace App\MainstoreModel;

use Illuminate\Database\Eloquent\Model;

class Inward extends Model
{
    protected $guarded = [];
}
