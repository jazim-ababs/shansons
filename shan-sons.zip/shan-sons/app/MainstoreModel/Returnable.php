<?php

namespace App\MainstoreModel;

use Illuminate\Database\Eloquent\Model;

class Returnable extends Model
{
    protected $guarded = [];
}
