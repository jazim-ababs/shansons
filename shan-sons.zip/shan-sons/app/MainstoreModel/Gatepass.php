<?php

namespace App\MainstoreModel;

use Illuminate\Database\Eloquent\Model;

class Gatepass extends Model
{
    protected $guarded = [];
}
