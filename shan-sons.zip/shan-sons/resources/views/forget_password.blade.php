@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Reest Password
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('password.reset') }}">
                            @csrf

                            <div class="form-group">
                                <label for="email">Email Address:</label>
                                <input type="email" name="email" class="form-control" id="email">
                            </div>
                            @if($errors->has('email'))
                                <span style="color: red; font-size: 14px;">Email is Required</span>
                            @endif

                            <div style="margin-top: 5px;">
                                <input type="submit" class="btn btn-primary" value="Send Password 
                                Reset Link">
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripting')

    @if(Session::has('message'))
        $.notify('{{ Session::get('message') }}', '{{ Session::get('alert-class') }}');
    @endif

@endsection