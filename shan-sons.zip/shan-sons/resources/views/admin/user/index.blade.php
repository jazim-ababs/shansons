
@extends('/admin.dashboard.header')

@section('title')
	
	All Users

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>User</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > User > All Users</p>
	</div>

	<div>
		<a href="{{ route('user.create') }}" class="btn btn-primary">Add New User</a>
	</div>

	<div class="table-responsive someTopMargin">
		
		<table class="table table-hover">
			
			<tr>
				<th>Username</th>
				<th>Email</th>
				<th>Role Type</th>
				<th>Delete</th>
			</tr>	

			@if(count($users) > 0)

				@foreach($users as $user)

					<tr>
						
						<td>{{ $user->name }}</td>
						<td>{{ $user->email }}</td>
						<td>
							<form id="myform" method="POST" action="{{ route('user.action', ['id' => $user->id]) }}">
								
								@csrf	

								<div class="form-group">
                                  <select class="form-control" name="userType" onchange='this.form.submit()'>
                                    
                                    @foreach ($roles as $key => $role)
                                        <option @if($user->role_id == $role) selected @endif value="{{ $role }}">{{ $key }}</option>
                                    @endforeach

								  </select>
								</div>

							</form>
						</td>
						

						{{-- DELETE --}}
						<td><a href="#" data-toggle="modal" data-target="#{{ $user->id }}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

						@component('components.modal', ['obj'=>$user])
							<form method="POST" action="{{ route('user.destroy', ['id' => $user->id]) }}">

								@method('delete')
								@csrf
			
								<input type="submit" class="btn btn-success" value="Yes">
							</form>
						@endcomponent

					</tr>

				@endforeach

			@endif

			


		</table>

	</div>


	<!-- END MAIN DIV -->

@endsection


@section('scripting')

	@include('shared.notification')

@endsection
