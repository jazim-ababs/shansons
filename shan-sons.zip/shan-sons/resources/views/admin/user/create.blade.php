@extends('/admin.dashboard.header')

@section('title')
    Create User
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>User</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > User > Create User</p>
    </div>

    <div>
        <a href="{{ route('user.index') }}" class="btn btn-primary">All Users</a>
    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                    <form method="POST" action="{{ route('user.store') }}">
			
                        @csrf
            
                        <div class="form-group">
                            <label for="name">Username:</label>
                            <input class="form-control" type="text" name="name" value="{{ old('name') }}">
                        </div>
            
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input class="form-control" type="email" name="email" value="{{ old('email') }}">
                        </div>
            
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" class="form-control" id="password">
                        </div>
            
                        <div class="form-group">
                            <label for="c-password">Confirm Password:</label>
                            <input type="password" name="password_confirmation" class="form-control" id="c-password">
                        </div>
            
                        <input type="submit" class="btn btn-success" value="Submit">
            
                    </form>

            </div>

        </div>

    </div>

    <div style="margin-top: 10px"></div>
    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
