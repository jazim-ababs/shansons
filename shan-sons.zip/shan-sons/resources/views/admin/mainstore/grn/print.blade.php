@extends('layouts.print')


@section('title')
    Print Grn
@endsection

@section('reportTitle')
    GRN
@endsection

@push('styling')
    <style>
        .highlight {
            font-size: 17px;
            font-weight: bold;
        }
        .topMargin {
            margin-top: 10px;
        }
    </style>
@endpush


@section('content')

<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          <div class="table-responsive">
            
            <div>
                          
              <table style="margin-top: 20px;" class="table">

                  <tr>
                    <th>Sr No</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Unit</th>
                    <th>Quantity</th>
                    <th>Rate</th>
                    <th>Amount</th>
                  </tr>

                  @foreach($grns as $grn)

						<tr>
							
							<td>{{ $grn->SrNo }}</td>
							<td>{{ $grn->date }}</td>
							<td>{{ $grn->description }}</td>
							<td>{{ $grn->unit }}</td>
							<td>{{ $grn->quantity }}</td>
							<td>{{ $grn->rate }}</td>
							<td>{{ $grn->amount}}</td>
						
						</tr>

					@endforeach

              </table>

            </div>


          </div>

          
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      @include('shared.main-print')
      

      <table style="margin-top: 20px;" class="table">

            <tr>
            <th>Sr No</th>
            <th>Date</th>
            <th>Description</th>
            <th>Unit</th>
            <th>Quantity</th>
            <th>Rate</th>
            <th>Amount</th>
            </tr>

            @foreach($grns as $grn)

                <tr>
                    
                    <td>{{ $grn->SrNo }}</td>
                    <td>{{ $grn->date }}</td>
                    <td>{{ $grn->description }}</td>
                    <td>{{ $grn->unit }}</td>
                    <td>{{ $grn->quantity }}</td>
                    <td>{{ $grn->rate }}</td>
                    <td>{{ $grn->amount}}</td>
                
                </tr>

            @endforeach

        </table>

      @component('components.footer', ['flag'=>true])
      @endcomponent

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>
  
@endsection

@push('scripting')
  <script>
    
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

  </script>
@endpush
