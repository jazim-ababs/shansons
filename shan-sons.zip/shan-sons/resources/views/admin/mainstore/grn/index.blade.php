
@extends('/admin.dashboard.header')

@section('title')
	
	All Outward Gate Pass

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>GRN</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > Main Store > GRN > All Record</p>
	</div>


	@component('components.search-button')
		<a href="/grn/create" class="btn btn-success">Add New Gate Pass</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		 
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Date</th>
		      	<th>Description</th>
		      	<th>Unit</th>
		      	<th>Quantity</th>
		      	<th>Rate</th>
		      	<th>Amount</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($grn as $grns)

						<tr>
							
							<td>{{ $grns->SrNo }}</td>
							<td>{{ $grns->date }}</td>
							<td>{{ $grns->description }}</td>
							<td>{{ $grns->unit }}</td>
							<td>{{ $grns->quantity }}</td>
							<td>{{ $grns->rate }}</td>
							<td>{{ $grns->amount}}</td>
						

							<td><a href="/grn/{{ $grns->id }}/edit" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

                           
							<td><a href="#" data-toggle="modal" data-target="#{{$grns->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							<!-- Modal for Deleting -->
							<div class="modal fade" id="{{$grns->id}}" role="dialog">
							<div class="modal-dialog">
							
								<!-- Modal content-->
								<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Delete</h4>
								</div>
								<div class="modal-body">
									<p>Are sure you want to delete this?</p>
								</div>
								<div class="modal-footer">

									<form method="POST" action="/grn/{{ $grns->id }}">

										@method('delete')
										@csrf

										<input type="submit" class="btn btn-success" value="Yes">
									</form>

									<a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
								</div>
								</div>
								
							</div>
							</div>

						</tr>

					@endforeach
				</tbody>


		  </table>

		</div>
		
	</div>

	<div style="margin-top: 20px">
		<a href="/grn/print" class="btn btn-primary">Print All</a>
	</div>

	@component('components.pagination', ['collection'=>$grn])
	@endcomponent	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

