@extends('/admin.dashboard.header')

@section('title')
    EDIT GRN
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>GRN</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Main Store > GRN > EDIT GRN</p>
    </div>

    <div>
     

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form  method="POST" action="/dn/{{$dn->id}}">
                        {{method_field('PATCH')}}
                            {{csrf_field()}}

                    <div class="form-group">
                        <label for="srNo">Serial Number:</label>
                        <input type="number" class="form-control" id="srNo" name="SrNo" value="{{$dn->SrNo}}">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="{{$dn->date}}">
                    </div>

                    <div class="form-group">
                        <label for="Description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" value="{{$dn->description}}">
                    </div>

                    <div class="form-group">
                        <label for="unit">Unit</label>
                        <input type="text" class="form-control" id="unit" name="unit" value="{{$dn->unit}}">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="{{$dn->quantity}}">
                    </div>

                  
                     <div class="form-group">
                        <label for="amount">Remarks</label>
                        <input type="text" class="form-control" id="remarks" name="remarks" value="{{$dn->remarks}}">
                    </div>



                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Update">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

  

@endsection


