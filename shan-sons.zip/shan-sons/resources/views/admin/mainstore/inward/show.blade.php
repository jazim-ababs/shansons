@component('components.mainstore', ['title'=>'Inward Report', 'store'=>$inward])
@endcomponent