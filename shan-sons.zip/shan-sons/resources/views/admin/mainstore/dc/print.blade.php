@extends('layouts.print')


@section('title')
    Print DC
@endsection

@section('reportTitle')
    DC
@endsection

@push('styling')
    <style>
        .highlight {
            font-size: 17px;
            font-weight: bold;
        }
        .topMargin {
            margin-top: 10px;
        }
    </style>
@endpush


@section('content')

<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          <div class="table-responsive">
            
            <div>
                          
              <table style="margin-top: 20px;" class="table">

                  <tr>
                    <th>Sr No</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Unit</th>
                    <th>Quantity</th>
                    <th>Remarks</th>
                  </tr>

                  @foreach($dcs as $dc)

						<tr>
                            
                            <td>{{ $dc->SrNo }}</td>
							<td>{{ $dc->date }}</td>
							<td>{{ $dc->description }}</td>
							<td>{{ $dc->unit }}</td>
							<td>{{ $dc->quantity }}</td>
							<td>{{ $dc->remarks}}</td>
							
						</tr>

					@endforeach

              </table>

            </div>


          </div>

          
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      @include('shared.main-print')
      

      <table style="margin-top: 20px;" class="table">

            <tr>
            <th>Sr No</th>
            <th>Date</th>
            <th>Description</th>
            <th>Unit</th>
            <th>Quantity</th>
            <th>Remarks</th>
            </tr>

            @foreach($dcs as $dc)

                <tr>
                    
                    <td>{{ $dc->SrNo }}</td>
                    <td>{{ $dc->date }}</td>
                    <td>{{ $dc->description }}</td>
                    <td>{{ $dc->unit }}</td>
                    <td>{{ $dc->quantity }}</td>
                    <td>{{ $dc->remarks}}</td>
                    
                </tr>

            @endforeach

        </table>

      @component('components.footer', ['flag'=>true])
      @endcomponent

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>
  
@endsection

@push('scripting')
  <script>
    
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

  </script>
@endpush
