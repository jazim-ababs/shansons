@component('components.mainstore', ['title'=>'Outward Gatepass', 'store'=>$gatePass])
@endcomponent