
@extends('/admin.dashboard.header')

@section('title')
	
	All Outward Gate Pass

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Outward Gate Pass</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > Main Store > Outward Gate Pass > All Outward Pass</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('gatepass.create') }}" class="btn btn-success">Add New Gate Pass</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($outwards) > 0)
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Date</th>
		      	<th>PartyName</th>
		      	<th>Vehicle No</th>
		      	<th>By Hand</th>
		      	<th>Description</th>
		      	<th>Unit</th>
		      	<th>Quantity</th>
		      	<th>Rate</th>
		      	<th>Price</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($outwards as $outward)

						<tr>
							
							<td>{{ $outward->srNumber }}</td>
							<td>{{ $outward->date }}</td>
							<td>{{ $outward->partyName }}</td>
							<td>{{ $outward->vehicleNumber }}</td>
							<td>{{ $outward->byHand }}</td>
							<td>{{ $outward->description }}</td>
							<td>{{ $outward->unit }}</td>
							<td>{{ $outward->quantity }}</td>
							<td>{{ $outward->box }}</td>
							<td>{{ $outward->price }}</td>

							<td><a href="{{ route('gatepass.show', ['id' => $outward->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="{{ route('gatepass.edit', ['id' => $outward->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$outward->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$outward])
								<form method="POST" action="{{ route('gatepass.destroy', ['id' => $outward->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
				</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	@component('components.pagination', ['collection'=>$outwards])
	@endcomponent
	<!-- END MAIN DIV -->
	@include('shared.get-search')
	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

