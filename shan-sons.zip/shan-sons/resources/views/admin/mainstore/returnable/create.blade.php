@extends('/admin.dashboard.header')

@section('title')
    Create Outward Returnable
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Outward Returnable</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Main Store > Outward Returnable > Create New Outward Returnable</p>
    </div>

    <div>
        
        <a href="{{ route('returnable.index') }}" class="btn btn-primary">Dsiaplay All Returnable</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('returnable.store') }}">

                    @csrf

                    <div class="form-group">
                        <label for="srNumber">Serial Number:</label>
                        <input type="number" class="form-control" id="srNumber" name="srNumber" value="{{old('srNumber')}}">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="{{old('date')}}">
                    </div>

                    <div class="form-group">
                        <label for="partyName">Party Name:</label>
                        <input type="text" class="form-control" id="partyName" name="partyName" value="{{old('partyName')}}">
                    </div>

                    <div class="form-group">
                        <label for="vehicleNumber">Vehicle Number:</label>
                        <input type="text" class="form-control" id="vehicleNumber" name="vehicleNumber" value="{{old('vehicleNumber')}}">
                    </div>

                    <div class="form-group">
                        <label for="byHand">By Hand:</label>
                        <input type="text" class="form-control" id="byHand" name="byHand" value="{{old('byHand')}}">
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <input type="text" class="form-control" id="description" name="description" value="{{old('description')}}">
                    </div>

                     <div class="form-group">
                        <label for="unit">Unit:</label>
                        <input type="text" class="form-control" id="unit" name="unit" value="{{old('unit')}}">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="{{old('quantity')}}">
                    </div>

                    <div class="form-group">
                        <label for="box">Box:</label>
                        <input type="number" class="form-control" id="box" name="box" value="{{old('box')}}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
