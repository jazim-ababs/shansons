@component('components.mainstore', ['title'=>'Outward Returnable', 'store'=>$outward])
    
@endcomponent