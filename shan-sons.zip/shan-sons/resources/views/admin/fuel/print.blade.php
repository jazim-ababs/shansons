
@extends('layouts.print')


@section('title')
    Fuel Report
@endsection

@section('reportTitle')
    Fuel Report
@endsection

@push('styling')
    <style>
        .highlight {
            font-size: 17px;
            font-weight: bold;
        }
        .topMargin {
            margin-top: 10px;
        }
    </style>
@endpush


@section('content')


<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          <div class="table-responsive">
            
            <div>
                          
              <table style="margin-top: 20px;" class="table">

                  <tr>
                    <th>Fuel Catagory</th>
                    <th>Opening Balance</th>
                    <th>Sr No</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>UOM</th>
                    <th>Issue</th>
                    <th>Received</th>
                    <th>Balance</th>
                    <th>Total</th>
                  </tr>

                  <tr>
                    
                      <td>{{ $fuel->fuelcatagory->fuelCatagory }}</td>
                      <td>{{ $fuel->openingBalance }}</td>
                      <td>{{ $fuel->srNo }}</td>
                      <td>{{ $fuel->name }}</td>
                      <td>{{ $fuel->description }}</td>
                      <td>{{ $fuel->uom }}</td>
                      <td>{{ $fuel->issue }}</td>
                      <td>{{ $fuel->received }}</td>
                      <td>{{ $fuel->balance }}</td>
                      <td>{{ $fuel->total }}</td>

                  </tr>  

              </table>

            </div>


          </div>

          
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      <div class="container">
        <div class="row">
          <div class=" col-md-12 ">
            <h1><center><font color="blue"> SHAN SON'S ENGINEERING WORKS</font></center></h1>
         
            <h4><b><center>Stock Register Of Finished Goods </center></b></h4><hr>
            <h3><center> Single Gate Report</center></h3>

          </div>
        </div>
      </div>
      

      <table style="margin-top: 100px;" class="table">
        
        <tr>
          <th>Fuel Catagory</th>
          <th>Opening Balance</th>
          <th>Sr No</th>
          <th>Name</th>
          <th>Description</th>
          <th>UOM</th>
          <th>Issue</th>
          <th>Received</th>
          <th>Balance</th>
          <th>Total</th>
        </tr>

        <tr>
          
            <td>{{ $fuel->fuelcatagory->fuelCatagory }}</td>
            <td>{{ $fuel->openingBalance }}</td>
            <td>{{ $fuel->srNo }}</td>
            <td>{{ $fuel->name }}</td>
            <td>{{ $fuel->description }}</td>
            <td>{{ $fuel->uom }}</td>
            <td>{{ $fuel->issue }}</td>
            <td>{{ $fuel->received }}</td>
            <td>{{ $fuel->balance }}</td>
            <td>{{ $fuel->total }}</td>

        </tr>  

      </table>

      @component('components.footer', ['flag'=>false])
      @endcomponent

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>


  @push('scripting')
    <script>
      
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

    </script>
  @endpush


@endsection