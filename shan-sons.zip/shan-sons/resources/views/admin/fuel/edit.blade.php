@extends('/admin.dashboard.header')

@section('title')
    Edit Fuel
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Fuel</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Main Store > Fuel </p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('fuel.update', ['id' => $fuel->id]) }}">

                    @method('PATCH')
                    @csrf

                    @if(count($fuelCatagories) > 0)  
                        <div class="form-group">
                          <label for="sel1">Select Fuel Catagory:</label>
                          <select class="form-control" id="sel1" name="fuelcatagory_id">
                            
                            @foreach($fuelCatagories as $fuelCatagory)

                                <option value="{{ $fuelCatagory->id }}" @if($fuel->fuelcatagory->id == $fuelCatagory->id) selected="selected" @endif>{{ $fuelCatagory->fuelCatagory }}</option>

                            @endforeach

                          </select>
                        </div>

                    @endif


                    <div class="form-group">
                        <label for="openingBalance">Opening Balance:</label>
                        <input type="number" class="form-control" id="openingBalance" name="openingBalance" value="{{ $fuel->openingBalance }}">
                    </div>

                    <div class="form-group">
                        <label for="srNo">Sr No:</label>
                        <input type="number" class="form-control" id="srNo" name="srNo" value="{{ $fuel->srNo }}">
                    </div>

                    <div class="form-group">
                        <label for="name">Issue To:</label>
                        <input type="text" class="form-control" id="name" name="name" value="{{ $fuel->name }}">
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <input type="text" class="form-control" id="description" name="description" value="{{ $fuel->description }}">
                    </div>

                    <div class="form-group">
                        <label for="uom">UOM:</label>
                        <input type="text" class="form-control" id="uom" name="uom" value="{{ $fuel->uom }}">
                    </div>

                    <div class="form-group">
                        <label for="issue">Issue:</label>
                        <input type="date" class="form-control" id="issue" name="issue" value="{{ $fuel->issue }}">
                    </div>

                    <div class="form-group">
                        <label for="received">Received:</label>
                        <input type="text" class="form-control" id="received" name="received" value="{{ $fuel->received }}">
                    </div>

                    <div class="form-group">
                        <label for="balance">Balance:</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="{{ $fuel->balance }}">
                    </div>

                    <div class="form-group">
                        <label for="total">Total:</label>
                        <input type="number" class="form-control" id="total" name="total" value="{{ $fuel->total }}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')

    @include('shared.notification')

@endsection
