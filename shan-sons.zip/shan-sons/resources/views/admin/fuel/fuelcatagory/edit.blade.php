@extends('/admin.dashboard.header')

@section('title')
    Edit Fuel Catagory
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Edit Fuel Catagory</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Edit Fuel Catagory</p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('fuelcatagory.update', ['id' => $fuelCatagory->id]) }}">

                    @method('PATCH')
                    @csrf

                    <div class="form-group">
                        <label for="fuelCatagory">Fuel Catogory Name:</label>
                        <input type="text" class="form-control" id="fuelCatagory" name="fuelCatagory" value="{{ $fuelCatagory->fuelCatagory }}">
                    </div>



                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')

    @include('shared.notification')

@endsection
