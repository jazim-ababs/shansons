
@extends('/admin.dashboard.header')

@section('title')
	
	All Fuel Catagories

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Fuel Catagory</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Fuel Catagory</p>
	</div>

	<div>
		
		<a href="{{ route('fuelcatagory.create') }}" class="btn btn-success">Add New Fuel Catagory</a>

	</div>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($fuelCatagories) > 0)
		    
		      <tr>
		      	<th>Fuel Catagory Name</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>


		      @foreach($fuelCatagories as $fuelCatagory)

		        <tr>
		        	
		        	<td>{{ $fuelCatagory->fuelCatagory }}</td>

		        	<td><a href="{{ route('fuelcatagory.edit', ['id' => $fuelCatagory->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

					<td><a href="#" data-toggle="modal" data-target="#{{$fuelCatagory->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>
					
					@component('components.modal', ['obj'=>$fuelCatagory])
						<form method="POST" action="{{ route('fuelcatagory.destroy', ['id'=>$fuelCatagory->id]) }}">

							@method('delete')
							@csrf

							<input type="submit" class="btn btn-success" value="Yes">
						</form>
					@endcomponent

		        </tr>

		      @endforeach

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>



	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')

@endsection

