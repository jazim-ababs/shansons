
@extends('/admin.dashboard.header')

@section('title')
	
	All {{ $catagoryName }} List

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>{{ $catagoryName }}</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > Main Store > Fuel > All {{ $catagoryName }} List</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('fuel.create') }}" class="btn btn-success">Add New Fuel</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($fuels) > 0)
		    
		      <tr>
		      	<th>Fuel Catagory</th>
		      	<th>Opening Balance</th>
		      	<th>Sr No</th>
		      	<th>Name</th>
		      	<th>Description</th>
		      	<th>UOM</th>
		      	<th>Issue</th>
		      	<th>Received</th>
		      	<th>Balance</th>
		      	<th>Total</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($fuels as $fuel)

						<tr>
							
							<td>{{ $fuel->fuelcatagory->fuelCatagory }}</td>
							<td>{{ $fuel->openingBalance }}</td>
							<td>{{ $fuel->srNo }}</td>
							<td>{{ $fuel->name }}</td>
							<td>{{ $fuel->description }}</td>
							<td>{{ $fuel->uom }}</td>
							<td>{{ $fuel->issue }}</td>
							<td>{{ $fuel->received }}</td>
							<td>{{ $fuel->balance }}</td>
							<td>{{ $fuel->total }}</td>

							<td><a href="{{ route('fuel.singleprint', ['id' => $fuel->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="{{ route('fuel.edit', ['id' => $fuel->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$fuel->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$fuel])
								<form method="POST" action="{{ route('fuel.destroy', ['id' => $fuel->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
				</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>

	

	@component('components.pagination', ['collection'=>$fuels])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

