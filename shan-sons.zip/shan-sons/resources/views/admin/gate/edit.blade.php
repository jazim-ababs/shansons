@extends('/admin.dashboard.header')

@section('title')
    Edit Gate
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Gate</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Gate</p>
    </div>


    <div>

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('gate.update', ['id'=>$gate->id]) }}">

                    @method('PATCH')
                    @csrf

                    <div class="form-group">
                        <label for="srNumber">Serial Number:</label>
                        <input type="number" class="form-control" id="srNumber" name="srNumber" value="{{ $gate->srNumber }}">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="{{ $gate->date }}">
                    </div>

                    <div class="form-group">
                        <label for="timing">Timing:</label>
                        <input type="time" class="form-control" id="timing" name="timing" value="{{ $gate->timing }}">
                    </div>

                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" value="{{ $gate->name }}">
                    </div>

                    <div class="form-group">
                        <label for="vehicleNumber">Vehicle Number:</label>
                        <input type="text" class="form-control" id="vehicleNumber" name="vehicleNumber" value="{{ $gate->vehicleNumber }}">
                    </div>

                    <div class="form-group">
                        <label for="contactInfo">Contact Info:</label>
                        <input type="text" class="form-control" id="contactInfo" name="contactInfo" value="{{ $gate->contactInfo }}">
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <input type="text" class="form-control" id="description" name="description" value="{{ $gate->description }}">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="{{ $gate->quantity }}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')

    @include('shared.notification')

@endsection
