@extends('layouts.print')


@section('title')
    Gate Pass
@endsection

@section('reportTitle')
    Gate Pass
@endsection

@push('styling')
    <style>
        .highlight {
            font-size: 17px;
            font-weight: bold;
        }
        .topMargin {
            margin-top: 10px;
        }
    </style>
@endpush


@section('content')

<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          <div class="table-responsive">
            
            <div>
                          
              <table style="margin-top: 20px;" class="table">

                  <tr>
                      <th>Sr No</th>
                      <th>Date</th>
                      <th>Time</th>
                      <th>Name</th>
                      <th>Vehicle No</th>
                      <th>Contact Info</th>
                      <th>Description</th>
                      <th>Quantity</th>
                  </tr>

                  <tr>
                    
                      <td>{{ $gate->srNumber }}</td>
                      <td>{{ $gate->date }}</td>
                      <td>{{ $gate->timing }}</td>
                      <td>{{ $gate->name }}</td>
                      <td>{{ $gate->vehicleNumber }}</td>
                      <td>{{ $gate->contactInfo }}</td>
                      <td>{{ $gate->description }}</td>
                      <td>{{ $gate->quantity }}</td>

                  </tr>  

              </table>

            </div>


          </div>

          
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      @include('shared.main-print')
      

      <table style="margin-top: 100px;" class="table">
        
        <tr>
            <th>Sr No</th>
            <th>Date</th>
            <th>Time</th>
            <th>Name</th>
            <th>Vehicle No</th>
            <th>Contact Info</th>
            <th>Description</th>
            <th>Quantity</th>
        </tr>

        <tr>
          
            <td>{{ $gate->srNumber }}</td>
            <td>{{ $gate->date }}</td>
            <td>{{ $gate->timing }}</td>
            <td>{{ $gate->name }}</td>
            <td>{{ $gate->vehicleNumber }}</td>
            <td>{{ $gate->contactInfo }}</td>
            <td>{{ $gate->description }}</td>
            <td>{{ $gate->quantity }}</td>

        </tr>

      </table>

      @component('components.footer', ['flag'=>true])
      @endcomponent

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>
  
@endsection

@push('scripting')
  <script>
    
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

  </script>
@endpush
