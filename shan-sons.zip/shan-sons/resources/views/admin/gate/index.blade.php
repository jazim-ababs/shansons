
@extends('/admin.dashboard.header')

@section('title')
	
	All Gates

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Gate</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Company</p>
	</div>

	@component('components.search-button')
		<a href="{{ route('gate.create') }}" class="btn btn-success">
			Add New Gate
		</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($gates) > 0)
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Date</th>
		      	<th>Time</th>
		      	<th>Name</th>
		      	<th>Vehicle No</th>
		      	<th>Contact Info</th>
		      	<th>Description</th>
		      	<th>Quantity</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  <tbody id="myTable">
				@foreach($gates as $gate)

					<tr>
						
						<td>{{ $gate->srNumber }}</td>
						<td>{{ $gate->date }}</td>
						<td>{{ $gate->timing }}</td>
						<td>{{ $gate->name }}</td>
						<td>{{ $gate->vehicleNumber }}</td>
						<td>{{ $gate->contactInfo }}</td>
						<td>{{ $gate->description }}</td>
						<td>{{ $gate->quantity }}</td>

						<td><a href="{{ route('gate.single', ['id' => $gate->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

						<td><a href="{{ route('gate.edit', ['id' => $gate->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

						@inject('restriction', 'App\Custom\RestrictRole')
						
						@if($restriction->roleExists(true, 'admin'))
							<td><a href="#" data-toggle="modal" data-target="#{{$gate->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$gate])
								<form method="POST" action="{{ route('gate.destroy', ['id'=>$gate->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						@endif

					</tr>

				@endforeach
			  </tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	<!-- END MAIN DIV -->
	@component('components.pagination', ['collection'=>$gates])
	@endcomponent
	
	<div style="margin-top:20px;">
		<a href="{{ route('gate.printall') }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print All</span></i></a>
	</div>


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')
	

@endsection

