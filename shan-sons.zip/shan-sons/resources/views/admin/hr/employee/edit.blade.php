@extends('/admin.dashboard.header')

@section('title')
    Edit Gate
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Employee</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > HR > Employee > Edit Employee</p>
    </div>


    <div>

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('employee.update', ['id'=>$employee->id]) }}">

                    @method('PATCH')
                    @csrf

                    <div class="form-group">
                        <label for="employeeNo">Employee Number:</label>
                        <input type="number" class="form-control" id="employeeNo" name="employeeNo" value="{{ $employee->employeeNo }}">
                    </div>

                    
                    <div class="form-group">
                        <label for="name">Employee Name:</label>
                        <input type="text" class="form-control" id="name" name="name" value="{{ $employee->name }}">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="{{ $employee->date }}">
                    </div>

                    <div class="form-group">
                        <label for="mobileNo">Mobile Number:</label>
                        <input type="number" class="form-control" id="mobileNo" name="mobileNo" value="{{ $employee->mobileNo }}">
                    </div>

                    <div class="form-group">
                        <label for="address">Employee Address:</label>
                        <input type="text" class="form-control" id="address" name="address" value="{{ $employee->address }}">
                    </div>

                    <div class="form-group">
                        <label for="department">Department:</label>
                        <input type="text" class="form-control" id="department" name="department" value="{{ $employee->department }}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')

    @include('shared.notification')

@endsection
