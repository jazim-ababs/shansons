
@extends('/admin.dashboard.header')

@section('title')
	
	All Employees

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Employee</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > HR > Employee > All Employees</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('employee.create') }}" class="btn btn-success">Add New Employee</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($employees) > 0)
		    
		      <tr>
		      	<th>Employee No</th>
		      	<th>Name</th>
		      	<th>Date</th>
		      	<th>Mobile No</th>
		      	<th>Address</th>
		      	<th>Department</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($employees as $employee)

						<tr>
							
							<td>{{ $employee->employeeNo }}</td>
							<td>{{ $employee->name }}</td>
							<td>{{ $employee->date }}</td>
							<td>{{ $employee->mobileNo }}</td>
							<td>{{ $employee->address }}</td>
							<td>{{ $employee->department }}</td>

							<td><a href="{{ route('employee.edit', ['id'=> $employee->id ]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$employee->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$employee])
								<form method="POST" action="{{ route('employee.destroy', ['id' => $employee->id ]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>

	@component('components.pagination', ['collection'=>$employees])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

