
@extends('/admin.dashboard.header')

@section('title')
	
	All Companies

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Company</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > FinishStore </p>
	</div>


	@component('components.search-button')
		<a href="{{ route('finishstore.create', ['companyId'=>$companyId]) }}" class="btn btn-success">Add New Finish Store</a>
	@endcomponent

	<div class="table-responsive someTopMargin">
		
		<table class="table table-hover">
			
			<tr>
				<th>Company Name</th>
				<th>Date</th>
				<th>Item Description</th>
				<th>Opening Balance</th>
				<th>Today Packing</th>
				<th>Total Balance</th>
				<th>Deliver QTV</th>
				<th>Reveive</th>
				<th>Balance in Hand</th>
				<th>Update</th>
				<th>Delete</th>
			</tr>	

			@if(count($finishStores) > 0)

				<tbody id="myTable">
					@foreach($finishStores as $finishStore)

						<tr>
							<td>{{ $finishStore->company->companyName }}</td>
							<td>{{ $finishStore->date }}</td>
							<td>{{ $finishStore->description}}</td>
							<td>{{ $finishStore->openingBalance }}</td>
							<td>{{ $finishStore->packing }}</td>
							<td>{{ $finishStore->endingBalance }}</td>
							<td>{{ $finishStore->qtv }}</td>
							<td>{{ $finishStore->receive }}</td>
							<td>{{ $finishStore->balance }}</td>

							<td><a href="{{ route('finishstore.edit', ['companyId'=>$finishStore->company->id, 'finishstore'=>$finishStore->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$finishStore->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$finishStore])
								<form method="POST" action="{{ route('finishstore.destroy', ['companyId'=>$finishStore->company->id, 'finishstore'=>$finishStore->id]) }}">
			
									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
				</tbody>


			@endif


		</table>

	</div>


	@component('components.pagination', ['collection'=>$finishStores])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

