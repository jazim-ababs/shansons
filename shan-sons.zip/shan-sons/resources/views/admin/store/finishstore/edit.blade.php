@extends('/admin.dashboard.header')

@section('title')
    Edit Finish Store
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Finish Store</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Store > Finish Store > Edit Record</p>
    </div>


    <div>

        <form id="myForm" method="POST" action="{{ route('finishstore.update', ['companyId'=>$finishStore->company->id, 'finishstore'=>$finishStore->id]) }}">
            
            @method('PATCH')
            @csrf

            <input type="hidden" name="company_id" value="{{ $finishStore->company->id }}">

            <div class="form-group">
                <label for="companyName">Company Name:</label>
                <input disabled type="text" class="form-control" id="companyName" value="{{ $finishStore->company->companyName }}">
            </div>

            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" value="{{ $finishStore->date }}">
            </div>

            <div class="form-group">
                <label for="description">Item Description:</label>
            <textarea class="form-control" name="description" rows="5" id="description">{!! $finishStore->description !!}</textarea>
            </div> 

            <div class="form-group">
                <label for="openingBalance">Opening Balance:</label>
                <input type="number" class="form-control" id="openingBalance" name="openingBalance" value="{{ $finishStore->openingBalance }}">
            </div>

            <div class="form-group">
                <label for="packing">Today Packing:</label>
                <input type="text" class="form-control" id="packing" name="packing" value="{{ $finishStore->packing }}">
            </div>

            <div class="form-group">
                <label for="qtv">Deliver QTV:</label>
                <input type="number" class="form-control" id="qtv" name="qtv" value="{{ $finishStore->qtv }}">
            </div>

            <div class="form-group">
                <label for="receive">Reveive:</label>
                <input type="number" class="form-control" id="receive" name="receive" value="{{ $finishStore->receive }}">
            </div>

           
            <div class="form-group ">

                <input type="submit" class="btn btn-success" value="Submit">
                <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

            </div>

        </form>

    </div>

    @include('/error')

@endsection


@section('scripting')

    @include('shared.notification')

@endsection
