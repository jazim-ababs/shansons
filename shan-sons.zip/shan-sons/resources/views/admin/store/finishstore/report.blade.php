
@extends('layouts.print')


@section('title')
    Finish Store Report
@endsection

@section('reportTitle')
    Finish Store Report
@endsection


@section('content')


<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          @component('components.finish-store', ['date'=>$date, 'companyName'=>$companyName, 'finishStores'=>$finishStores])
          @endcomponent

          


        
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      @include('shared.main-print')
      

      @component('components.finish-store', ['date'=>$date, 'companyName'=>$companyName, 'finishStores'=>$finishStores])
      @endcomponent

      @component('components.footer', ['flag'=>false])
      @endcomponent

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>

  @push('scripting')
    
    <script>
      
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

    </script>

  @endpush
  
  
@endsection