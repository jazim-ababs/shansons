
@extends('/admin.dashboard.header')

@section('title')
	
	All Companies

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Company</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > FinishStore </p>
	</div>

	<div>
		
		<a href="{{ route('company.create') }}" class="btn btn-success">Add New Compnay</a>

	</div>

	<div class="table-responsive someTopMargin">
		
		<table class="table table-hover">
			
			<tr>
				<th>Serial Number</th>
				<th>Company Name</th>
				<th>Create Record</th>
				<th>Print</th>
				<th>Display Record</th>
			</tr>	

			@if(count($companies) > 0)

				@foreach($companies as $company)

					<tr>
						<td>{{ $company->id }}</td>
						<td>{{ $company->companyName }}</td>
						<td>
							<a href="{{ route('finishstore.create', ['id'=>$company->id]) }}" class="btn btn-warning">
							<i class="fa fa-plus" aria-hidden="true"></i> Create
							</a>
						</td>
						<td>
							<a href="#{{ $company->id }}" data-toggle="modal" data-target="#{{$company->id}}"class="btn btn-primary">
							<i class="fa fa-print" aria-hidden="true"></i> Print
							</a>
						</td>
						<td>
							<a href="{{ route('finishstore.index', ['companyId' => $company->id]) }}" class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> Display</a>
						</td>

						<!-- Modal for Deleting -->
						<div class="modal fade" id="{{$company->id}}" role="dialog">
						  <div class="modal-dialog">


						  
						    <!-- Modal content-->
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal">&times;</button>
						        <h4 class="modal-title">Display Record</h4>
						      </div>
						      <div class="modal-body">
						        <div>
						        	{{-- <form method="GET" action="">
						        		<div class="form-group">
						        			<label for="date">Select Date:</label>
						        			<div type="text" class="form-control" id="date" name="date"></div>
						        		</div>
						        	</form> --}}
						        	<form method="POST" action="{{ route('finishstore.selectDate', ['companyId'=>$company->id]) }}">
						        		@csrf

						        		<div class="form-group">
						        			<label>Select Date:</label>
						        			<input type="date" class="form-control" name="date">
						        		</div>
						        		<input type="submit" class="btn btn-success" value="Submit">
						        	</form>
						        </div>
						      </div>
						      <div class="modal-footer">

						      	{{-- <form method="GET" action="">

						      		<input type="submit" class="btn btn-success" value="Yes">
						      	</form> --}}

						        <a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
						      </div>
						    </div>
						    
						  </div>
						</div>

					</tr>

				@endforeach


			@endif


		</table>

	</div>


	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')

@endsection

