
@extends('/admin.dashboard.header')

@section('title')
	
	All Raw Material Store

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Raw Material Store</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Store > Raw Material Store > Display All Records</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('raw.create') }}" class="btn btn-success">Add New Raw Material Store</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($raws) > 0)
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Date</th>
		      	<th>Description</th>
		      	<th>UOM</th>
		      	<th>Issue</th>
		      	<th>Balance</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($raws as $raw)

						<tr>
							
							<td>{{ $raw->srNumber }}</td>
							<td>{{ $raw->date }}</td>
							<td>{{ $raw->description }}</td>
							<td>{{ $raw->uom }}</td>
							<td>{{ $raw->issue }}</td>
							<td>{{ $raw->balance }}</td>

							<td><a href="{{ route('raw.show', ['id' => $raw->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="{{ route('raw.edit', ['id' => $raw->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$raw->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$raw])
								<form method="POST" action="{{ route('raw.destroy', ['id' => $raw->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	@component('components.pagination', ['collection'=>$raws])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

