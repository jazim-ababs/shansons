
@extends('/admin.dashboard.header')

@section('title')
	
	All Companies

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Company</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Company</p>
	</div>

	{{-- <div>
		
		<a href="{{ route('company.create') }}" class="btn btn-success">Add New Compnay</a>

	</div>

	<div class="row">
		<div class="col-md-2">
			<input type="text" class="form-control" id="searchInput">
		</div>
	</div> --}}

	@component('components.search-button')
		<a href="{{ route('company.create') }}" class="btn btn-success">Add New Company</a>
	@endcomponent

	<div class="table-responsive someTopMargin">
		
		<table class="table table-hover">
			
			<tr>
				<th>Company Name</th>
				<th>Address</th>
				<th>Phone Number</th>
				<th>NTN Number</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>	

			@if(count($companies) > 0)

				<tbody id="myTable">
					@foreach($companies as $company)

						<tr>
							
							<td>{{ $company->companyName }}</td>
							<td>{{ $company->address }}</td>
							<td>{{ $company->number }}</td>
							<td>{{ $company->ntnNumber }}</td>
							
							<td><a href="{{ route('company.edit', ['id' => $company->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$company->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$company])
								<form method="POST" action="{{ route('company.destroy', ['id' => $company->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
				</tbody>

			@endif


		</table>

	</div>

	{{-- pagination component --}}
	@component('components.pagination', ['collection'=>$companies])
	@endcomponent

	

	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')
	
@endsection

