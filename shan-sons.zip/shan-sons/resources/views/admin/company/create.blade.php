@extends('/admin.dashboard.header')

@section('title')
    Create Company
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Company</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Create New Company</p>
    </div>

    <div>
        <a href="{{ route('company.index') }}" class="btn btn-primary">Dsiaplay All Companies</a>
    </div>

    <div style="margin-top: 20px;"></div>

    <div>

        <form id="myForm" method="POST" action="{{ route('company.store') }}">

            @csrf

            <div class="form-group">
                <label for="companyName">Company Name:</label>
                <input type="text" class="form-control" id="companyName" name="companyName" value="{{old('companyName')}}">
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" class="form-control" id="address" name="address" value="{{old('address')}}">
            </div>

            <div class="form-group">
                <label for="number">Number:</label>
                <input type="number" class="form-control" id="number" name="number" value="{{old('number')}}">
            </div>

            <div class="form-group">
                <label for="ntnNumber">NTN Number: </label>
                <input type="number" name="ntnNumber" class="form-control" id="ntnNumber" value="{{ old('ntnNumber') }}">
            </div>

            <div class="form-group ">

                <input type="submit" class="btn btn-success" value="Submit">
                <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

            </div>

        </form>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
