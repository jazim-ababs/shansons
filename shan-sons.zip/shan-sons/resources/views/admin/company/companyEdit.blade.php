
@extends('/admin.dashboard.header')

@section('title')
	
	Edit the Company

@endsection


@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Company</small>
	</h1>

	<div class="alert alert-info">
		<h3>Dashboard > Edit Company</h3>
	</div>


	<div>
		
		<form id="myForm" method="POST" action="{{ route('company.update', ['id' => $company->id]) }}">

			@method('PATCH')
			@csrf
			
			<div class="form-group">
			    <label for="companyName">Company Name:</label>
			    <input type="text" class="form-control" id="companyName" name="companyName" value="{{ $company->companyName }}">
			</div>

			<div class="form-group">
			    <label for="address">Address:</label>
			    <input type="text" class="form-control" id="address" name="address" value="{{ $company->address }}">
			</div>

			<div class="form-group">
			    <label for="number">Number:</label>
			    <input type="number" class="form-control" id="number" name="number" value="{{ $company->number }}">
			</div>

			<div class="form-group">
				<label for="ntnNumber">NTN Number:</label>
				<input type="number" name="ntnNumber" id="ntnNumber" class="form-control" value="{{ $company->ntnNumber }}">
			</div>

			<div class="form-group ">
				
				<input type="submit" class="btn btn-success" value="Submit">
				
			</div>

		</form>

	</div>

	@include('/error')

	

	

	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')

	@include('shared.notification')

@endsection




