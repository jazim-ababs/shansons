@extends('/admin.dashboard.header')

@section('title')
    Edit Prfole
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Profile</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Profile > Edit Profile</p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                    <form method="POST" action="{{ route('profile.update', ['id' => auth()->user()->id]) }}">
			
                        @method('PATCH')
                        @csrf
            
                        <div class="form-group">
                            <label for="name">Username:</label>
                            <input class="form-control" type="text" name="name" value="{{ Auth::user()->name }}">
                        </div>
            
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input class="form-control" disabled  type="email" name="email" value="{{ Auth::user()->email }}">
                        </div>
            
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" class="form-control" id="password">
                        </div>
            
                        <div class="form-group">
                            <label for="c-password">Confirm Password:</label>
                            <input type="password" name="password_confirmation" class="form-control" id="c-password">
                        </div>
            
                        <input type="submit" class="btn btn-primary" value="Update Password">
            
                    </form>

            </div>

        </div>

    </div>

    <div style="margin-top: 10px"></div>
    @include('/error')

@endsection


@section('scripting')

    @include('shared.notification')

@endsection
