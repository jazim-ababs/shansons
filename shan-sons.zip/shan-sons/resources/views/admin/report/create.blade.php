@extends('/admin.dashboard.header')

@section('title')
    Create Rejected Report
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Rejected Report</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Create Record</p>
    </div>

    <div>
        <a href="{{ route('rejectedReport.index') }}" class="btn btn-primary">Dsiaplay All Records</a>
    </div>

    <div style="margin-top: 20px;"></div>

    <div class="row">

        <div class="col-md-8 col-md-offset-2">
            <form id="myForm" method="POST" action="{{ route('rejectedReport.store') }}">
                @csrf

                <div class="form-group">
                    <label for="partyname">Party Name:</label>
                    <input type="text" class="form-control" id="partyname" name="partyname" value="{{old('partyname')}}">
                </div>

                <div class="form-group">
                    <label for="totalBalance">Total Balance:</label>
                    <input type="number" class="form-control" id="totalBalance" name="totalBalance" value="{{old('totalBalance')}}">
                </div>

                <div class="form-group">
                    <label for="description">Description:</label>
                    <input type="text" class="form-control" id="description" name="description" value="{{old('description')}}">
                </div>

                <div class="form-group">
                    <label for="process">Process: </label>
                    <input type="text" name="process" class="form-control" id="process" value="{{ old('process') }}">
                </div>

                <div class="form-group">
                    <label for="workerName">Worker Name: </label>
                    <input type="text" name="workerName" class="form-control" id="workerName" value="{{ old('workerName') }}">
                </div>

                <div class="form-group">
                    <label for="checkBy">Check By: </label>
                    <input type="text" name="checkBy" class="form-control" id="checkBy" value="{{ old('checkBy') }}">
                </div>

                <div class="form-group">
                    <label for="balance">Balance: </label>
                    <input type="number" name="balance" class="form-control" id="balance" value="{{ old('balance') }}">
                </div>

                <div class="form-group ">

                    <input type="submit" class="btn btn-success" value="Submit">
                    <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                </div>

            </form>
        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
