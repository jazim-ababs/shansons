@extends('/admin.dashboard.header')

@section('title')
    Edit Rejected Report
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Rejected Report</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Edit Record</p>
    </div>

    <div style="margin-top: 20px;"></div>

    <div class="row">

        <div class="col-md-8 col-md-offset-2">
            <form id="myForm" method="POST" action="{{ route('rejectedReport.update', ['rejectedReport'=>$report->id]) }}">
                @csrf
                @method('PATCH')

                <div class="form-group">
                    <label for="partyname">Party Name:</label>
                    <input type="text" class="form-control" id="partyname" name="partyname" value="{{ $report->partyname }}">
                </div>

                <div class="form-group">
                    <label for="totalBalance">Total Balance:</label>
                    <input type="number" class="form-control" id="totalBalance" name="totalBalance" value="{{ $report->totalBalance }}">
                </div>

                <div class="form-group">
                    <label for="description">Description:</label>
                    <input type="text" class="form-control" id="description" name="description" value="{{ $report->description }}">
                </div>

                <div class="form-group">
                    <label for="process">Process: </label>
                    <input type="text" name="process" class="form-control" id="process" value="{{ $report->process }}">
                </div>

                <div class="form-group">
                    <label for="workerName">Worker Name: </label>
                    <input type="text" name="workerName" class="form-control" id="workerName" value="{{ $report->workerName }}">
                </div>

                <div class="form-group">
                    <label for="checkBy">Check By: </label>
                    <input type="text" name="checkBy" class="form-control" id="checkBy" value="{{ $report->checkBy }}">
                </div>

                <div class="form-group">
                    <label for="balance">Balance: </label>
                    <input type="number" name="balance" class="form-control" id="balance" value="{{ $report->balance }}">
                </div>

                <div class="form-group ">

                    <input type="submit" class="btn btn-success" value="Submit">
                    <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                </div>

            </form>
        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
