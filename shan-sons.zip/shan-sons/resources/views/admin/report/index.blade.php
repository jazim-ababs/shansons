
@extends('/admin.dashboard.header')

@section('title')
	
	All Rejected Reports

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Rejected Reprots</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Rejected Reports > All Records</p>
	</div>

	@component('components.search-button')
		<a href="{{ route('rejectedReport.create') }}" class="btn btn-success">
			Add New Record
		</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($reports) > 0)
		    
		      <tr>
		      	<th>Partyname</th>
		      	<th>Total Balance</th>
		      	<th>Description</th>
		      	<th>Process</th>
		      	<th>Worker Name</th>
		      	<th>Description</th>
		      	<th>Check By</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  <tbody id="myTable">
				@foreach($reports as $report)

					<tr>
						
						<td>{{ $report->partyname }}</td>
						<td>{{ $report->totalBalance }}</td>
						<td>{{ $report->description }}</td>
						<td>{{ $report->process }}</td>
						<td>{{ $report->workerName }}</td>
						<td>{{ $report->checkBy }}</td>
						<td>{{ $report->balance }}</td>

						<td><a href="" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

						<td><a href="{{ route('rejectedReport.edit', ['rejectedReport'=>$report->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

						
                        <td><a href="#" data-toggle="modal" data-target="#{{$report->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

                        @component('components.modal', ['obj'=>$report])
                            <form method="POST" action="{{ route('rejectedReport.destroy', ['rejectedReport'=>$report->id]) }}">

                                @method('delete')
                                @csrf

                                <input type="submit" class="btn btn-success" value="Yes">
                            </form>
                        @endcomponent

					</tr>

				@endforeach
			  </tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	<!-- END MAIN DIV -->
	@component('components.pagination', ['collection'=>$reports])
	@endcomponent
	
	<div style="margin-top:20px;">
		<a href="" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print All</span></i></a>
	</div>


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')
	

@endsection

