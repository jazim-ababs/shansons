
@extends('/admin.dashboard.header')

@section('title')
	
	Profit

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}
        .div-margin {
            margin-top: 7px;
        }

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Profit</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Profit</p>
	</div>

	<div>
		
    <a href="{{ route('profit.create') }}" class="btn btn-success">Calculate Profit</a>

	</div>

	
    
    
    @if(count($sales) > 0)
        <div style="margin-top: 20px;">

            <div class="row">
                
                <div class="col-md-8 col-md-offset-2">
                    
                    <form>


                        @foreach($sales as $sale)

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-5">
                                        <label>{{ $sale['name'] }}:</label>
                                    </div>
                                    <div class="col-md-7">
                                        <input disabled type="number" class="form-control" value="{{ $sale['price'] }}">
                                    </div>
                                </div>
                            </div>

                            <div class="div-margin"></div>

                        @endforeach


                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-5">
                                    <label>Total Revenues: </label>
                                </div>
                                <div class="col-md-7">
                                    <input disabled type="text" class="form-control" value="{{ $totalRevenue }}">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-5">
                                    <label>Total Expenses: </label>
                                </div>
                                <div class="col-md-7">
                                    <input disabled type="text" class="form-control" value="{{ $totalExpenses }}">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-5">
                                    <label>Profit: </label>
                                </div>
                                <div class="col-md-7">
                                    <input disabled type="text" class="form-control" value="{{ $profit }}">
                                </div>
                            </div>
                        </div>

                        {{-- Print Button --}}
                        <div>
                            <a href="{{ route('profit.show', ['date'=>$date]) }}" class="btn btn-primary">Print</a>
                        </div>

                    </form>

                </div>

            </div>

        </div>

        @else
            <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

    @endif
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	
    @include('shared.notification')
	

@endsection

