
@extends('/admin.dashboard.header')

@section('title')
	
	All Expenses

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Expenses</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Expenses > All Record</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('expenses.createpage') }}" class="btn btn-success">Add New Expenses</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($expenses) > 0)
		    
		      <tr>
		      	<th>Date</th>
		      	<th>Advance Salary</th>
		      	<th>Entertainment</th>
		      	<th>Fuel Expenses</th>
		      	<th>Repair & Maintainence</th>
		      	<th>Courier</th>
		      	<th>EOB</th>
		      	<th>Acceessories</th>
		      	<th>Bill Factory</th>
		      	<th>Freight</th>
		      	<th>Hardware</th>
		      	<th>Home</th>
		      	<th>Lunch</th>
		      	<th>Rent</th>
		      	<th>Lubricant Diesel</th>
		      	<th>Office Expenses</th>
		      	<th>Paint</th>
		      	<th>Fuel Tool Plaza</th>
		      	<th>Raw Material</th>
		      	<th>Taxes</th>
		      	<th>Installement</th>
		      	<th>Services</th>
		      	<th>Social Security</th>
				<th>Income Tax</th>
				<th>Print</th>  
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($expenses as $expense)

						<tr>
							
							<td>{{ $expense->date }}</td>
							<td>{{ $expense->advanceSalary }}</td>
							<td>{{ $expense->entertainment }}</td>
							<td>{{ $expense->fuelExpenses }}</td>
							<td>{{ $expense->repairAndMain }}</td>
							<td>{{ $expense->courier }}</td>
							<td>{{ $expense->eob }}</td>
							<td>{{ $expense->accessories }}</td>
							<td>{{ $expense->billFactory }}</td>
							<td>{{ $expense->freight }}</td>
							<td>{{ $expense->hardware }}</td>
							<td>{{ $expense->home }}</td>
							<td>{{ $expense->lunch }}</td>
							<td>{{ $expense->rent }}</td>
							<td>{{ $expense->lubricantDiesel }}</td>
							<td>{{ $expense->officeExpenses }}</td>
							<td>{{ $expense->paint }}</td>
							<td>{{ $expense->fuelToolPlaza }}</td>
							<td>{{ $expense->rawMaterial }}</td>
							<td>{{ $expense->taxes }}</td>
							<td>{{ $expense->installment }}</td>
							<td>{{ $expense->services }}</td>
							<td>{{ $expense->socialSecurity }}</td>
							<td>{{ $expense->incomeTax }}</td>
							
							<td><a href="{{ route('expenses.print', ['id' => $expense->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="{{ route('expenses.edit', ['id' => $expense->id ]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$expense->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$expense])
								<form method="POST" action="{{ route('expenses.destroy', ['id' => $expense->id ]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent
							
						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	@component('components.pagination', ['collection'=>$expenses])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

