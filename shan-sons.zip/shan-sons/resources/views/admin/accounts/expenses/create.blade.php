@extends('/admin.dashboard.header')

@section('title')
    Create Expenses
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Expenses</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Expenses > Create Record</p>
    </div>

    <div>
        
        <a href="{{ route('expenses.index') }}" class="btn btn-primary">Dsiaplay All Expenses</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('expenses.store') }}">

                    @csrf

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input readonly type="month" class="form-control" id="date" name="date" value="{{ $date }}">
                    </div>

                    <div class="form-group">
                        <label for="advanceSalary">Salary:</label>
                        <input readonly type="number" class="form-control" id="advanceSalary" name="advanceSalary" value="{{ $advanceSalary }}">
                    </div>

                    <div class="form-group">
                        <label for="entertainment">Entertainment:</label>
                        <input readonly type="number" class="form-control" id="entertainment" name="entertainment" value="{{ $entertainment }}">
                    </div>

                    <div class="form-group">
                        <label for="otherExpenses">Fixed Assets:</label>
                        <input readonly type="number" class="form-control" id="otherExpenses" name="otherExpenses" value="{{ $otherExpenses }}">
                    </div>

                    <div class="form-group">
                        <label for="fuelExpenses">Fuel Expenses:</label>
                        <input readonly type="number" class="form-control" id="fuelExpenses" name="fuelExpenses" value="{{ $fuelExpense }}">
                    </div>

                    <div class="form-group">
                        <label for="repairAndMain">Repair & Maintainence:</label>
                        <input readonly type="number" class="form-control" id="repairAndMain" name="repairAndMain" value="{{ $repair }}">
                    </div>


                    <div class="form-group">
                        <label for="courier">Courier:</label>
                        <input type="number" class="form-control" id="courier" name="courier" value="{{old('courier')}}">
                    </div>

                    <div class="form-group">
                        <label for="eob">E.O.B:</label>
                        <input type="number" class="form-control" id="eob" name="eob" value="{{old('eob')}}">
                    </div>

                    <div class="form-group">
                        <label for="accessories">Electrical Accessories:</label>
                        <input type="number" class="form-control" id="accessories" name="accessories" value="{{old('accessories')}}">
                    </div>

                    <div class="form-group">
                        <label for="billFactory">Electrical Bill Factory:</label>
                        <input type="number" class="form-control" id="billFactory" name="billFactory" value="{{old('billFactory')}}">
                    </div>

                    <div class="form-group">
                        <label for="freight">Freight Expense:</label>
                        <input type="number" class="form-control" id="freight" name="freight" value="{{old('freight')}}">
                    </div>

                    <div class="form-group">
                        <label for="hardware">Hardware Items:</label>
                        <input type="number" class="form-control" id="hardware" name="hardware" value="{{old('hardware')}}">
                    </div>

                    <div class="form-group">
                        <label for="home">Home Expenses:</label>
                        <input type="number" class="form-control" id="home" name="home" value="{{old('home')}}">
                    </div>

                    <div class="form-group">
                        <label for="lunch">Labour Lunch:</label>
                        <input type="number" class="form-control" id="lunch" name="lunch" value="{{old('lunch')}}">
                    </div>

                    <div class="form-group">
                        <label for="rent">Labour Rent:</label>
                        <input type="number" class="form-control" id="rent" name="rent" value="{{old('rent')}}">
                    </div>

                    <div class="form-group">
                        <label for="lubricantDiesel">Lubricants + Diesel etc:</label>
                        <input type="number" class="form-control" id="lubricantDiesel" name="lubricantDiesel" value="{{old('lubricantDiesel')}}">
                    </div>

                    <div class="form-group">
                        <label for="officeExpenses">Other Office Expenses:</label>
                        <input type="number" class="form-control" id="officeExpenses" name="officeExpenses" value="{{old('officeExpenses')}}">
                    </div>

                    <div class="form-group">
                        <label for="paint">Paint Works Expenses:</label>
                        <input type="number" class="form-control" id="paint" name="paint" value="{{old('paint')}}">
                    </div>

                    <div class="form-group">
                        <label for="fuelToolPlaza">Pick up fuel + Tool Plaza:</label>
                        <input type="number" class="form-control" id="fuelToolPlaza" name="fuelToolPlaza" value="{{old('fuelToolPlaza')}}">
                    </div>

                    <div class="form-group">
                        <label for="rawMaterial">Raw Material:</label>
                        <input type="number" class="form-control" id="rawMaterial" name="rawMaterial" value="{{old('rawMaterial')}}">
                    </div>


                    <div class="form-group">
                        <label for="taxes">Taxes:</label>
                        <input type="number" class="form-control" id="taxes" name="taxes" value="{{old('taxes')}}">
                    </div>

                    <div class="form-group">
                        <label for="installment">Vehicle Installment:</label>
                        <input type="number" class="form-control" id="installment" name="installment" value="{{old('installment')}}">
                    </div>

                    <div class="form-group">
                        <label for="services">Services:</label>
                        <input type="number" class="form-control" id="services" name="services" value="{{old('services')}}">
                    </div>

                    <div class="form-group">
                        <label for="socialSecurity">Social Security:</label>
                        <input type="number" class="form-control" id="socialSecurity" name="socialSecurity" value="{{old('socialSecurity')}}">
                    </div>

                    <div class="form-group">
                        <label for="incomeTax">4.5 % Deduction Income Tax :</label>
                        <input type="number" class="form-control" id="incomeTax" name="incomeTax" value="{{old('incomeTax')}}">
                    </div>



                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
