@extends('layouts.print')


@section('title')
    Expenses Report
@endsection

@section('reportTitle')
    Expenses Report
@endsection


@section('content')

    @component('components.expenses', ['expense' => $expense])
    @endcomponent

    <div class="hidden">
        <div id="printDiv">
    
          @include('shared.main-print')
          
    
          @component('components.expenses', ['expense' => $expense])
          @endcomponent

          @component('components.footer', ['flag'=>false])
          @endcomponent
    
        </div>
    </div>

    <div style="margin-top: 30px;" class="container">
        <div class="row">
          <div class=" col-md-4 ">
            <button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
          </div>
        </div>
    </div>



@endsection

@push('scripting')
    <script>
      
        document.getElementById("doPrint").addEventListener("click", function() {
            var printContents = document.getElementById('printDiv').innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        });

  </script>
@endpush

