@extends('/admin.dashboard.header')

@section('title')
    Create Page For Expenses
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Expenses</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Expenses</p>
    </div>

    <div>
        <a href="{{ route('expenses.index') }}" class="btn btn-primary">Dsiaplay All Expenses</a>
    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="GET" action="/create/expenses">

                    <div class="form-group">
                        <label for="date">Select Date:</label>
                        <input type="month" class="form-control" id="date" name="date" value="{{old('date')}}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

        @if(count($errors) > 0)
        $.notify('Something wrong \n Check the errors below the page ', 'error');
        @endif

        @if(Session::has('message'))
        $.notify('{{ Session::get('message') }}', '{{ Session::get('alert-class') }}');
        @endif

    </script>
    @include('shared.notification')

@endsection
