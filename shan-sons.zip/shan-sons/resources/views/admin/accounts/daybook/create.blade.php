@extends('/admin.dashboard.header')

@section('title')
    Create Daybook
@endsection

@section('styling')

    <link rel="stylesheet" type="text/css" href="{{ asset('admin/css/animation.css') }}">
    
    <style type="text/css">
        
        .details {
            font-size: 15px;
            font-weight: bolder;
        }

        .detailsP {
            font-size: 13px;
            font-weight: bolder;
        }

        .big-size {
            font-size: 18px;
            font-weight: bolder;
        }

        .highlight {
            /*box-shadow: 3px 3px 5px 6px #ccc;*/
            border: 1px solid red;
        }

        .top-margin {
            margin-top: 30px;
        }

        .more-input-margin {
            margin-top: 20px;
        }

    </style>

@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Daybook</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Daybook > Create Record</p>
    </div>

    <div>
        
        <a href="{{ route('daybook.index') }}" class="btn btn-primary">Dsiaplay All Daybooks</a>

    </div>

    <div ng-app="myApplication" ng-controller="myController" style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <div class="slide-animation">
                        
                    <div style="margin-top: 30px;"></div>


                    <form method="POST" action="{{ route('daybook.store') }}">

                        @csrf

                        <div class="form-group">
                            <label for="date">Date:</label>
                            <input type="date" id="date" name="date" value="{{ old('date') }}" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="voucherNo">Voucher Number:</label>
                            <input type="number" id="voucherNo" name="voucherNo" value="{{ old('voucherNo') }}" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="openingBalance">Opening Balance:</label>
                            <input type="number" id="openingBalance" name="openingBalance" value="{{ $openingBalance }}" class="form-control">
                        </div>

                        <hr>

                        

                        
                        <div class="top-margin"></div>

                        {{-- For Repair And Maintainence --}}
                        <div>
                            
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <p class="details">Repair And Maintainence</p>
                                </div>

                            </div>

                            <div class="row more-input-margin">
                                <div class="col-md-12">
                                    <span>More Inputs</span>
                                    <input style="margin-left: 4px;" type="checkbox" ng-model="repairMaintain">
                                </div>
                            </div>

                            <div ng-show="repairMaintain" class="appAnimation more-input-margin">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-3">
                                        <div class="form-group">
                                            <label>Add Inputs</label>
                                            <input type="number" ng-model="repair" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center">For Repair Maintainence</h4>

                                <div class="highlight row">
                                    <div ng-repeat="n in [] | range: repair " class="form-group repeat-animation">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Description: </label>
                                                <input type="text" name="rpDescription[]" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price: </label>
                                                <input type="number" name="rpPrice[]" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        {{-- Ends Repair And Maintainence --}}

                        <div class="top-margin"></div>

                        {{-- For Other Expenses --}}
                        <div>
                            
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <p class="details">Fixed Assets</p>
                                </div>

                            </div>

                            <div class="row more-input-margin">
                                <div class="col-md-12">
                                    <span>More Inputs</span>
                                    <input style="margin-left: 4px;" type="checkbox" ng-model="otherExpenses">
                                </div>
                            </div>

                            <div ng-show="otherExpenses" class="appAnimation more-input-margin">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-3">
                                        <div class="form-group">
                                            <label>Add Inputs</label>
                                            <input type="number" ng-model="other" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center">For Other Expenses</h4>

                                <div class="highlight row">
                                    <div ng-repeat="n in [] | range: other " class="form-group repeat-animation">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Description: </label>
                                                <input type="text" name="otherExpDescription[]" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price: </label>
                                                <input type="number" name="otherExpPrice[]" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        {{-- Ends Other Expenses --}}

                        <div class="top-margin"></div>

                        {{-- For Salary Wages --}}
                        <div>
                            
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <p class="details">Salary Wages</p>
                                </div>

                            </div>

                            <div class="row more-input-margin">
                                <div class="col-md-12">
                                    <span>More Inputs</span>
                                    <input style="margin-left: 4px;" type="checkbox" ng-model="salaryWages">
                                </div>
                            </div>

                            <div ng-show="salaryWages" class="appAnimation more-input-margin">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-3">
                                        <div class="form-group">
                                            <label>Add Inputs</label>
                                            <input type="number" ng-model="salary" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center">For Salary Wages</h4>

                                <div class="highlight row">
                                    <div ng-repeat="n in [] | range: salary " class="form-group repeat-animation">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Description: </label>
                                                <input type="text" name="wagesDescription[]" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price: </label>
                                                <input type="number" name="wagesPrice[]" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        {{-- Ends Salary Wages --}}

                        <div class="top-margin"></div>


                        {{-- For Fuel Expenses --}}
                        <div>
                            
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <p class="details">Fuel Expenses</p>
                                </div>

                            </div>

                            <div class="row more-input-margin">
                                <div class="col-md-12">
                                    <span>More Inputs</span>
                                    <input style="margin-left: 4px;" type="checkbox" ng-model="fuelExpenses">
                                </div>
                            </div>

                            <div ng-show="fuelExpenses" class="appAnimation more-input-margin">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-3">
                                        <div class="form-group">
                                            <label>Add Inputs</label>
                                            <input type="number" ng-model="fuel" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center">For Fuel Expenses</h4>

                                <div class="highlight row">
                                    <div ng-repeat="n in [] | range: fuel " class="form-group repeat-animation">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Description: </label>
                                                <input type="text" name="fuelDesctiption[]" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price: </label>
                                                <input type="number" name="fuelPrice[]" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        {{-- Ends Fuel Expenses --}}

                        <div class="top-margin"></div>


                        {{-- For Advance Expenses --}}
                        <div>
                            
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <p class="details">Advance Expenses</p>
                                </div>

                            </div>

                            <div class="row more-input-margin">
                                <div class="col-md-12">
                                    <span>More Inputs</span>
                                    <input style="margin-left: 4px;" type="checkbox" ng-model="advanceExpenses">
                                </div>
                            </div>

                            <div ng-show="advanceExpenses" class="appAnimation more-input-margin">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-3">
                                        <div class="form-group">
                                            <label>Add Inputs</label>
                                            <input type="number" ng-model="advance" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center">For Advance Expenses</h4>

                                <div class="highlight row">
                                    <div ng-repeat="n in [] | range: advance " class="form-group repeat-animation">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Description: </label>
                                                <input type="text" name="advanceDescription[]" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price: </label>
                                                <input type="number" name="advancePrice[]" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        {{-- Ends Advance Expenses --}}

                        <div class="top-margin"></div>


                        {{-- For Entertainment --}}
                        <div>
                            
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <p class="details">Entertainment</p>
                                </div>

                            </div>

                            <div class="row more-input-margin">
                                <div class="col-md-12">
                                    <span>More Inputs</span>
                                    <input style="margin-left: 4px;" type="checkbox" ng-model="entertainment">
                                </div>
                            </div>

                            <div ng-show="entertainment" class="appAnimation more-input-margin">
                                <div class="row">
                                    <div class="col-md-5 col-md-offset-3">
                                        <div class="form-group">
                                            <label>Add Inputs</label>
                                            <input type="number" ng-model="entertain" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center">For Entertainment</h4>

                                <div class="highlight row">
                                    <div ng-repeat="n in [] | range: entertain " class="form-group repeat-animation">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Description: </label>
                                                <input type="text" name="entertainDescription[]" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price: </label>
                                                <input type="number" name="entertainPrice[]" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        {{-- Ends Entertainment --}}
                        
                        <div class="top-margin"></div>
                        
                        {{-- For Form Submission --}}
                        <div class="form-group ">

                            <input type="submit" class="btn btn-success" value="Submit">

                        </div>
                        {{-- Ends Form Submission --}}

                    </form>


                </div>

            </div>

        </div>

    </div>


    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

    <script src="{{ asset('admin/js/angular.js') }}"></script>
    <script src="{{ asset('admin/js/angular-animate.js') }}"></script>


    <script>
        
        var app = angular.module('myApplication', ['ngAnimate']);

        app.filter('range', function() {
          return function(input, total) {
            total = parseInt(total);
            for (var i=0; i<total; i++)
              input.push(i);
            return input;
          };
        });

        app.controller('myController', function($scope) {

            $scope.user_first = 0;

        });

    </script>

@endsection

