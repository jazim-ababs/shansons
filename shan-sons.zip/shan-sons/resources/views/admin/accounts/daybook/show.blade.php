
@extends('/admin.dashboard.header')

@section('title')
	
	Daybook Detail List

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Daybook Details</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Daybook > Details</p>
	</div>

	<div>
		
		<a href="{{ route('daybook.index') }}" class="btn btn-primary">Back</a>

	</div>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($details) > 0)
		    
		      <tr>
		      	<th>Catagory Name</th>
		      	<th>Description</th>
		      	<th>Price</th>
		      	<th>Date & Time</th>
		      </tr>
			  
		      @foreach($details as $detail)

		        <tr>
		        	
		        	<td>{{ $detail->catagoryName }}</td>
		        	<td>{{ $detail->description }}</td>
		        	<td>{{ $detail->price }}</td>
					<td>{{ $detail->created_at }}</td>

		        </tr>

			  @endforeach
			  <tr>
				  <td>Price</td>
				  <td></td>
				  <td>{{ $daybook->totalExpenses }}</td>
			  </tr>
			  <tr>
				  <td>Remaining</td>
				  <td></td>
				  <td>{{ $daybook->remainingBalance }}</td>
			  </tr>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	<!-- END MAIN DIV -->

	


@endsection

