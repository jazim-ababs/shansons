@extends('/admin.dashboard.header')

@section('title')
    Edit Party Name
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Accounts</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Edit Party Name</p>
    </div>


    <div>

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('partyname.update', ['id'=>$partyName->id]) }}">

                    @method('PATCH')
                    @csrf

                    <div class="form-group">
                        <label for="srNumber">Serial Number:</label>
                        <input type="number" class="form-control" id="srNumber" name="srNumber" value="{{ $partyName->srNumber }}">
                    </div>

                    <div class="form-group">
                        <label for="ac">AC:</label>
                        <input type="number" class="form-control" id="ac" name="ac" value="{{ $partyName->ac }}">
                    </div>

                    <div class="form-group">
                        <label for="partyName">Party Name:</label>
                        <input type="text" class="form-control" id="partyName" name="partyName" value="{{ $partyName->partyName }}">
                    </div>

                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
