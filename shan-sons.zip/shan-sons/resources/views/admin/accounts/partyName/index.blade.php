
@extends('/admin.dashboard.header')

@section('title')
	
	All Party Names

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>PartyName</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('partyname.create') }}" class="btn btn-success">Add New PartyName</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($partyNames) > 0)
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>AC</th>
		      	<th>Party Name</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($partyNames as $partyName)

						<tr>
							
							<td>{{ $partyName->srNumber }}</td>
							<td>{{ $partyName->ac }}</td>
							<td>{{ $partyName->partyName }}</td>
							

							<td><a href="{{ route('partyname.edit', ['id' => $partyName->id ]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$partyName->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$partyName])
								<form method="POST" action="{{ route('partyname.destroy', ['id' => $partyName->id ]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	@component('components.pagination', ['collection'=>$partyNames])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

