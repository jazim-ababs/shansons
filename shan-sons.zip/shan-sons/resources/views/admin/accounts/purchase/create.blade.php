@extends('/admin.dashboard.header')

@section('title')
    Create Purchase
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Purchase</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Purchase</p>
    </div>

    <div>
        
        <a href="{{ route('purchase.index', ['id' => $partyName->id]) }}" class="btn btn-primary">Dsiaplay All Purchases</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('purchase.store', ['id' => $partyName->id]) }}">

                    @csrf

                    <input type="hidden" name="partyname_id" value="{{ $partyName->id }}">

                    <div class="form-group">
                        <label for="acNumber">Acc No:</label>
                        <input disabled type="number" class="form-control" id="acNumber" name="acNumber" value="{{ $partyName->ac }}">
                    </div>

                    <div class="form-group">
                        <label for="partyName">Party Name:</label>
                        <input disabled type="text" class="form-control" id="partyName" name="partyName" value="{{ $partyName->partyName }}">
                    </div>

                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" value="{{old('date')}}">
                    </div>

                    <div class="form-group">
                        <label for="girn">I/W # GIRN:</label>
                        <input type="number" class="form-control" id="girn" name="girn" value="{{old('girn')}}">
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                    <textarea class="form-control" rows="5" id="description" name="description">{{ old('description') }}</textarea>
                    </div> 

                    <div class="form-group">
                        <label for="qty">QTY:</label>
                        <input type="text" class="form-control" id="qty" name="qty" value="{{old('qty')}}">
                    </div>

                    <div class="form-group">
                        <label for="uom">UoM:</label>
                        <input type="text" class="form-control" id="uom" name="uom" value="{{old('uom')}}">
                    </div>

                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="number" class="form-control" id="price" name="price" value="{{old('price')}}">
                    </div>

                    <div class="form-group">
                        <label for="cr">Amount (CR) :</label>
                        <input type="number" class="form-control" id="cr" name="cr" value="{{old('cr')}}">
                    </div>

                    <div class="form-group">
                        <label for="balance">Balance:</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="{{ $balance }}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
