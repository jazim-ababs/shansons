
@extends('/admin.dashboard.header')

@section('title')
	
	All Party Names

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>PartyName</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts</p>
	</div>

	<div>
		
		<a href="{{ route('partyname.index') }}" class="btn btn-primary">All PartyNames</a>

	</div>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($partyNames) > 0)
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>AC</th>
		      	<th>Party Name</th>
		      </tr>


		      @foreach($partyNames as $partyName)

		        <tr>
		        	
		        	<td>{{ $partyName->srNumber }}</td>
		        	<td>{{ $partyName->ac }}</td>
		        	<td>
		        		<a data-toggle="modal" data-target="#{{$partyName->id}}" href="#">
		        			{{ $partyName->partyName }}
		        		</a>
		        	</td>

		        	<div class="modal fade" id="{{$partyName->id}}" role="dialog">
		        	  <div class="modal-dialog">
		        	  
		        	    <!-- Modal content-->
		        	    <div class="modal-content">
		        	      <div class="modal-header">
		        	        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        	        <h4 class="modal-title">Options for Purchasse</h4>
		        	      </div>
		        	      <div class="modal-body">
		        	        <p>Click on Button</p>

		        	        <a href="{{ route('purchase.create', ['id' => $partyName->id]) }}" class="btn btn-primary">Create Purchase</a>
		        	      	<a href="{{ route('purchase.index', ['id' => $partyName->id]) }}" class="btn btn-success">Display Purchase</a>
		        	      </div>
		        	      <div class="modal-footer">

		        	        <a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
		        	        
		        	      </div>
		        	    </div>
		        	    
		        	  </div>
		        	</div>

		        </tr>

		      @endforeach

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	
@endsection

