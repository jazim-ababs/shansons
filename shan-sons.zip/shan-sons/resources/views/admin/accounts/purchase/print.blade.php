@extends('layouts.print')


@section('title')
    All Purchase Report
@endsection

@section('reportTitle')
Purchase Report
@endsection


@section('content')

    <div class="container">
        @component('components.print-purchase', ['purchases' => $purchases])
        @endcomponent
    </div>

    <div class="hidden">
        <div id="printDiv">
    
          @include('shared.main-print')
          
    
          @component('components.print-purchase', ['purchases' => $purchases])
          @endcomponent

          @component('components.footer', ['flag'=>false])
          @endcomponent
    
        </div>
    </div>

    <div style="margin-top: 30px;" class="container">
        <div class="row">
          <div class=" col-md-4 ">
            <button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
          </div>
        </div>
    </div>



@endsection

@push('scripting')
    <script>
      
        document.getElementById("doPrint").addEventListener("click", function() {
            var printContents = document.getElementById('printDiv').innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        });

  </script>
@endpush

