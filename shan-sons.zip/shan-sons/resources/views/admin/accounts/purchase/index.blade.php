
@extends('/admin.dashboard.header')

@section('title')
	
	All Purchases

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Purchase</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Purchase</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('purchase.createpage') }}" class="btn btn-success">Add New Purchase</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($purchases) > 0)
		    
		      <tr>
		      	<th>Ac Number</th>
		      	<th>PartyName</th>
		      	<th>Date</th>
		      	<th>Girn</th>
		      	<th>Description</th>
		      	<th>Qt</th>
		      	<th>UOM</th>
		      	<th>Price</th>
		      	<th>Amount (DR)</th>
		      	<th>Amount (CR)</th>
		      	<th>Balance</th>
		      	<th>Print</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($purchases as $purchase)

						<tr>
							
							<td>{{ $partyName->ac }}</td>
							<td>{{ $partyName->partyName }}</td>
							<td>{{ $purchase->date }}</td>
							<td>{{ $purchase->girn }}</td>
							<td>{{ $purchase->description }}</td>
							<td>{{ $purchase->qty }}</td>
							<td>{{ $purchase->uom }}</td>
							<td>{{ $purchase->price }}</td>
							<td>{{ $purchase->dr }}</td>
							<td>{{ $purchase->cr }}</td>
							<td>{{ $purchase->balance }}</td>

							<td><a href="{{ route('purchase.show', ['partynameID'=>$partyName->id, 'purchase'=>$purchase->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$purchase->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$purchase])
								<form method="POST" action="{{ route('purchase.destroy', ['partyNameId' => $partyName->id, 'id' => $purchase->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	@component('components.pagination', ['collection'=>$purchases])
	@endcomponent
	<!-- END MAIN DIV -->

	<div style="margin-top:20px;">
		<a href="{{ route('purchase.print', ['partynameId'=>$partyName->id]) }}" class="btn btn-primary">Print All</a>
	</div>


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

