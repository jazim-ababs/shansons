@extends('/admin.dashboard.header')

@section('title')
    Create Sale Name
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Accounts</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Create New Sale Name</p>
    </div>

    <div>
        
        <a href="{{ route('salename.index') }}" class="btn btn-primary">Dsiaplay All Salenames</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('salename.store') }}">

                    @csrf


                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" value="{{old('name')}}">
                    </div>

                    <div class="form-group">
                        <label for="mobileNumber">Number:</label>
                        <input type="number" class="form-control" id="mobileNumber" name="mobileNumber" value="{{old('mobileNumber')}}">
                    </div>
                    


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
