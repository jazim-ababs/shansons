
@extends('/admin.dashboard.header')

@section('title')
	Opening Page for Payroll
@endsection

@section('styling')
	<style type="text/css">
		.someTopMargin {
			margin-top: 30px;
		}
	</style>
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Payroll</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Payroll</p>
	</div>

	<div>
		<a href="{{ route('employee.create') }}" class="btn btn-success">Add New Employee</a>
	</div>

	<div class="table-responsive someTopMargin">
		
		<table class="table table-hover">
			
			<tr>
				<th>ID</th>
				<th>Employee Name</th>
				<th>Create Payroll</th>
				<th>Display Payroll</th>
			</tr>	

			@if(count($employees) > 0)

				<tbody id="myTable">
					@foreach($employees as $employee)

						<tr>
							
							<td>{{ $employee->id }}</td>
							<td>{{ $employee->name }}</td>
							
							<td><a href="{{ route('payroll.create', ['id' => $employee->id]) }}" class="btn btn-primary">Create Payroll</a></td>
                            <td><a href="" class="btn btn-success">Display Payroll</a></td>
                            
						</tr>

					@endforeach
				</tbody>

			@endif


		</table>

	</div>

	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	<script src="{{ asset('admin/js/search.js') }}"></script>
	

@endsection

