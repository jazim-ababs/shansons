@extends('/admin.dashboard.header')

@section('title')
    Edit Payroll
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Payroll</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Payroll > Edit Payroll</p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('payroll.update', ['empId' => $payroll->employee->id, 'id' => $payroll->id]) }}">

                    @method('PATCH')
                    @csrf

                    <input type="hidden" name="employee_id" value="{{ $payroll->employee_id }}">

                    <div class="form-group">
                        <label for="srNumber">Serial Number:</label>
                        <input type="number" class="form-control" id="srNumber" name="srNumber" value="{{ $payroll->srNumber }}">
                    </div>

                    <div class="form-group">
                        <label for="name">Employee Name:</label>
                        <input readonly type="text" class="form-control" id="name" name="name" value="{{ $payroll->employee->name }}">
                    </div>

                    <div class="form-group">
                        <label>Date</label>
                        <input type="month" name="date" value="{{ $payroll->date }}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="basicSalary">Basic Salary:</label>
                        <input type="number" class="form-control" id="basicSalary" name="basicSalary" value="{{ $payroll->basicSalary }}">
                    </div>

                    <div class="form-group">
                        <label for="workingDays">Working Days:</label>
                        <input type="number" class="form-control" id="workingDays" name="workingDays" value="{{ $payroll->workingDays }}">
                    </div>

                    <div class="form-group">
                        <label for="totalHours">Total Hours:</label>
                        <input type="number" class="form-control" id="totalHours" name="totalHours" value="{{ $payroll->totalHours }}">
                    </div>

                    <div class="form-group">
                        <label for="lateHours">Late Hours:</label>
                        <input type="number" class="form-control" id="lateHours" name="lateHours" value="{{ $payroll->lateHours }}">
                    </div>

                    <div class="form-group">
                        <label for="coSec">Co Sec:</label>
                        <input type="number" class="form-control" id="coSec" name="coSec" value="{{ $payroll->coSec }}">
                    </div>

                    <div class="form-group">
                        <label for="pBalance">P.Balance:</label>
                        <input type="number" class="form-control" id="pBalance" name="pBalance" value="{{ $payroll->pBalance }}">
                    </div>

                    <div class="form-group">
                        <label for="daybook">Daybook:</label>
                        <input type="number" class="form-control" id="daybook" name="daybook" value="{{ $payroll->daybook }}">
                    </div>

                    <div class="form-group">
                        <label for="advanceDeduction">Advance Deduction:</label>
                        <input type="number" class="form-control" id="advanceDeduction" name="advanceDeduction" value="{{ $payroll->advanceDeduction }}">
                    </div>

                    <div class="form-group">
                        <label for="penalty">Penalty:</label>
                        <input type="number" class="form-control" id="penalty" name="penalty" value="{{ $payroll->penalty }}">
                    </div>

                    <div class="form-group">
                        <label for="signature">Signature:</label>
                        <input type="text" class="form-control" id="signature" name="signature" value="{{ $payroll->signature }}">
                    </div>

                    <div class="form-group">
                        <label for="bLoan">B/Loan:</label>
                        <input type="number" class="form-control" id="bLoan" name="bLoan" value="{{ $payroll->bLoan }}">
                    </div>

                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
