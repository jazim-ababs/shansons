
@extends('/admin.dashboard.header')

@section('title')
	
	All Payrolls

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Payroll</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Payroll > All Record</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('payroll.create', ['empId' => $emp_id]) }}" class="btn btn-success">Add New Payroll</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($payrolls) > 0)
		    
		      <tr>
		      	<th>Sr No</th>
		      	<th>Name</th>
		      	<th>Working Days</th>
		      	<th>Basic Salary</th>
		      	<th>Total Hours	</th>
		      	<th>Late Hours	</th>
		      	<th>Total Over Time	</th>
		      	<th>Over Time Commission</th>
		      	<th>Net Salary	</th>
		      	<th>Co. Section	</th>
		      	<th>P.Balance	</th>
		      	<th>Day Book</th>
		      	<th>Total</th>
		      	<th>Advance Dedication</th>
		      	<th>Penality</th>
		      	<th>Final Salary</th>
		      	<th>Pay Salary</th>
		      	<th>Signature</th>
		      	<th>B/Loan</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($payrolls as $payroll)

						<tr>
							
							<td>{{ $payroll->srNumber }}</td>
							<td>{{ $payroll->employee->name }}</td>
							<td>{{ $payroll->workingDays }}</td>
							<td>{{ $payroll->basicSalary }}</td>
							<td>{{ $payroll->totalHours }}</td>
							<td>{{ $payroll->lateHours }}</td>
							<td>{{ $payroll->overTime }}</td>
							<td>{{ $payroll->overTimeCommission }}</td>
							<td>{{ $payroll->netSalary }}</td>
							<td>{{ $payroll->coSec }}</td>
							<td>{{ $payroll->pBalance }}</td>
							<td>{{ $payroll->daybook }}</td>
							<td>{{ $payroll->total }}</td>
							<td>{{ $payroll->advanceDeduction }}</td>
							<td>{{ $payroll->penalty }}</td>
							<td>{{ $payroll->finalSalary }}</td>
							<td>{{ $payroll->paySalary }}</td>
							<td>{{ $payroll->signature }}</td>
							<td>{{ $payroll->bLoan }}</td>

							<td><a href="{{ route('payroll.show', ['empId' => $emp_id, 'id' => $payroll->id ]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="{{ route('payroll.edit', ['empId' => $emp_id, 'id' => $payroll->id]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$payroll->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$payroll])
								<form method="POST" action="{{ route('payroll.destroy', ['empId' => $emp_id, 'id' => $payroll->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>

	

	

@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

