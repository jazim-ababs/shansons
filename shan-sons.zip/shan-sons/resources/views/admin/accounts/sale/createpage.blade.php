
@extends('/admin.dashboard.header')

@section('title')
	
	Create Page

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Create Record</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Create Record</p>
	</div>

	<div>
        
        <a href="{{ route('salename.create') }}" class="btn btn-primary">Add New Salename</a>

    </div>

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($salenames) > 0)
		    
		      <tr>
		      	<th>Name</th>
		      	<th>Mobile Number</th>
		      </tr>


		      @foreach($salenames as $salename)

		        <tr>
		        	
		        	<td>
		        		<a data-toggle="modal" data-target="#{{$salename->id}}" href="#">
		        			{{ $salename->name }}
		        		</a>
		        	</td>
		        	<td>{{ $salename->mobileNumber }}</td>
		        	

		        	<div class="modal fade" id="{{$salename->id}}" role="dialog">
		        	  <div class="modal-dialog">
		        	  
		        	    <!-- Modal content-->
		        	    <div class="modal-content">
		        	      <div class="modal-header">
		        	        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        	        <h4 class="modal-title">Options for Sales</h4>
		        	      </div>
		        	      <div class="modal-body">
		        	        <p>Click on Button</p>

		        	        <a href="{{ route('sale.create', ['id' => $salename->id]) }}" class="btn btn-primary">Create Sale</a>
		        	      	<a href="{{ route('sale.index', ['id' => $salename->id]) }}" class="btn btn-success">Display Sale</a>
		        	      </div>
		        	      <div class="modal-footer">

		        	        <a type="button" class="btn btn-danger" data-dismiss="modal">Close</a>
		        	        
		        	      </div>
		        	    </div>
		        	    
		        	  </div>
		        	</div>

		        </tr>

		      @endforeach

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')

@endsection

