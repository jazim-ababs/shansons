<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sale Report</title>

    <link rel="stylesheet" href="{{ asset('admin/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/font-awesome/font-awesome.min.css') }}">

</head>
<body>

        @component('components.sale', ['sale'=>$sale])
        @endcomponent


        <div class="hidden">
            <div id="printDiv">
        
                @component('components.sale', ['sale'=>$sale])
                @endcomponent

                @component('components.footer', ['flag'=>false])
                @endcomponent
        
            </div>
        </div>

        <div style="margin-top: 30px;" class="container">
            <div class="row">
              <div class=" col-md-4 ">
                <button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
            </div>
          </div>
        </div>

    
    <script src="{{ asset('admin/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery.js') }}"></script>
    <script>
        document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });
    </script>
    
</body>
</html>