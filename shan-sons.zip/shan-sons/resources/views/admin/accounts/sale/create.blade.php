@extends('/admin.dashboard.header')

@section('title')
    Create Sale
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Sale</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Sale</p>
    </div>

    <div>
        
        <a href="{{ route('sale.index', ['id' => $salename->id]) }}" class="btn btn-primary">Dsiaplay All Sales</a>

    </div>

    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('sale.store', ['salenameID' => $salename->id ]) }}">

                    @csrf

                    <input type="hidden" name="salename_id" value="{{ $salename->id }}">

                    <div class="form-group">
                        <label for="invoiceNo">Invoice Number:</label>
                        <input type="number" class="form-control" id="invoiceNo" name="invoiceNo" value="{{old('invoiceNo')}}">
                    </div>

                    <div class="form-group">
                        <label for="invoiceDate">Invoice Date:</label>
                        <input type="date" class="form-control" id="invoiceDate" name="invoiceDate" value="{{ old('invoiceDate') }}">
                    </div>

                    <div class="form-group">
                        <label for="customerId">Customer ID:</label>
                        <input type="number" class="form-control" id="customerId" name="customerId" value="{{ old('customerId')}}">
                    </div>

                    <div class="form-group">
                        <label for="customerPro">Customer PO:</label>
                        <input type="text" class="form-control" id="customerPro" name="customerPro" value="{{old('customerPro')}}">
                    </div>

                    <div class="form-group">
                        <label for="paymentTerms">Payment Terms:</label>
                        <input type="text" class="form-control" id="paymentTerms" name="paymentTerms" value="{{old('paymentTerms')}}">
                    </div>

                    <div class="form-group">
                        <label for="salesRepId">Sales Rep ID:</label>
                        <input type="number" name="salesRepId" id="salesRepId" value="{{ old('salesRepId') }}" class="form-control">
                    </div> 

                    <div class="form-group">
                        <label for="shippingMethod">Shipping Method:</label>
                        <input type="text" class="form-control" id="shippingMethod" name="shippingMethod" value="{{old('shippingMethod')}}">
                    </div>

                    <div class="form-group">
                        <label for="shipDate">Ship Date:</label>
                        <input type="date" class="form-control" id="shipDate" name="shipDate" value="{{old('shipDate')}}">
                    </div>

                    <div class="form-group">
                        <label for="dueDate">Due Date:</label>
                        <input type="date" class="form-control" id="dueDate" name="dueDate" value="{{old('dueDate')}}">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity :</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="{{old('quantity')}}">
                    </div>

                    <div class="form-group">
                        <label for="item">Unit of Measure :</label>
                        <input type="text" class="form-control" id="item" name="item" value="{{old('item')}}">
                    </div>

                    <div class="form-group">
                        <label for="description">Descripton:</label>
                    <textarea class="form-control" rows="5" id="description" name="description">{{ old('description') }}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="unitPrice">Unit Price:</label>
                        <input type="number" class="form-control" id="unitPrice" name="unitPrice" value="{{old('unitPrice')}}">
                    </div>

                    <div class="form-group">
                        <label for="amount">Amount:</label>
                        <input type="number" class="form-control" id="amount" name="amount" value="{{old('amount')}}">
                    </div>

                    <div class="form-group">
                        <label for="subTotal">Sub Total:</label>
                        <input type="number" class="form-control" id="subTotal" name="subTotal" value="{{old('subTotal')}}">
                    </div>

                    <div class="form-group">
                        <label for="balance">Sales Tax:</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="17">
                    </div>

                    <div class="form-group">
                        <label for="credit">Delivery Challan:</label>
                        <input type="number" class="form-control" id="credit" name="credit" value="{{old('credit')}}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
