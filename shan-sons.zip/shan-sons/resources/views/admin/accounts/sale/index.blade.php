
@extends('/admin.dashboard.header')

@section('title')
	
	All Sales

@endsection

@section('styling')
	
	<style type="text/css">
		
		.someTopMargin {
			margin-top: 30px;
		}

	</style>
	
@endsection	

@section('dashboard-content')

	<!-- ALL CONTENT HERE IN THIS DIV -->
	
	<h1 class="page-header">
	    Dashboard
	    <small>Sale</small>
	</h1>

	<div class="alert alert-info">
		<p>Dashboard > Accounts > Sale</p>
	</div>


	@component('components.search-button')
		<a href="{{ route('sale.createpage') }}" class="btn btn-success">Add New Sale</a>
	@endcomponent

	<div class="table-responsive someTopMargin">

		<div>
		              
		  <table style="margin-top: 20px;" class="table">

		    @if(count($sales) > 0)
		    
		      <tr>
		      	<th>Invoice Number</th>
		      	<th>Invoice Date</th>
		      	<th>Customer Id</th>
		      	<th>Customer Pro</th>
		      	<th>Payment Terms</th>
		      	<th>Sales Rep Id</th>
		      	<th>Shipping Method</th>
		      	<th>Ship Date</th>
		      	<th>Due Date</th>
		      	<th>Quantity</th>
		      	<th>Unit of Measure</th>
		      	<th>Description</th>
		      	<th>Unit Price</th>
		      	<th>Amount</th>
		      	<th>Sub Total</th>
		      	<th>Sales Tax</th>
		      	<th>Total Invoice Amount</th>
		      	<th>Payment</th>
		      	<th>Total</th>
		      	<th>Check</th>
		      	<th>Print</th>
		      	<th>Edit</th>
		      	<th>Delete</th>
		      </tr>

			  	<tbody id="myTable">
					@foreach($sales as $sale)

						<tr>
							
							<td>{{ $sale->invoiceNo }}</td>
							<td>{{ $sale->invoiceDate }}</td>
							<td>{{ $sale->customerId }}</td>
							<td>{{ $sale->customerPro }}</td>
							<td>{{ $sale->paymentTerms }}</td>
							<td>{{ $sale->salesRepId }}</td>
							<td>{{ $sale->shippingMethod }}</td>
							<td>{{ $sale->shipDate }}</td>
							<td>{{ $sale->dueDate }}</td>
							<td>{{ $sale->quantity }}</td>
							<td>{{ $sale->item }}</td>
							<td>{{ $sale->description }}</td>
							<td>{{ $sale->unitPrice }}</td>
							<td>{{ $sale->amount }}</td>
							<td>{{ $sale->subTotal }}</td>
							<td>{{ $sale->balance }}</td>
							<td>{{ $sale->totalInvoiceAmount }}</td>
							<td>{{ $sale->payment }}</td>
							<td>{{ $sale->total }}</td>
							<td>{{ $sale->credit }}</td>

							<td><a href="{{ route('sale.show', ['salenameID' => $sale->salename->id, 'id' => $sale->id]) }}" class="btn btn-primary btn-sm"><i class="fa fa-print"><span style="margin-left: 5px;">Print</span></i></a></td>

							<td><a href="{{ route('sale.edit', ['salenameId' => $sale->salename->id, 'id' => $sale->id ]) }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"><span style="margin-left: 5px;">Update</span></i></a></td>

							<td><a href="#" data-toggle="modal" data-target="#{{$sale->id}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"><span style="margin-left: 5px;">Delete</span></i></a></td>

							@component('components.modal', ['obj'=>$sale])
								<form method="POST" action="{{ route('sale.destroy', ['salenameId' => $sale->salename->id, 'id' => $sale->id]) }}">

									@method('delete')
									@csrf

									<input type="submit" class="btn btn-success" value="Yes">
								</form>
							@endcomponent

						</tr>

					@endforeach
			  	</tbody>

		      @else
		        <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

		    @endif  

		  </table>

		</div>
		
	</div>


	@component('components.pagination', ['collection'=>$sales])
	@endcomponent
	<!-- END MAIN DIV -->

	


@endsection


@section('scripting')
	
	@include('shared.notification')
	@include('shared.get-search')

@endsection

