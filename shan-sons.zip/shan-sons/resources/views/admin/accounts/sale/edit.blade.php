@extends('/admin.dashboard.header')

@section('title')
    Edit Sale
@endsection

@section('dashboard-content')

    <h1 class="page-header">
        Dashboard
        <small>Sale</small>
    </h1>

    <div class="alert alert-info">
        <p>Dashboard > Accounts > Sale</p>
    </div>


    <div style="margin-top: 20px;">

        <div class="row">
            
            <div class="col-md-8 col-md-offset-2">
                
                <form id="myForm" method="POST" action="{{ route('sale.update', ['salenameID' => $sale->salename->id, 'id' => $sale->id ]) }}">

                    @method('PATCH')
                    @csrf

                    <input type="hidden" name="salename_id" value="{{ $sale->salename->id }}">

                    <div class="form-group">
                        <label for="invoiceNo">Invoice Number:</label>
                        <input type="number" class="form-control" id="invoiceNo" name="invoiceNo" value="{{ $sale->invoiceNo }}">
                    </div>

                    <div class="form-group">
                        <label for="invoiceDate">Invoice Date:</label>
                        <input type="date" class="form-control" id="invoiceDate" name="invoiceDate" value="{{ $sale->invoiceDate }}">
                    </div>

                    <div class="form-group">
                        <label for="customerId">Customer ID:</label>
                        <input type="number" class="form-control" id="customerId" name="customerId" value="{{ $sale->customerId}}">
                    </div>

                    <div class="form-group">
                        <label for="customerPro">Customer PO:</label>
                        <input type="text" class="form-control" id="customerPro" name="customerPro" value="{{ $sale->customerPro }}">
                    </div>

                    <div class="form-group">
                        <label for="paymentTerms">Payment Terms:</label>
                        <input type="text" class="form-control" id="paymentTerms" name="paymentTerms" value="{{ $sale->paymentTerms }}">
                    </div>

                    <div class="form-group">
                        <label for="salesRepId">Sales Rep ID:</label>
                        <input type="number" name="salesRepId" id="salesRepId" value="{{ $sale->salesRepId }}" class="form-control">
                    </div> 

                    <div class="form-group">
                        <label for="shippingMethod">Shipping Method:</label>
                        <input type="text" class="form-control" id="shippingMethod" name="shippingMethod" value="{{ $sale->shippingMethod }}">
                    </div>

                    <div class="form-group">
                        <label for="shipDate">Ship Date:</label>
                        <input type="date" class="form-control" id="shipDate" name="shipDate" value="{{ $sale->shipDate }}">
                    </div>

                    <div class="form-group">
                        <label for="dueDate">Due Date:</label>
                        <input type="date" class="form-control" id="dueDate" name="dueDate" value="{{ $sale->dueDate }}">
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity :</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="{{ $sale->quantity }}">
                    </div>

                    <div class="form-group">
                        <label for="item">Unit of Measure :</label>
                        <input type="text" class="form-control" id="item" name="item" value="{{ $sale->item }}">
                    </div>

                    <div class="form-group">
                        <label for="description">Descripton:</label>
                        <textarea class="form-control" rows="5" id="description" name="description"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="unitPrice">Unit Price:</label>
                        <input type="number" class="form-control" id="unitPrice" name="unitPrice" value="{{ $sale->unitPrice }}">
                    </div>

                    <div class="form-group">
                        <label for="balance">Sales Tax:</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="{{ $sale->balance }}">
                    </div>

                    <div class="form-group">
                        <label for="totalInvoiceAmount">Total Invoice Amount:</label>
                        <input type="number" class="form-control" id="totalInvoiceAmount" name="totalInvoiceAmount" value="{{ $sale->totalInvoiceAmount }}">
                    </div>

                    <div class="form-group">
                        <label for="credit">Delivery Challan:</label>
                        <input type="number" class="form-control" id="credit" name="credit" value="{{ $sale->credit }}">
                    </div>


                    <div class="form-group ">

                        <input type="submit" class="btn btn-success" value="Submit">
                        <input onclick="myFunction()" style="margin-left: 20px;" type="button" class="btn btn-danger" value="Clear">

                    </div>

                </form>

            </div>

        </div>

    </div>

    @include('/error')

@endsection


@section('scripting')


    <script type="text/javascript">

        function myFunction() {
            document.getElementById("myForm").reset();
        }

    </script>
    @include('shared.notification')

@endsection
