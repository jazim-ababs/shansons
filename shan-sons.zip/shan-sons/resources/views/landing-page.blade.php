<!DOCTYPE HTML>

<html>
	<head>
		<title>Dimension by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="{{ asset('custom/assets/css/main.css') }}" />
    <noscript><link rel="stylesheet" href="{{ asset('custom/assets/css/noscript.css') }}" /></noscript>
    
    <style>
      .add-img {
        background-image: url({{ asset('custom/images/main.jpg') }})
      }
    </style>
	</head>
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper" class="add-img">

				<!-- Header -->
					<header id="header" class="add">
						<div class="logo">
							<span class="icon fa-gem"></span>
						</div>
						<div class="content">
							<div class="inner">
								<h1>Shan Son's Engineering Works</h1>
								<p>Auto Parts Manufacturer</p>
							</div>
						</div>
						<nav>
							<ul>
                @auth
                    <li><a href="{{ url('/home') }}">Home</a></li>
                @else
                    <li><a href="{{ route('login') }}">Login</a></li>

                    @if (Route::has('register'))
                        <li><a href="{{ route('register') }}">Register</a></li>
                    @endif
                @endauth
							</ul>
						</nav>
					</header>
			
				<!-- Footer -->
					<footer id="footer">
						<p class="copyright">&copy; 2019 <a href="https://www.softwarehubpro.com" >Software Hub Pro</a>. All Rights Reserved.</p>
					</footer>

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="{{ asset('custom/assets/js/jquery.min.js') }}"></script>
			<script src="{{ asset('custom/assets/js/browser.min.js') }}"></script>
			<script src="{{ asset('custom/assets/js/breakpoints.min.js') }}"></script>
			<script src="{{ asset('custom/assets/js/util.js') }}"></script>
			<script src="{{ asset('custom/assets/js/main.js') }}"></script>
			<script src="{{ asset('admin/js/loader.js') }}"></script>

	</body>
</html>
