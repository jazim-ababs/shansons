<!-- Bootstrap Core CSS -->
<link href="{{ asset('admin/css/bootstrap.min.css') }}" rel="stylesheet">

<!-- Custom CSS -->
<link href="{{ asset('admin/css/sb-admin.css') }}" rel="stylesheet">

<!-- Custom Fonts -->
<link href="{{ asset('admin/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">


<link rel="stylesheet" href="{{ asset('admin/css/loader.css') }}">