<!-- jQuery -->
<script src="{{ asset('admin/js/jquery.js') }}"></script>

<!-- Bootstrap Core JavaScript -->
<script src="{{ asset('admin/js/bootstrap.min.js') }}"></script>

<script src="{{ asset('admin/js/notify.js') }}"></script>


<script src="{{ asset('admin/js/loader.js') }}"></script>