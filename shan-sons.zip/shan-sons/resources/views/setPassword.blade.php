@extends('layouts.app')

@section('content')
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        Update Password
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('password.update') }}">
                            @csrf

                            <div class="form-group">
                                <label for="token">Confirmation Token:</label>
                                <input readonly type="text" name="token" class="form-control" id="token" value="{{ $confirmation_token }}">
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" name="password" class="form-control" id="password">
                            </div>
                            <div class="form-group">
                                <label for="c_password">Confirm Password:</label>
                                <input type="password" name="password_confirmation" class="form-control" id="c_password">
                            </div>

                            <input type="submit" class="btn btn-primary" value="Update Password">

                        </form>

                        <div style="margin-top: 10px"></div>
                        @include('error')

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripting')

    @if(Session::has('message'))
        $.notify('{{ Session::get('message') }}', '{{ Session::get('alert-class') }}');
    @endif

@endsection
