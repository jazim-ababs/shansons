<div>
    <p class="alert alert-info text-center">Shan Sons Official Web Software</p>

    <div style="margin-top: 20px;">

        <h4>Hello {{ $name }}!</h4>
        <p>You are receiving this email because we received a password reset request
        for your account.</p>

        <div class="text-center">
            <a href="{{ route('password.set', ['token' => $confirm_token]) }}" class="btn btn-primary">Reset Password</a>
        </div>

        <p>If you did not request a password reset, no further action is required.</p>
        <p>Regards</p>
        <p>Shan Sons</p>

    </div>

</div>