<div class="table-responsive">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            <tr>
                <th>Sr No</th>
                <th>Date</th>
                <th>UOM</th>
                <th>Issue</th>
                <th>Description</th>
                <th>Balance</th>
            </tr>

            <tr>
                <td>{{ $raw->srNumber }}</td>
                <td>{{ $raw->date }}</td>
                <td>{{ $raw->uom }}</td>
                <td>{{ $raw->issue }}</td>
                <td>{{ $raw->description }}</td>
                <td>{{ $raw->balance }}</td>
            </tr>

        </table>

    </div>

</div>