
@extends('layouts.print')


@section('title')
    {{ $title }}
@endsection

@section('reportTitle')
    {{ $title }}
@endsection

@push('styling')
    <style>
        .highlight {
            font-size: 17px;
            font-weight: bold;
        }
        .topMargin {
            margin-top: 10px;
        }
    </style>
@endpush


@section('content')

<div class="topMargin"></div>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <p><span class="highlight">Date</span>: {{ $store->date }}</p>
        </div>
        <div class="col-md-6">
            <p><span class="highlight">Party Name</span>: {{ $store->partyName }}</p>
        </div>
        <div class="col-md-6">
            <p><span class="highlight">Vehicle Number</span>:  {{ $store->vehicleNumber }}</p>
        </div>
        <div class="col-md-6">
            <p><span class="highlight">By Hand</span> : {{ $store->byHand }}</p>
        </div>
    </div>
</div>




<!-- Page content -->
<div class="container">
  <div class="row">
    <div class=" col-md-12 ">
      <div class="main">
        
          <div class="table-responsive">
            
            <div>
                          
              <table style="margin-top: 20px;" class="table">

                <tr>
                    <th>Sr Number</th>
                    <th>Description</th>
                    <th>Unit</th>
                    <th>Quantity</th>
                    <th>Box</th>
                    <th>Price</th>
                </tr>

                <tr>
                    <td>{{ $store->srNumber }}</td>
                    <td>{{ $store->description }}</td>
                    <td>{{ $store->unit }}</td>
                    <td>{{ $store->quantity }}</td>
                    <td>{{ $store->box }}</td>
                    <td>{{ $store->price }}</td>
                </tr>

              </table>

            </div>


          </div>

          


        
         </div>
     </div>
 </div>
</div>

         
  <div class="hidden">
    <div id="printDiv">

      @include('shared.main-print')
      
      <div class="topMargin"></div>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <p><span class="highlight">Date</span>: {{ $store->date }}</p>
        </div>
        <div class="col-md-6">
            <p><span class="highlight">Party Name</span>: {{ $store->partyName }}</p>
        </div>
        <div class="col-md-6">
            <p><span class="highlight">Vehicle Number</span>:  {{ $store->vehicleNumber }}</p>
        </div>
        <div class="col-md-6">
            <p><span class="highlight">By Hand</span> : {{ $store->byHand }}</p>
        </div>
    </div>
</div>

      <div class="table-responsive">
            
        <div>
                      
          <table style="margin-top: 20px;" class="table">

            <tr>
                <th>Sr Number</th>
                <th>Description</th>
                <th>Unit</th>
                <th>Quantity</th>
                <th>Box</th>
                <th>Price</th>
            </tr>

            <tr>
                <td>{{ $store->srNumber }}</td>
                <td>{{ $store->description }}</td>
                <td>{{ $store->unit }}</td>
                <td>{{ $store->quantity }}</td>
                <td>{{ $store->box }}</td>
                <td>{{ $store->price }}</td>
            </tr>

          </table>

          @component('components.footer', ['flag'=>true])
          @endcomponent

        </div>


      </div>

    </div>
  </div>

         



<div style="margin-top: 30px;" class="container">
  <div class="row">
    <div class=" col-md-4 ">
<button id="doPrint" type="button" class="btn btn-primary">Print Report</button>
</div>
</div>
</div>

  @push('scripting')
    
    <script>
      
      document.getElementById("doPrint").addEventListener("click", function() {
          var printContents = document.getElementById('printDiv').innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      });

    </script>

  @endpush
  
  
@endsection