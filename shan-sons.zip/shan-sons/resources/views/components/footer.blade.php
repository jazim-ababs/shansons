<div class="text-center" @if($flag) style="color: white; background-color: black" @endif>  
    &copy; 2019 <a href="https://www.softwarehubpro.com" @if($flag) style="color: white" @endif>Software Hub Pro</a>. All Rights Reserved.
</div>