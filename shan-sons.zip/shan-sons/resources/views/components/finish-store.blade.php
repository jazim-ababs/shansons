<div>
    <p>Date: {{ $date }}</p>
</div>

<div style="margin-top: 10px;"></div>

<div class="table-responsive">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            @if(count($finishStores) > 0)
    
                <tr>
                    <th>Company Name</th>
                    <th>Description</th>
                    <th>Opening Balance</th>
                    <th>Packing</th>
                    <th>Ending Balance</th>
                    <th>QTV</th>
                    <th>Balance</th>
                </tr>


                @foreach($finishStores as $finishStore)

                <tr>
                    
                    <td>{{ $companyName }}</td>
                    <td>{{ $finishStore->description }}</td>
                    <td>{{ $finishStore->openingBalance }}</td>
                    <td>{{ $finishStore->packing }}</td>
                    <td>{{ $finishStore->endingBalance }}</td>
                    <td>{{ $finishStore->qtv }}</td>
                    <td>{{ $finishStore->balance }}</td>

                </tr>

                @endforeach

            @endif   

        </table>

    </div>

</div>