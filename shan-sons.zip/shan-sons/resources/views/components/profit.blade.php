<div class="table-responsive">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            <tr>
                <td>Date</td>
                <td>{{ $date }}</td>
            </tr>

            @if(count($sales) > 0)
                @foreach($sales as $sale)

                    <tr>
                        <td>{{ $sale['name'] }}</td>
                        <td>{{ $sale['price'] }}</td>
                    </tr>

                @endforeach
            @endif

            <tr>
                <td>Total Revenue</td>
                <td>{{ $totalRevenue }}</td>
            </tr>

            <tr>
                <td>Total Expenses</td>
                <td>{{ $totalExpenses }}</td>
            </tr>

            <tr>
                <td>Profit</td>
                <td>{{ $profit }}</td>
            </tr>

        </table>

    </div>

</div>