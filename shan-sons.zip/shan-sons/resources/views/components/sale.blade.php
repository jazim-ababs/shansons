<div class="container-fluid">
    <div class="row">
        <div class="col-md-10">
              <h2>SHANSONS ENGINEERING WORKS</h2>
              <span>22KM FEROUZPUR ROAD</span>
               <br>
              <Span>4KM OFF ROHI NALA KACHHA</span>
                <br>
                <span>LAHORE 54,000</span>
                <br>
                <span>PAKISTAN</span>
                <br>
                <br>
                <span>Voice</span><br>
                <span>FAX</span>
        </div>
        <div class="col-md-2" >
            <h2 style="font-weight: bolder;">INVOICE</h2>
            <span>Invoice Number: {{ $sale->invoiceNo }}</span>
            <br>
            <span>Invoice Date: {{ $sale->invoiceDate }}</span>
            <br>
        </div>
    </div>
</div>

<div class="container-fluid">
   <div class="row">
        <div class="col-md-6" style="padding-top: 30px;">
     <table class="table table-bordered table-striped">
         <tr>
             <th>Bill To:</th>    
</tr>


<tr>
    <td>
        {{ $sale->salename->name }}
        <br>
        {{ $sale->salename->mobileNumber }}
    </td>
</tr>
</table> 
</div>

               <div class="col-md-6" style="padding-top: 30px;">
           <table class="table table-bordered table-striped" >
  
         <tr>
             <th>Ship To:</th>    
           </tr>


     <tr>
            <td>
                  {{ $sale->salename->name }}
                <br>
                {{ $sale->salename->mobileNumber }}
            </td>
       </tr>

      </table>
              </div>
        </div>
</div>

<div class="container-fluid">
     <div class="row">
          <div class="col-md-12">
              <table class="table table-bordered table-striped" >
       
      <tr>
                <th>Customer ID</th>
                 <th>Customer PO</th>
                   <th colspan="2">Payment Terms</th>
           </tr>

           <tr>
               <td>{{ $sale->customerId }}</td>
      <td>{{ $sale->customerPro }}</td>
      <td colspan="2">{{ $sale->paymentTerms }}</td>
           </tr>


           <tr>
               <th>Sales Rep ID</th>
               <th>Shipping Method</th>
               <th>Ship Date</th>
               <th>Due Date</th>
           </tr>


           <tr> 
               <td>{{ $sale->salesRepId }}</td>
               <td>{{ $sale->shippingMethod }}</td>
      <td>{{ $sale->shipDate }}</td>
      <td>{{ $sale->dueDate }}</td>
           </tr>

       </table>
   </div>
   </div>
</div>


<div class="container-fluid">
     <div class="row">
          <div class="col-md-12">
                <table class="table table-bordered table-striped" style="padding-top: 20px;" >
           
    <tr>
               <th>Quantity</th>
               <th>Unit of Measure</th>
      <th>Description</th>
               <th>Unit Price</th>
               <th>Amount</th>
           </tr>

           <tr> 
               <td>{{ $sale->quantity }}</td>
               <td>{{ $sale->item }}</td>
      <td>{{ $sale->description }}</td>
      <td>{{ $sale->unitPrice }}</td>
      <td>{{ $sale->amount }}</td>
           </tr>
           
       </table>
       </div>


       <div class="col-md-6">
           <br>
           <br>
           <h5>Check/Credit Memo No: {{ $sale->credit }}</h5>	
       </div>


       <div class="col-md-6">
              <table class="table table-bordered">
       
      <tr>
              <td>Subtotal</td>
        <td>{{ $sale->subTotal }}</td>
   </tr>
           
    <tr>
               <td>Sales Tax</td>
               <td>{{ $sale->balance }}</td>
           </tr>
           
    <tr>
               <td>Total Invoice Amout</td>
               <td>{{ $sale->totalInvoiceAmount }}</td>
           </tr>
           
    <tr>
               <td>Payment/Credit Applied</td>
               <td>{{ $sale->payment }}</td>
           </tr>
           

    <tr>
        <td  class ="color">Total</td>
               <td class="color">{{ $sale->total }}</td>
           </tr>


           </table>
       </div>
   </div>
</div>


<div class="container-fluid">
   <div class="row">
       
   </div>
</div>