<div class="">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            <tr>
		      	<th>Ac Number</th>
		      	<th>PartyName</th>
		      	<th>Date</th>
		      	<th>Girn</th>
		      	<th>Description</th>
		      	<th>Qt</th>
		      	<th>UOM</th>
		      	<th>Price</th>
		      	<th>Amount (DR)</th>
		      	<th>Amount (CR)</th>
		      	<th>Balance</th>
            </tr>

            <tr>
                <td>{{ $purchase->partyname->ac }}</td>
                <td>{{ $purchase->partyname->partyName }}</td>
                <td>{{ $purchase->date }}</td>
                <td>{{ $purchase->girn }}</td>
                <td>{{ $purchase->description }}</td>
                <td>{{ $purchase->qty }}</td>
                <td>{{ $purchase->uom }}</td>
                <td>{{ $purchase->price }}</td>
                <td>{{ $purchase->dr }}</td>
                <td>{{ $purchase->cr }}</td>
                <td>{{ $purchase->balance }}</td>
            </tr>


        </table>

    </div>
    
</div>