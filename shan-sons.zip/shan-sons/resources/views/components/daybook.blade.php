<div class="table-responsive">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            @if(count($details) > 0)
    
                <tr>
                    <th>Catagory Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Date & Time</th>
                </tr>

                @foreach($details as $detail)

                <tr>
                    
                    <td>{{ $detail->catagoryName }}</td>
                    <td>{{ $detail->description }}</td>
                    <td>{{ $detail->price }}</td>
                    <td>{{ $detail->created_at }}</td>

                </tr>

                @endforeach
                <tr>
                    <td>Total</td>
                    <td></td>
                    <td>{{ $daybook->totalExpenses }}</td>
                </tr>
                <tr>
                    <td>Remaining</td>
                    <td></td>
                    <td>{{ $daybook->remainingBalance }}</td>
                </tr>

                @else
                <p style="margin-top: 10px;" class="alert alert-danger">Sorry. There is no record.</p>

            @endif   

        </table>

    </div>

</div>