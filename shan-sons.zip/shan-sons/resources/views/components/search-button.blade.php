<div class="row">
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-2">
                {{ $slot }}
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-8 col-md-offset-3">
                @component('components.search')
                @endcomponent
            </div>
        </div>
    </div>
</div>