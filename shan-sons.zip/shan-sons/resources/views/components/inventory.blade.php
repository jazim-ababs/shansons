<div class="table-responsive">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            <tr>
                <th>Sr No</th>
                <th>Date</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Issue</th>
                <th>Return</th>
                <th>Balance</th>
            </tr>

            @foreach($inventories as $inventory)
                <tr>
                    <td>{{ $inventory->srNumber }}</td>
                    <td>{{ $inventory->date }}</td>
                    <td>{{ $inventory->description }}</td>
                    <td>{{ $inventory->quantity }}</td>
                    <td>{{ $inventory->issue }}</td>
                    <td>{{ $inventory->return }}</td>
                    <td>{{ $inventory->balance }}</td>
                </tr>
            @endforeach


        </table>

    </div>
    
</div>