<table class="table table-bordered table-responsive table-striped"><br>
          
    <tr>
          <td><strong>Advance Salary</strong></td>
          <td><strong>Courier</strong></td>
          <td><strong>E.O.B<strong></td>
          <td><strong>Electrical Accessories<strong></td>
          <td><strong>Electrical Bill Factory<strong></td>
          <td><strong>Entertainments</strong></td>
          <td><strong>Freight Expense</strong></td>
          <td><strong>Fuel Expense</strong></td>
          <td><strong>Hardware Items</strong></td>
          <td><strong>Home Expenses</strong></td>
          <td><strong>Labour Lunch</strong></td>
          <td><strong>Labour Rent</strong></td>
          <td><strong>Lubricants + Diesel</strong></td>
                              
      </tr>

        
         <tr>
                  
            <td>{{ $expense->advanceSalary }}</td>
            <td>{{ $expense->courier }}</td>
            <td>{{ $expense->eob }}</td>
            <td>{{ $expense->accessories }}</td>
            <td>{{ $expense->billFactory }}</td>
            <td>{{ $expense->entertainment }}</td>
            <td>{{ $expense->freight }}</td>
            <td>{{ $expense->fuelExpenses }}</td>
            <td>{{ $expense->hardware }}</td>
            <td>{{ $expense->home }}</td>
            <td>{{ $expense->lunch }}</td>
            <td>{{ $expense->rent }}</td>
            <td>{{ $expense->lubricantDiesel }}</td>
            
        </tr>

    <tr>
     
           <td><strong>Other Office Expenses</strong></td>
           <td><strong>Paint Works Expenses</strong></td>
           <td><strong>Pick Up Fuel + Tool Plaza</strong></td>
           <td><strong>Raw Material</strong></td>
           <td><strong>Repair & Maintance</strong></td>
           <td><strong>Salaries</strong></td>
           <td><strong>Taxes</strong></td>
           <td><strong>Vehical Installment</strong></td>
           <td><strong>Services</strong></td>
          <td><strong>Social Security</strong></td>
          <td><strong>4.5 % Deduction Income Tax</strong></td>        
    </tr>                                                     

           <tr>
            <td>{{ $expense->officeExpenses }}</td>             
            <td>{{ $expense->paint }}</td>
            <td>{{ $expense->fuelToolPlaza }}</td>
            <td>{{ $expense->rawMaterial }}</td>
            <td>{{ $expense->repairAndMain }}</td>
            <td>{{ $expense->advanceSalary }}</td>
            <td>{{ $expense->taxes }}</td>
            <td>{{ $expense->installment }}</td> 
            <td>{{ $expense->services }}</td>
            <td>{{ $expense->socialSecurity }}</td>
            <td>{{ $expense->incomeTax }}</td>
        
        </tr>

             
      </table>
     </div>
    </div>
  </div>