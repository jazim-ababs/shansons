
<div style="float: right; margin-right: 30px;">
    {{ $collection->links() }}
</div>