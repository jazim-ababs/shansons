<div class="{{ $responsiveClass }}">
            
    <div>
                    
        <table style="margin-top: 20px;" class="table">

            @if(count($payrolls) > 0)
    
                <tr>
                    <th>Sr No</th>
                    <th>Name</th>
                    <th>Working Days</th>
                    <th>Basic Salary</th>
                    <th>Total Hours	</th>
                    <th>Late Hours	</th>
                    <th>Total Over Time	</th>
                    <th>Over Time Commission</th>
                    <th>Net Salary	</th>
                    <th>Co. Section	</th>
                    <th>P.Balance	</th>
                    <th>Day Book</th>
                    <th>Total</th>
                    <th>Advance Dedication</th>
                    <th>Penality</th>
                    <th>Final Salary</th>
                    <th>Pay Salary</th>
                    <th>Signature</th>
                    <th>B/Loan</th>
                    <th>Total Security</th>
                </tr>

                @foreach($payrolls as $payroll)

                <tr>
                    
                    <td>{{ $payroll->srNumber }}</td>
                    <td>{{ $payroll->name }}</td>
                    <td>{{ $payroll->workingDays }}</td>
                    <td>{{ $payroll->basicSalary }}</td>
                    <td>{{ $payroll->totalHours }}</td>
                    <td>{{ $payroll->lateHours }}</td>
                    <td>{{ $payroll->overTime }}</td>
                    <td>{{ $payroll->overTimeCommission }}</td>
                    <td>{{ $payroll->netSalary }}</td>
                    <td>{{ $payroll->coSec }}</td>
                    <td>{{ $payroll->pBalance }}</td>
                    <td>{{ $payroll->daybook }}</td>
                    <td>{{ $payroll->total }}</td>
                    <td>{{ $payroll->advanceDeduction }}</td>
                    <td>{{ $payroll->penalty }}</td>
                    <td>{{ $payroll->finalSalary }}</td>
                    <td>{{ $payroll->paySalary }}</td>
                    <td>{{ $payroll->signature }}</td>
                    <td>{{ $payroll->bLoan }}</td>
                    <td>{{ $payroll->totalSecurity }}</td>
                </tr>

                @endforeach
                

            @endif   

        </table>

    </div>

</div>