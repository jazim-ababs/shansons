<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title', 'Default Report')</title>

    <link rel="stylesheet" href="{{ asset('admin/css/bootstrap.min.css') }}">

    @stack('styling')

</head>
<body>


        @include('shared.main-print')

        <div>
            @yield('content')
        </div>

       
    <script src="{{ asset('admin/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery.js') }}"></script>
    @stack('scripting')
    
</body>
</html>