<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// use League\Flysystem\Config;

Route::get('/', function () {
	// $record = config('settings.pages');
    return view('landing-page');
});

Route::get('sendattachmentemail','MailController@attachment_email');
Route::get('sendhtmlemail','MailController@html_email');

Route::get('/dashboard/fuel', function() {
	return view('admin.dashboard.fuel');
});


// to show all different dashboards
Route::get('/dashboard', 'DashboardController@dashboard')->name('dashboard');
Route::get('/dashboard/store', 'DashboardController@store')->name('store');
Route::get('/dashboard/mainstore', 'DashboardController@mainstore')->name('mainstore');
Route::get('/dashboard/fuel', 'DashboardController@fuel')->name('fuel');
Route::get('/dashboard/accounts', 'DashboardController@accounts')->name('accounts');
Route::get('/dashboard/hr', 'DashboardController@hr')->name('hr');


// Routes for Company
Route::resource('company', 'CompanyController', [

	'names' => [
		'create'	=>	'company.create',
		'index'	=>	'company.index',
		'edit'	=>	'company.edit',
		'update'	=>	'company.update',
		'store'	=>	'company.store',
		'destroy' => 'company.destroy',
	]

]);

// Routes for Finish Store
Route::get('finishstore/record', 'Store\FinishStoreController@record')->name('finishstore.record');
Route::post('finishstore/{companyId}/selectDate', 'Store\FinishStoreController@selectDate')->name('finishstore.selectDate');

Route::resource('company/{companyId}/finishstore', 'Store\FinishStoreController', [

	'names'	=> [
		'create' => 'finishstore.create',
		'store' => 'finishstore.store',
		'index' => 'finishstore.index',
		'edit' => 'finishstore.edit',
		'update' => 'finishstore.update',
		'destroy' => 'finishstore.destroy',
	]

]);


// Routes For Gates
Route::get('/gate/print/{id}', 'GateController@single')->name('gate.single');
Route::get('gate/printall', 'GateController@printAll')->name('gate.printall');
Route::resource('gate', 'GateController', [

	'names' => [
		'create' => 'gate.create',
		'store' => 'gate.store',
		'index' => 'gate.index',
		'update' => 'gate.update'
	]

]);


// Routes for HR\Employees
Route::resource('employee', 'Hr\EmployeeController', [

	'names' => [
		'create' => 'employee.create',
		'store' => 'employee.store',
		'index' => 'employee.index',
		'edit' => 'employee.edit',
		'update' => 'employee.update',
		'destroy' => 'employee.destroy'
	]

]);


// Routes for Petrole
Route::get('petrole/{id}/print', 'Fuel\PetroleController@singleprint')->name('petrole.singleprint');
Route::resource('petrole', 'Fuel\PetroleController', [

	'names' => [
		'create' => 'petrole.create',
		'store' => 'petrole.store',
		'index' => 'petrole.index',
		'edit' => 'petrole.edit',
		'update' => 'petrole.update',
		'destroy' => 'petrole.destroy'
	]

]);


// Routes for Diesel
Route::get('diesel/{id}/print', 'Fuel\DieselController@singleprint')->name('diesel.singleprint');
Route::resource('diesel', 'Fuel\DieselController', [

	'names' => [
		'create' => 'diesel.create',
		'store' => 'diesel.store',
		'index' => 'diesel.index',
		'edit' => 'diesel.edit',
		'update' => 'diesel.update',
		'destroy' => 'diesel.destroy'
	]

]);


// Routes for Cutting Oil
Route::get('cuttingoil/{id}/print', 'Fuel\CuttingoilController@singleprint')->name('cuttingoil.singleprint');
Route::resource('cuttingoil', 'Fuel\CuttingoilController', [

	'names' => [
		'create' => 'cuttingoil.create',
		'store' => 'cuttingoil.store',
		'index' => 'cuttingoil.index',
		'edit' => 'cuttingoil.edit',
		'update' => 'cuttingoil.update',
		'destroy' => 'cuttingoil.destroy'
	]

]);


// Routes for Fuel Catagory
Route::resource('fuelcatagory', 'Fuel\FuelCatagoryController', [

	'names' => [
		'create' => 'fuelcatagory.create',
		'store' => 'fuelcatagory.store',
		'edit' => 'fuelcatagory.edit',
		'index' => 'fuelcatagory.index',
		'update' => 'fuelcatagory.update',
		'destroy' => 'fuelcatagory.destroy',
	]

]);

// Routes for Fuel
Route::get('fuel/create', 'Fuel\FuelController@create')->name('fuel.create');
Route::post('fuel', 'Fuel\FuelController@store')->name('fuel.store');
Route::post('fuel/record', 'Fuel\FuelController@index')->name('fuel.index');
Route::get('fuel/{id}/edit', 'Fuel\FuelController@edit')->name('fuel.edit');
Route::patch('fuel/{id}', 'Fuel\FuelController@update')->name('fuel.update');
Route::delete('fuel/{id}', 'Fuel\FuelController@destroy')->name('fuel.destroy');
Route::get('fuel/{id}/print', 'Fuel\FuelController@singleprint')->name('fuel.singleprint');

// Route::resource('fuel', 'Fuel\FuelController', [

// 	'names' => [
// 		'create' => 'fuel.create',
// 		'store' => 'fuel.store'
// 	]

// ]);


// Routes for Party Name
Route::resource('partyname', 'Partyname\PartyNameController', [

	'names' => [
		'create' => 'partyname.create',
		'store' => 'partyname.store',
		'index' => 'partyname.index',
		'edit' => 'partyname.edit',
		'update' => 'partyname.update',
		'destroy' => 'partyname.destroy',
	]

]);

// Routes for Purchase 
Route::get('/purchase/{partynameId}/print', 'Partyname\PurchaseController@print')->name('purchase.print');
Route::get('purchase/createpage', 'Partyname\PurchaseController@createpage')->name('purchase.createpage');
Route::resource('partyname/{partynameID}/purchase', 'Partyname\PurchaseController', [

	'names' => [
		'create' => 'purchase.create',
		'store' => 'purchase.store',
		'index' => 'purchase.index',
		'edit' => 'purchase.edit',
		'update' => 'purchase.update',
		'destroy' => 'purchase.destroy',
		'show' => 'purchase.show',
	]

]);

// Routes for PayRoll
Route::get('/payroll/open', 'Partyname\PayrollController@open')->name('payroll.open');
Route::get('/payroll/print', 'Partyname\PayrollController@print')->name('payroll.print');
Route::resource('employee/{empId}/payroll', 'Partyname\PayRollController', [

	'names' => [
		'create' => 'payroll.create',
		'store' => 'payroll.store',
		'index' => 'payroll.index',
		'edit' => 'payroll.edit',
		'update' => 'payroll.update',
		'destroy' => 'payroll.destroy',
		'show' => 'payroll.show',
	]

]);


// Routes for Salename
Route::resource('salename', 'Partyname\SaleNameController', [

	'names' => [
		'create' => 'salename.create',
		'store' => 'salename.store',
		'index' => 'salename.index',
		'edit' => 'salename.edit',
		'update' => 'salename.update',
		'destroy' => 'salename.destroy',
	]

]);

// Routes for Sale
Route::get('sale/createpage', 'Partyname\SaleController@createpage')->name('sale.createpage');
Route::resource('salename/{salenameID}/sale', 'Partyname\SaleController', [

	'names' => [
		'create' => 'sale.create',
		'store' => 'sale.store',
		'index' => 'sale.index',
		'edit' => 'sale.edit',
		'update' => 'sale.update',
		'destroy' => 'sale.destroy',
		'show' => 'sale.show'
	]

]);


// Rotues for Inward
Route::resource('inward', 'Mainstore\InwardController', [

	'names' => [
		'create' => 'inward.create',
		'store' => 'inward.store',
		'index' => 'inward.index',
		'edit' => 'inward.edit',
		'update' => 'inward.update',
		'destroy' => 'inward.destroy',
		'show' => 'inward.show'
	]

]);

// Rotues for Outward Returnable
Route::resource('returnable', 'Mainstore\ReturnableController', [

	'names' => [
		'create' => 'returnable.create',
		'store' => 'returnable.store',
		'index' => 'returnable.index',
		'edit' => 'returnable.edit',
		'update' => 'returnable.update',
		'destroy' => 'returnable.destroy',
		'show' => 'returnable.show',
	]

]);

// Routes for Outward Gatepass
Route::resource('gatepass', 'Mainstore\GatepassController', [

	'names' => [
		'create' => 'gatepass.create',
		'store' => 'gatepass.store',
		'index' => 'gatepass.index',
		'edit' => 'gatepass.edit',
		'update' => 'gatepass.update',
		'destroy' => 'gatepass.destroy',
		'show' => 'gatepass.show',
	]

]);


// Routes for Raw Material Store
Route::resource('raw-material', 'Store\RawMaterialStoreController', [

	'names' => [
		'create' => 'raw.create',
		'store' => 'raw.store',
		'index' => 'raw.index',
		'edit' => 'raw.edit',
		'update' => 'raw.update',
		'destroy' => 'raw.destroy',
		'show' => 'raw.show',
	]

]);


// Routes for daybook
Route::get('/print/daybook/{id}', 'Partyname\DaybookController@print')->name('daybook.print');
Route::resource('daybook', 'Partyname\DaybookController', [

	'names' => [
		'create' => 'daybook.create',
		'store' => 'daybook.store',
		'index' => 'daybook.index',
		'show' => 'daybook.show',
		'destroy' => 'daybook.destroy'
	]

]);


//Routes for Expenses
Route::get('/expenses/page', 'Partyname\ExpensesController@createpage')->name('expenses.createpage');
Route::get('/create/expenses', 'Partyname\ExpensesController@createExpenses');
// Route::post('store-expenses', 'Partyname\ExpensesController@store')->name('expenses.store');
Route::get('/expenses/print/{id}', 'Partyname\ExpensesController@print')->name('expenses.print');
Route::resource('expenses', 'Partyname\ExpensesController', [

	'names' => [
		'store' => 'expenses.store',
		'index' => 'expenses.index',
		'edit' => 'expenses.edit',
		'update' => 'expenses.update',
		'destroy' => 'expenses.destroy',
	]

]);


// Routes for Profit
Route::get('/profit/create', 'Partyname\ProfitController@create')->name('profit.create');
Route::post('/profit/date', 'Partyname\ProfitController@store')->name('profit.store');
Route::get('/profit/{date}', 'Partyname\ProfitController@show')->name('profit.show');

// Routes for Auth
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


// Routes for Reseting Password through Email
Route::post('/reset/password', 'PasswordForgetController@send_link')->name('password.reset');
Route::get('/setpassword/{confirmation_token}', 'PasswordForgetController@setPassword')->name('password.set');
Route::post('/update-password', 'PasswordForgetController@update')->name('password.update');
Route::get('/reset', 'PasswordForgetController@reset')->name('reset');


// Routes for Profile
Route::get('/profile/edit', 'ProfileController@edit')->name('profile.edit');
Route::patch('/profile/{id}/update', 'ProfileController@update')->name('profile.update');


// Routes for Users
Route::get('/user/create', 'UserController@create')->name('user.create');
Route::post('/user', 'UserController@store')->name('user.store');
Route::get('/user', 'UserController@index')->name('user.index');
Route::post('/user/{id}/action', 'UserController@action')->name('user.action');
Route::delete('/user/{id}', 'UserController@destroy')->name('user.destroy');


// Routs for Reports
Route::get('/main-report', function() {
	return view('layouts.print');
});

Route::get('inventory/print', 'Mainstore\InventoryController@print')->name('inventory.print');
Route::resource('inventory', 'Mainstore\InventoryController', [
	'names' => [
		'create' => 'inventory.create',
		'store' => 'inventory.store',
		'index' => 'inventory.index',
		'edit' => 'inventory.edit',
		'update' => 'inventory.update',
		'destroy' => 'inventory.destroy',
	]
]);


// for rejected reports
Route::resource('rejectedReport', 'RejectedReportController');



Route::get('/grn/create', 'GrnController@create');
Route::Post('/grn/create','GrnController@store');
Route::get('/grn', 'GrnController@index');

Route::get('/grn/{grn}/edit','GrnController@edit');

Route::patch('/grn/{id}', 'GrnController@update');
Route::delete('/grn/{id}', 'GrnController@destroy');
Route::get('/grn/print', 'GrnController@print');




Route::get('/dc/create', 'DcController@create');
Route::Post('/dc/create','DcController@store');
Route::get('/dc', 'DcController@index');

Route::get('/dc/{dc}/edit','DcController@edit');
Route::patch('/dc/{id}', 'DcController@update');
Route::delete('/dc/{dc}', 'DcController@destroy');
Route::get('/dc/print', 'DcController@print');


Route::get('/dn/create', 'DnController@create');
Route::Post('/dn/create','DnController@store');
Route::get('/dn', 'DnController@index');

Route::get('/dn/{dn}/edit','DnController@edit');

Route::patch('/dn/{id}', 'DnController@update');
Route::delete('/dn/{dn}', 'DnController@destroy');
Route::get('/dn/print', 'DnController@print');
