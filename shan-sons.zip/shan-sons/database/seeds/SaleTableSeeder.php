<?php

use App\PartynameModel\Sale;
use Illuminate\Database\Seeder;

class SaleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Sale::create([
            'salename_id' => 1,
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
            'invoiceNo' => rand(1, 100),
        ]);
    }
}
