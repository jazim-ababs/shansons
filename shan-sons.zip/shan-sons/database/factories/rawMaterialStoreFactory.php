<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\StoreModel\Rawmaterial;
use Faker\Generator as Faker;

$factory->define(Rawmaterial::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'srNumber' => $faker->randomDigit,
        'date' => $date,
        'uom' => $faker->sentence(1),
        'issue' => $faker->sentence(1),
        'description' => $faker->text(),
        'balance' => $faker->randomDigit,
    ];
});
