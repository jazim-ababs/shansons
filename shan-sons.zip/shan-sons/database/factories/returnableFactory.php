<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\MainstoreModel\Returnable;
use Faker\Generator as Faker;

$factory->define(Returnable::class, function (Faker $faker) {
    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'srNumber' => $faker->randomDigit,
        'date' => $date,
        'partyName' => $faker->sentence(1),
        'vehicleNumber' => $faker->sentence(1),
        'byHand' => $faker->sentence(1),
        'description' => $faker->text(),
        'unit' => $faker->sentence(1),
        'quantity' => $faker->randomDigit,
        'box' => $faker->randomDigit,
        'price' => $faker->randomDigit,
    ];
});
