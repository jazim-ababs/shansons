<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\FuelModel\Fuelcatagory;
use Faker\Generator as Faker;

$factory->define(Fuelcatagory::class, function (Faker $faker) {
    return [
        'fuelCatagory' => $faker->sentence(1)
    ];
});
