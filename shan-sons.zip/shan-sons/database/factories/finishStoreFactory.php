<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\StoreModel\FinishStore;
use Faker\Generator as Faker;

$factory->define(FinishStore::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'date' => $date,
        'description' => $faker->text(),
        'openingBalance' => $faker->randomDigit,
        'packing' => $faker->sentence(1),
        'endingBalance' => $faker->randomDigit,
        'qtv' => $faker->randomDigit,
        'balance' => $faker->randomDigit,
        'receive' => $faker->randomDigit,
        'company_id' => function () {
            return factory(App\Company::class)->create()->id;
        }

    ];
});
