<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\PartynameModel\Salename;
use Faker\Generator as Faker;

$factory->define(Salename::class, function (Faker $faker) {
    return [
        'name' => $faker->name('male'),
        'mobileNumber' => $faker->phoneNumber
    ];
});
