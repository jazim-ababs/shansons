<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\PartynameModel\Payroll;
use Faker\Generator as Faker;

$factory->define(Payroll::class, function (Faker $faker) {
    return [
        'srNumber' => $faker->randomDigit,
        'name' => $faker->name('male'),
        'basicSalary' => $faker->randomDigit,
        'workingDays' => $faker->randomDigit,
        'totalHours' => $faker->randomDigit,
        'lateHours' => $faker->randomDigit,
        'overTime' => $faker->randomDigit,
        'overTimeCommission' => $faker->randomDigit,
        'netSalary' => $faker->randomDigit,
        'coSec' => $faker->randomDigit,
        'pBalance' => $faker->randomDigit,
        'daybook' => $faker->sentence(1),
        'total' => $faker->randomDigit,
        'advanceDeduction' => $faker->randomDigit,
        'penalty' => $faker->randomDigit,
        'finalSalary' => $faker->randomDigit,
        'paySalary' => $faker->randomDigit,
        'signature' => $faker->sentence(1),
        'bLoan' => $faker->randomDigit,
        'totalSecurity' => $faker->randomDigit
    ];
});
