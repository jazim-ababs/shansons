<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\PartynameModel\Purchase;
use Faker\Generator as Faker;

$factory->define(Purchase::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'date' => $date,
        'girn' => $faker->randomDigit,
        'description' => $faker->text(),
        'qty' => $faker->sentence(1),
        'uom' => $faker->text(),
        'price' => $faker->randomDigit,
        'dr' => $faker->randomDigit,
        'cr' => $faker->randomDigit,
        'balance' => $faker->randomDigit,
        'partyname_id' => function () {
            return factory(App\PartynameModel\Partyname::class)->create()->id;
        }

    ];
});
