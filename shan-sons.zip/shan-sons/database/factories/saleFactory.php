<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\PartynameModel\Sale;
use Faker\Generator as Faker;

$factory->define(Sale::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'invoiceNo' => $faker->randomDigit,
        'invoiceDate' => $date,
        'customerId' => $faker->randomDigit,
        'customerPro' => $faker->sentence(1),
        'paymentTerms' => $faker->sentence(1),
        'salesRepId' => $faker->randomDigit,
        'shippingMethod' => $faker->sentence(1),
        'shipDate' => $date,
        'dueDate' => $date,
        'quantity' => $faker->randomDigit,
        'item' => $faker->sentence(1),
        'description' => $faker->text(),
        'unitPrice' => $faker->randomDigit,
        'amount' => $faker->randomDigit,
        'balance' => $faker->randomDigit,
        'totalInvoiceAmount' => $faker->randomDigit,
        'credit' => $faker->randomDigit,
        'salename_id' => function () {
            return factory(App\PartynameModel\Salename::class)->create()->id;
        }
        
    ];
});
