<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\PartynameModel\Daybook;
use Faker\Generator as Faker;

$factory->define(Daybook::class, function (Faker $faker) {

	$start = new DateTime('2019-10-01');
	$end = new DateTime('2019-10-29');
	
	$randomTimestamp = mt_rand($start->getTimestamp(), $end->getTimestamp());
    $randomDate = new DateTime();
    $randomDate->setTimestamp($randomTimestamp);
    $date = $randomDate->format('Y-m-d');

    return [
        'date' => $date,
        'voucherNo' => $faker->randomDigit,
        'openingBalance' => $faker->randomDigit,
        'rpDb' => $faker->randomDigit,
        'otherExpCr' => $faker->randomDigit,
        'otherExpDb' => $faker->randomDigit,
        'wagesCr' => $faker->randomDigit,
        'wagesDb' => $faker->randomDigit,
        'fuelCr' => $faker->randomDigit,
        'fuelDb' => $faker->randomDigit,
        'advanceCr' => $faker->randomDigit,
        'advanceDb' => $faker->randomDigit,
        'entertainCr' => $faker->randomDigit,
        'entertainDb' => $faker->randomDigit
    ];
});
