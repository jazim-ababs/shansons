<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\Gate;
use Faker\Generator as Faker;

$factory->define(Gate::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'srNumber' => $faker->randomDigit,
        'date' => $date,
        'timing' => $date,
        'name' => $faker->name('male'),
        'vehicleNumber' => $faker->sentence(1),
        'contactInfo' => $faker->sentence(2),
        'description' => $faker->sentence(3),
        'quantity' => $faker->randomDigit,
    ];
});
