<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\HrModel\Employee;
use Faker\Generator as Faker;

$factory->define(Employee::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'employeeNo' => $faker->randomDigit,
        'name' => $faker->name('male'),
        'date' => $date,
        'mobileNo' => $faker->phoneNumber,
        'address' => $faker->text(),
        'department' => $faker->sentence(1),
    ];
});
