<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Custom\FactoryDate;
use App\MainstoreModel\Inventory;
use Faker\Generator as Faker;

$factory->define(Inventory::class, function (Faker $faker) {

    $dateObj = new FactoryDate;
    $date = $dateObj->getDate();

    return [
        'srNumber' => $faker->randomDigit,
        'date' => $date,
        'description' => $faker->text(),
        'quantity' => $faker->randomDigit,
        'issue' => $faker->randomDigit,
        'return' => $faker->randomDigit,
        'balance' => $faker->randomDigit,
    ];
});
