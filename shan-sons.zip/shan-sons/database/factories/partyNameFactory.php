<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\PartynameModel\Partyname;
use Faker\Generator as Faker;

$factory->define(Partyname::class, function (Faker $faker) {
    return [
        'srNumber' => $faker->randomDigit,
        'ac' => $faker->randomDigit,
        'partyName' => $faker->sentence(1)
    ];
});
