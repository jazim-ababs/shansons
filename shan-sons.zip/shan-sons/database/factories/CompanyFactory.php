<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Company;
use Faker\Generator as Faker;

$factory->define(Company::class, function (Faker $faker) {
    return [
        'companyName' => $faker->sentence(5),
        'address' => $faker->sentence(5),
        'number' => $faker->sentence(5),
        'ntnNumber' => $faker->sentence(5),
    ];
});
