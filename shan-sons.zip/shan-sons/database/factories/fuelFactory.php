<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\FuelModel\Fuel;
use Faker\Generator as Faker;

$factory->define(Fuel::class, function (Faker $faker) {
    return [
        'openingBalance' => $faker->randomDigit,
        'srNo' => $faker->randomDigit,
        'name' => $faker->sentence(1),
        'description' => $faker->text(),
        'uom' => $faker->sentence(1),
        'issue' => $faker->sentence(1),
        'received' => $faker->sentence(1),
        'balance' => $faker->randomDigit,
        'total' => $faker->randomDigit,
        'fuelcatagory_id' => function () {
            return factory(App\FuelModel\Fuelcatagory::class)->create()->id;
        }

    ];
});
