<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePayrollsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payrolls', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('employee_id')->index();
            $table->integer('srNumber');
            $table->integer('basicSalary');
            $table->integer('workingDays');
            $table->integer('totalSalary');
            $table->integer('totalHours');
            $table->integer('lateHours');
            $table->integer('overTime');
            $table->integer('overTimeCommission');
            $table->integer('netSalary');
            $table->integer('coSec');
            $table->integer('pBalance');
            $table->string('daybook');
            $table->integer('total');
            $table->integer('advanceDeduction');
            $table->integer('penalty');
            $table->integer('finalSalary');
            $table->integer('paySalary');
            $table->string('signature');
            $table->integer('bLoan');
            $table->integer('remainingLoan')->default(0);
            $table->integer('totalSecurity')->default(0);
            $table->timestamps();

            $table->foreign('employee_id')->references('id')->on('employees')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payrolls');
    }
}
