<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salename_id')->index();
            $table->integer('invoiceNo');
            $table->string('invoiceDate');
            $table->integer('customerId');
            $table->string('customerPro');
            $table->string('paymentTerms');
            $table->integer('salesRepId');
            $table->string('shippingMethod');
            $table->string('shipDate');
            $table->string('dueDate');
            $table->integer('quantity');
            $table->string('item');
            $table->text('description');
            $table->integer('unitPrice');
            $table->integer('amount');
            $table->integer('balance');
            $table->integer('totalInvoiceAmount');
            $table->integer('credit');
            $table->timestamps();

            $table->foreign('salename_id')->references('id')->on('salenames')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales');
    }
}
