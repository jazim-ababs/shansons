<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFuelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fuels', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('fuelcatagory_id')->index();
            $table->integer('openingBalance');
            $table->integer('srNo');
            $table->string('name');
            $table->text('description');
            $table->string('uom');
            $table->string('issue');
            $table->string('received');
            $table->integer('balance');
            $table->integer('total');
            $table->timestamps();

            $table->foreign('fuelcatagory_id')->references('id')->on('fuelcatagories')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fuels');
    }
}
