<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRejectedreportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rejectedreports', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('partyname');
            $table->integer('totalBalance');
            $table->text('description');
            $table->string('process');
            $table->string('workerName');
            $table->string('checkBy');
            $table->integer('balance');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rejectedreports');
    }
}
