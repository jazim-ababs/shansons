<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePurchasesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchases', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('partyname_id')->index();
            $table->string('date');
            $table->integer('girn');
            $table->text('description');
            $table->string('qty');
            $table->text('uom');
            $table->integer('price');
            $table->integer('dr');
            $table->integer('cr');
            $table->integer('balance');
            $table->timestamps();

            $table->foreign('partyname_id')->references('id')->on('partynames')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchases');
    }
}
