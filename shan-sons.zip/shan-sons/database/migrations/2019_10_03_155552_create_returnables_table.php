<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateReturnablesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('returnables', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('srNumber');
            $table->string('date');
            $table->string('partyName');
            $table->string('vehicleNumber');
            $table->string('byHand');
            $table->text('description');
            $table->string('unit');
            $table->integer('quantity');
            $table->integer('box');
            $table->integer('price');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('returnables');
    }
}
