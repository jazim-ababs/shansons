<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateExpensesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('expenses', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('date');
            $table->integer('advanceSalary');
            $table->integer('entertainment');
            $table->integer('otherExpenses');
            $table->integer('fuelExpenses');
            $table->integer('repairAndMain');
            $table->integer('courier');
            $table->integer('eob');
            $table->integer('accessories');
            $table->integer('billFactory');
            $table->integer('freight');
            $table->integer('hardware');
            $table->integer('home');
            $table->integer('lunch');
            $table->integer('rent');
            $table->integer('lubricantDiesel');
            $table->integer('officeExpenses');
            $table->integer('paint');
            $table->integer('fuelToolPlaza');
            $table->integer('rawMaterial');
            $table->integer('taxes');
            $table->integer('installment');
            $table->integer('services');
            $table->integer('socialSecurity');
            $table->integer('incomeTax');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('expenses');
    }
}
