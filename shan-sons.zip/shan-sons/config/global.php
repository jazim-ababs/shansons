<?php

return [
    'pages' => 5
]

?>