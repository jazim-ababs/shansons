<?php

return [
    'pages' => 10
];
